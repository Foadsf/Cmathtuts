/*ForcheckIDE/Constants.h*/

/****************************************************************************

    Copyright 2016 Erik Kruyt, Forcheck b.v.

    This file is part of forcheckIDE.

    forcheckIDE is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    forcheckIDE is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with forcheckIDE.  If not, see <http://www.gnu.org/licenses/>.

****************************************************************************/

#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <QString>

class Constants {
public:
        static const QString DefaultEditorFileName;
        static const QString DefaultEditorCommandLine;
        static const QString DefaultCompiler;
        static const QString DefaultCompilerOptions;
        static const QString DefaultCompilerDebugOptions;
        static const QString DefaultcCompiler;
        static const QString DefaultcCompilerOptions;
        static const QString DefaultLinkerOptions;
        static const QString DefaultBuildUtility;

        static const QString DefaultExt_Project;
        static const QString DefaultExt_Make;
        static const QString DefaultExt_Source;
        static const QString DefaultExt_PreSource;
        static const QString DefaultExt_CSource;
        static const QString DefaultExt_Include;
        static const QString DefaultExt_Library;
        static const QString DefaultExt_Listing;
        static const QString DefaultExt_Report;
        static const QString DefaultExt_Refstruct;
        static const QString DefaultExt_ModDep;
        static const QString DefaultExt_Bin;

        static const QString DefaultEmulationFilename;

        static const QString HelpFilename;

        static const QString FckConfigurationFilename;
        static const QString IDEConfigurationFilename;
        static const QString DefaultOptionsFilename;
        static const QString FckPwdFilename;
        static const QString FckMsgFilename;
        static const QString DepFilename;
        static const QString DefaultReportFilename;
        static const QString CommandFilename;

        static const QString FckExecutable;
        static const QString InterfExecutable;
        static const QString InstallationReport;
};
#endif
