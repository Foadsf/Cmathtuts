/*ForcheckIDE/Info.cpp*/

/****************************************************************************

    Copyright 2016 Erik Kruyt, Forcheck b.v.

    This file is part of forcheckIDE.

    forcheckIDE is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    forcheckIDE is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with forcheckIDE.  If not, see <http://www.gnu.org/licenses/>.

****************************************************************************/

#include "Info.h"

#include <QSysInfo>

const QString Info::APPLICATION = "ForcheckIDE";
#if defined(Q_OS_WIN)
  const QString Info::IMPLEMENTATION = "PC/Windows";
#elif defined(Q_OS_LINUX)
  const QString Info::IMPLEMENTATION = "PC/Linux";
#endif

const QString Info::VERSION = "14.6.07";

const QString Info::TITLE = "Forcheck IDE ";

const QString Info::Address =
                "Forcheck b.v.\n"
                "Leiden\n"
                "The Netherlands\n"
        ;

const QString Info::E_MAIL = "mailto:info@forcheck.nl";
const QString Info::HOMEPAGE_URL = "http://www.forcheck.nl";
const QString Info::FAQ_URL = "http://www.forcheck.nl/faq.htm";
const QString Info::REGISTRATION_URL = "http://www.forcheck.nl/register.htm";
const QString Info::VERSION_URL = "http://www.forcheck.nl/kits/versioninfo.htm";
