      Common /Stats/ACPW,AWPS,NW,NP,NL,NC,NEC(255)
