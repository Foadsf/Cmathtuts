/* A Bison parser, made by GNU Bison 1.875c.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     tok_identifier = 258,
     tok_array_identifier = 259,
     tok_label = 260,
     tok_integer_const = 261,
     tok_real_const = 262,
     tok_dp_const = 263,
     tok_quad_const = 264,
     tok_complex_const = 265,
     tok_dcomplex_const = 266,
     tok_logical_const = 267,
     tok_string = 268,
     tok_hollerith = 269,
     tok_edit_descriptor = 270,
     tok_letter = 271,
     tok_relop = 272,
     tok_AND = 273,
     tok_OR = 274,
     tok_EQV = 275,
     tok_NEQV = 276,
     tok_NOT = 277,
     tok_power = 278,
     tok_concat = 279,
     tok_lparen = 280,
     tok_pointer_assignment = 281,
     tok_ACCEPT = 282,
     tok_ALLOCATABLE = 283,
     tok_ALLOCATE = 284,
     tok_ASSIGN = 285,
     tok_BACKSPACE = 286,
     tok_BLOCKDATA = 287,
     tok_BYTE = 288,
     tok_CALL = 289,
     tok_CASE = 290,
     tok_CASEDEFAULT = 291,
     tok_CHARACTER = 292,
     tok_CLOSE = 293,
     tok_COMMON = 294,
     tok_COMPLEX = 295,
     tok_CONTINUE = 296,
     tok_CYCLE = 297,
     tok_DATA = 298,
     tok_DEALLOCATE = 299,
     tok_DIMENSION = 300,
     tok_DO = 301,
     tok_DOUBLECOMPLEX = 302,
     tok_DOUBLEPRECISION = 303,
     tok_DOWHILE = 304,
     tok_ELSE = 305,
     tok_END = 306,
     tok_ENDBLOCKDATA = 307,
     tok_ENDDO = 308,
     tok_ENDFILE = 309,
     tok_ENDFUNCTION = 310,
     tok_ENDIF = 311,
     tok_ENDPROGRAM = 312,
     tok_ENDSELECT = 313,
     tok_ENDSUBROUTINE = 314,
     tok_ENTRY = 315,
     tok_EQUIVALENCE = 316,
     tok_EXTERNAL = 317,
     tok_EXIT = 318,
     tok_FORMAT = 319,
     tok_FUNCTION = 320,
     tok_GOTO = 321,
     tok_IF = 322,
     tok_IMPLICIT = 323,
     tok_INCLUDE = 324,
     tok_INQUIRE = 325,
     tok_INTEGER = 326,
     tok_INTRINSIC = 327,
     tok_LOGICAL = 328,
     tok_NAMELIST = 329,
     tok_NONE = 330,
     tok_NULLIFY = 331,
     tok_OPEN = 332,
     tok_PARAMETER = 333,
     tok_PAUSE = 334,
     tok_POINTER = 335,
     tok_PRINT = 336,
     tok_PROGRAM = 337,
     tok_READ = 338,
     tok_REAL = 339,
     tok_RETURN = 340,
     tok_REWIND = 341,
     tok_SAVE = 342,
     tok_SELECTCASE = 343,
     tok_STOP = 344,
     tok_SUBROUTINE = 345,
     tok_TARGET = 346,
     tok_THEN = 347,
     tok_TO = 348,
     tok_TYPE = 349,
     tok_WHILE = 350,
     tok_WRITE = 351,
     tok_illegal = 352,
     tok_empty = 353,
     EOS = 127,
     REDUCE = 354
   };
#endif
#define tok_identifier 258
#define tok_array_identifier 259
#define tok_label 260
#define tok_integer_const 261
#define tok_real_const 262
#define tok_dp_const 263
#define tok_quad_const 264
#define tok_complex_const 265
#define tok_dcomplex_const 266
#define tok_logical_const 267
#define tok_string 268
#define tok_hollerith 269
#define tok_edit_descriptor 270
#define tok_letter 271
#define tok_relop 272
#define tok_AND 273
#define tok_OR 274
#define tok_EQV 275
#define tok_NEQV 276
#define tok_NOT 277
#define tok_power 278
#define tok_concat 279
#define tok_lparen 280
#define tok_pointer_assignment 281
#define tok_ACCEPT 282
#define tok_ALLOCATABLE 283
#define tok_ALLOCATE 284
#define tok_ASSIGN 285
#define tok_BACKSPACE 286
#define tok_BLOCKDATA 287
#define tok_BYTE 288
#define tok_CALL 289
#define tok_CASE 290
#define tok_CASEDEFAULT 291
#define tok_CHARACTER 292
#define tok_CLOSE 293
#define tok_COMMON 294
#define tok_COMPLEX 295
#define tok_CONTINUE 296
#define tok_CYCLE 297
#define tok_DATA 298
#define tok_DEALLOCATE 299
#define tok_DIMENSION 300
#define tok_DO 301
#define tok_DOUBLECOMPLEX 302
#define tok_DOUBLEPRECISION 303
#define tok_DOWHILE 304
#define tok_ELSE 305
#define tok_END 306
#define tok_ENDBLOCKDATA 307
#define tok_ENDDO 308
#define tok_ENDFILE 309
#define tok_ENDFUNCTION 310
#define tok_ENDIF 311
#define tok_ENDPROGRAM 312
#define tok_ENDSELECT 313
#define tok_ENDSUBROUTINE 314
#define tok_ENTRY 315
#define tok_EQUIVALENCE 316
#define tok_EXTERNAL 317
#define tok_EXIT 318
#define tok_FORMAT 319
#define tok_FUNCTION 320
#define tok_GOTO 321
#define tok_IF 322
#define tok_IMPLICIT 323
#define tok_INCLUDE 324
#define tok_INQUIRE 325
#define tok_INTEGER 326
#define tok_INTRINSIC 327
#define tok_LOGICAL 328
#define tok_NAMELIST 329
#define tok_NONE 330
#define tok_NULLIFY 331
#define tok_OPEN 332
#define tok_PARAMETER 333
#define tok_PAUSE 334
#define tok_POINTER 335
#define tok_PRINT 336
#define tok_PROGRAM 337
#define tok_READ 338
#define tok_REAL 339
#define tok_RETURN 340
#define tok_REWIND 341
#define tok_SAVE 342
#define tok_SELECTCASE 343
#define tok_STOP 344
#define tok_SUBROUTINE 345
#define tok_TARGET 346
#define tok_THEN 347
#define tok_TO 348
#define tok_TYPE 349
#define tok_WHILE 350
#define tok_WRITE 351
#define tok_illegal 352
#define tok_empty 353
#define EOS 127
#define REDUCE 354




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
typedef int YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;



