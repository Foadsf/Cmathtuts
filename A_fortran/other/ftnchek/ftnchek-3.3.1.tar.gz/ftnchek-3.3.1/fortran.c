/* A Bison parser, made by GNU Bison 1.875c.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     tok_identifier = 258,
     tok_array_identifier = 259,
     tok_label = 260,
     tok_integer_const = 261,
     tok_real_const = 262,
     tok_dp_const = 263,
     tok_quad_const = 264,
     tok_complex_const = 265,
     tok_dcomplex_const = 266,
     tok_logical_const = 267,
     tok_string = 268,
     tok_hollerith = 269,
     tok_edit_descriptor = 270,
     tok_letter = 271,
     tok_relop = 272,
     tok_AND = 273,
     tok_OR = 274,
     tok_EQV = 275,
     tok_NEQV = 276,
     tok_NOT = 277,
     tok_power = 278,
     tok_concat = 279,
     tok_lparen = 280,
     tok_pointer_assignment = 281,
     tok_ACCEPT = 282,
     tok_ALLOCATABLE = 283,
     tok_ALLOCATE = 284,
     tok_ASSIGN = 285,
     tok_BACKSPACE = 286,
     tok_BLOCKDATA = 287,
     tok_BYTE = 288,
     tok_CALL = 289,
     tok_CASE = 290,
     tok_CASEDEFAULT = 291,
     tok_CHARACTER = 292,
     tok_CLOSE = 293,
     tok_COMMON = 294,
     tok_COMPLEX = 295,
     tok_CONTINUE = 296,
     tok_CYCLE = 297,
     tok_DATA = 298,
     tok_DEALLOCATE = 299,
     tok_DIMENSION = 300,
     tok_DO = 301,
     tok_DOUBLECOMPLEX = 302,
     tok_DOUBLEPRECISION = 303,
     tok_DOWHILE = 304,
     tok_ELSE = 305,
     tok_END = 306,
     tok_ENDBLOCKDATA = 307,
     tok_ENDDO = 308,
     tok_ENDFILE = 309,
     tok_ENDFUNCTION = 310,
     tok_ENDIF = 311,
     tok_ENDPROGRAM = 312,
     tok_ENDSELECT = 313,
     tok_ENDSUBROUTINE = 314,
     tok_ENTRY = 315,
     tok_EQUIVALENCE = 316,
     tok_EXTERNAL = 317,
     tok_EXIT = 318,
     tok_FORMAT = 319,
     tok_FUNCTION = 320,
     tok_GOTO = 321,
     tok_IF = 322,
     tok_IMPLICIT = 323,
     tok_INCLUDE = 324,
     tok_INQUIRE = 325,
     tok_INTEGER = 326,
     tok_INTRINSIC = 327,
     tok_LOGICAL = 328,
     tok_NAMELIST = 329,
     tok_NONE = 330,
     tok_NULLIFY = 331,
     tok_OPEN = 332,
     tok_PARAMETER = 333,
     tok_PAUSE = 334,
     tok_POINTER = 335,
     tok_PRINT = 336,
     tok_PROGRAM = 337,
     tok_READ = 338,
     tok_REAL = 339,
     tok_RETURN = 340,
     tok_REWIND = 341,
     tok_SAVE = 342,
     tok_SELECTCASE = 343,
     tok_STOP = 344,
     tok_SUBROUTINE = 345,
     tok_TARGET = 346,
     tok_THEN = 347,
     tok_TO = 348,
     tok_TYPE = 349,
     tok_WHILE = 350,
     tok_WRITE = 351,
     tok_illegal = 352,
     tok_empty = 353,
     EOS = 127,
     REDUCE = 354
   };
#endif
#define tok_identifier 258
#define tok_array_identifier 259
#define tok_label 260
#define tok_integer_const 261
#define tok_real_const 262
#define tok_dp_const 263
#define tok_quad_const 264
#define tok_complex_const 265
#define tok_dcomplex_const 266
#define tok_logical_const 267
#define tok_string 268
#define tok_hollerith 269
#define tok_edit_descriptor 270
#define tok_letter 271
#define tok_relop 272
#define tok_AND 273
#define tok_OR 274
#define tok_EQV 275
#define tok_NEQV 276
#define tok_NOT 277
#define tok_power 278
#define tok_concat 279
#define tok_lparen 280
#define tok_pointer_assignment 281
#define tok_ACCEPT 282
#define tok_ALLOCATABLE 283
#define tok_ALLOCATE 284
#define tok_ASSIGN 285
#define tok_BACKSPACE 286
#define tok_BLOCKDATA 287
#define tok_BYTE 288
#define tok_CALL 289
#define tok_CASE 290
#define tok_CASEDEFAULT 291
#define tok_CHARACTER 292
#define tok_CLOSE 293
#define tok_COMMON 294
#define tok_COMPLEX 295
#define tok_CONTINUE 296
#define tok_CYCLE 297
#define tok_DATA 298
#define tok_DEALLOCATE 299
#define tok_DIMENSION 300
#define tok_DO 301
#define tok_DOUBLECOMPLEX 302
#define tok_DOUBLEPRECISION 303
#define tok_DOWHILE 304
#define tok_ELSE 305
#define tok_END 306
#define tok_ENDBLOCKDATA 307
#define tok_ENDDO 308
#define tok_ENDFILE 309
#define tok_ENDFUNCTION 310
#define tok_ENDIF 311
#define tok_ENDPROGRAM 312
#define tok_ENDSELECT 313
#define tok_ENDSUBROUTINE 314
#define tok_ENTRY 315
#define tok_EQUIVALENCE 316
#define tok_EXTERNAL 317
#define tok_EXIT 318
#define tok_FORMAT 319
#define tok_FUNCTION 320
#define tok_GOTO 321
#define tok_IF 322
#define tok_IMPLICIT 323
#define tok_INCLUDE 324
#define tok_INQUIRE 325
#define tok_INTEGER 326
#define tok_INTRINSIC 327
#define tok_LOGICAL 328
#define tok_NAMELIST 329
#define tok_NONE 330
#define tok_NULLIFY 331
#define tok_OPEN 332
#define tok_PARAMETER 333
#define tok_PAUSE 334
#define tok_POINTER 335
#define tok_PRINT 336
#define tok_PROGRAM 337
#define tok_READ 338
#define tok_REAL 339
#define tok_RETURN 340
#define tok_REWIND 341
#define tok_SAVE 342
#define tok_SELECTCASE 343
#define tok_STOP 344
#define tok_SUBROUTINE 345
#define tok_TARGET 346
#define tok_THEN 347
#define tok_TO 348
#define tok_TYPE 349
#define tok_WHILE 350
#define tok_WRITE 351
#define tok_illegal 352
#define tok_empty 353
#define EOS 127
#define REDUCE 354




/* Copy the first part of user declarations.  */
#line 10 "fortran.y"


/*
  fortran.c:


Copyright (c) 2001 by Robert K. Moniot.

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Acknowledgement: the above permission notice is what is known
as the "MIT License."
*/

/*

	    This grammar is ANSI standard-conforming, except for:
		-- complex constant and a few other ambiguities needing
		   significant lookahead cannot be split across lines.

	    Extensions supported:
	        -- Case insensitive.
	 	-- Hollerith constants.
		-- Variable names may be longer than 6 characters.  Also
		   allows underscores and dollar signs in names.
		-- DO ... ENDDO and DO WHILE loop forms allowed.
		-- NAMELIST supported.
		-- TYPE and ACCEPT I/O statements allowed.
		-- Tabs are permitted in input, and (except in character data)
		   expand into blanks up to the next column equal to 1 mod 8.
		-- Type declarations INTEGER*2, REAL*8, etc. are allowed.
		-- IMPLICIT NONE allowed.
                -- CASE construct supported
*/


#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "ftnchek.h"
#include "symtab.h"

	/* The following section is for use with bison-derived
	   parser.  Define alloca to be malloc for those cases
	   not covered by the cases covered there.  The ifdefs
	   are those in the skeleton parser with includes removed */
#ifdef AIXC	/* IBM RS/6000 xlc compiler does it this way */
#pragma alloca
#endif
#ifndef alloca
#ifdef __GNUC__
#else /* Not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__)
#else /* Not sparc */
#ifdef MSDOS
#endif /* MSDOS */
#endif /* Not sparc.  */
#endif /* Not GNU C.  */
#define alloca malloc
#endif /* alloca now defined.  */

#ifndef YYDEBUG	/* If not declared otherwise... */
int yydebug;	/* declare yydebug to satisfy extern in ftnchek.c */
#ifdef DEVELOPMENT
#define YYDEBUG 1		/* For development it is handy */
#else
#define YYDEBUG 0
#endif
#endif

#ifdef DEVELOPMENT
#define DEBUG_PARSER
#endif

PRIVATE int current_datatype,	/* set when parse type_name or type_stmt */
    current_size_is_adjustable, /* set in CHARACTER declarations */
    current_size_is_expression, /* set in CHARACTER declarations */
    current_save_attr,	/* set if SAVE attribute given in type decl */
    current_external_attr,	/* set if EXTERNAL attr given */
    current_intrinsic_attr,	/* set if INTRINSIC attr given */
    current_parameter_attr,	/* set if PARAMETER attr given */
    current_pointer_attr,       /* set if POINTER attr given */
    current_target_attr,        /* set if TARGET attr given */
    current_allocatable_attr,   /* set if ALLOCATABLE attr given */
    label_dummy_arg_count,	/* number of labels in dummy argument list */
    len_selector_given, /* flag for use in processing CHARACTER decls */
    len_spec_item_count,/* count of items in CHARACTER len-selector list */
    control_item_count;	/* count of items in control_info_list */

PRIVATE Token *current_dim_bound_list;	/* attr-based dim bound tokenlist */

	/* Information about the current I/O statement */
int current_io_unit_id;		/* hashnum of unit id of current I/O operation */
int  current_io_unit_no;	/* unit number of current I/O operation */
IO_ACCESS_TYPE current_io_access;/* access mode (direct/sequential) */
IO_FORM_TYPE current_io_form;	/* form (formatted/unformatted) */

int io_internal_file,	/* Flag for catching misuse of internal files */
    io_list_directed,	/* Flag for use in processing io control lists */
    io_warning_given;		/* to prevent multiple warnings */
			/* Flag shared with forlex for lexing hints */
int stmt_sequence_no,   /* set when parsing, reset to 0 at end_stmt */
    f90_stmt_sequence_no;
PRIVATE long current_typesize;	/* for type*len declarations: value of len */
PRIVATE char *current_len_text;	/* for type*len declarations: text of len */

PRIVATE int kind_warning_given=FALSE; /* to say "not interpreted" only once */

PRIVATE Token save_token,	/* Holds token shared by productions */
    len_spec_token,		/* Holds character length spec temporarily */
    dim_bound_token;		/* Holds attr-based dim-bound list header */

extern LINENO_t prev_stmt_line_num; /* shared with advance */

LINENO_t true_prev_stmt_line_num;	/* shared with symtab.c */

PRIVATE int
    current_module_type,
    executable_stmt=FALSE,
    prev_stmt_class=0,		 /* flags for lexer */
    labeled_stmt_type,		 /* for label handling */
    if_line_num, if_col_num,	/* for picky construct-usage warnings */
    prev_goto=FALSE,
    goto_flag=FALSE;	/* if unconditional GOTO was encountered */

int 
    complex_const_allowed=FALSE, /* for help in lookahead for these */
    construct_name_seen=FALSE,	/* for help recognizing DO */
    param_noparen=FALSE,	/* for different PARAMETER stmt semantics */
    in_assignment_stmt=FALSE,
    in_attrbased_typedecl=FALSE,/* help is_keyword lex type, attr :: list */
    inside_format=FALSE,	/* when inside parens of FORMAT  */
    integer_context=FALSE;	/* says integers-only are to follow */


		/* Macro for initializing attributes of type decl. */
#define reset_type_attrs() (\
    current_save_attr = FALSE, \
    current_external_attr = FALSE, \
    current_intrinsic_attr = FALSE, \
    current_parameter_attr = FALSE, \
    current_pointer_attr = FALSE, \
    current_target_attr = FALSE, \
    current_allocatable_attr = FALSE, \
    current_dim_bound_list = NULL   )

			/* Define stuff for checking block nesting */

#define MAX_BLOCK_DEPTH 100	/* maximum depth of nesting blocks */

	/* USE_YYTNAME allows messages to incorporate token names from
	   the yytname array.  This option should be enabled if bison
	   is used to generate parser, not otherwise.  Enabling it
	   also assumes fortran.c has been edited to remove "tok_"
	   from token names (see Makefile).
	*/
#ifndef NO_YYTNAME
#if defined( YYDEBUG ) && defined( YYBISON )
#define USE_YYTNAME
#endif
#endif

				/* Convenience typedef for category of block */
typedef enum {subprog, construct} BLOCK_TYPE;

typedef struct {
    int sclass;			/* stmt_class of block opener */
    char *name;			/* name of block or subprogram */
    LABEL_t label;		/* label of closing statement for DO */
    LINENO_t first_line;	/* line number of block opener */
    BLOCK_TYPE blocktype;	/* category for wording of warnings */
    int do_var_hash;		/* hash index for index variable of DO block */
} BlockStack;

PRIVATE BlockStack block_stack[MAX_BLOCK_DEPTH];

PRIVATE char *
    curr_stmt_name;	/* subprog or END-subprog name; DO, IF construct name*/

PRIVATE int
    block_depth=0;		/* depth of nesting of current block */

				/* Defns of private functions */

PROTO(PRIVATE void push_block,(Token *t, int stmt_class, BLOCK_TYPE blocktype,
			       char *name, LABEL_t label));
PROTO(PRIVATE void pop_block,(Token *t, int stmt_class,
			      char *name, LABEL_t label));
PROTO(PRIVATE void check_construct_name_match,(Token *stmt, char *name));

PROTO(PRIVATE Token * add_tree_node,( Token *node, Token *left, Token *right ));
PROTO(PRIVATE Token * append_token,( Token *tlist, Token *t ));
PROTO(PRIVATE void check_stmt_sequence,( Token *t, int seq_num ));
PROTO(PRIVATE void check_f90_stmt_sequence,( Token *t, int f90_seq_num ));
PROTO(PRIVATE void do_binexpr,( Token *l_expr, Token *op, Token *r_expr,
			Token *result ));
PROTO(PRIVATE int do_bounds_type,( Token *t1, Token *t2, Token *t3 ));
PROTO(PRIVATE void do_unexpr,( Token *op, Token *expr, Token *result ));
PROTO(PRIVATE Token * empty_token,( Token *t ));
PROTO(PRIVATE void END_processing,( Token *t ));
PROTO(PRIVATE void init_io_ctrl_list,( void ));
PROTO(PRIVATE void record_default_io,( void ));
PROTO(PRIVATE void process_attrs,(Token *t,Token *dim_bounds));
PROTO(PRIVATE void give_kind_warning,(Token *t));
#ifdef DEBUG_PARSER
PROTO(PRIVATE void print_exprlist,( char *s, Token *t ));
PROTO(PRIVATE void print_comlist,( char *s, Token *t ));
#endif

		/* Uses of Token fields for nonterminals: */
/* NOTE: As of Aug 1994 these are undergoing revision to separate the
         use of class, subclass fields */
/*
  1. dim_bound_lists: dimensioning info for arrays:
       token.class = no. of dimensions,  --> TOK_dims
       token.subclass = no. of elements  --> TOK_elts
  2. expressions
       token.value.integer = hash index (of identifier)
       token.TOK_type = type_byte = storage_class << 4 + datatype
       token.TOK_flags: CONST_EXPR, LVALUE_EXPR, etc.
       token.TOK_flags: COMMA_FLAG used to handle extra/missing commas
  4. substring_interval
       token.class = start index  --> TOK_start
       token.subclass = end index --> TOK_end
*/




/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
typedef int YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 214 of yacc.c.  */
#line 536 "y.tab.c"

#if ! defined (yyoverflow) || YYERROR_VERBOSE

# ifndef YYFREE
#  define YYFREE free
# endif
# ifndef YYMALLOC
#  define YYMALLOC malloc
# endif

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   define YYSTACK_ALLOC alloca
#  endif
# else
#  if defined (alloca) || defined (_ALLOCA_H)
#   define YYSTACK_ALLOC alloca
#  else
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow)      && (! defined (__cplusplus) 	 || (defined (YYSTYPE_IS_TRIVIAL) && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined (__GNUC__) && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  325
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1926

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  114
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  308
/* YYNRULES -- Number of rules. */
#define YYNRULES  611
/* YYNRULES -- Number of states. */
#define YYNSTATES  1041

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   354

#define YYTRANSLATE(YYX) 						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,   110,     2,     2,     2,
     102,   100,   104,   111,   103,   108,   109,   106,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   105,     2,
     112,   107,   113,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,    99,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,   101
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short yyprhs[] =
{
       0,     0,     3,     5,     6,     8,    11,    13,    15,    17,
      19,    21,    24,    26,    28,    30,    32,    34,    37,    39,
      41,    43,    45,    47,    50,    52,    54,    57,    60,    64,
      66,    68,    70,    72,    76,    78,    80,    82,    84,    86,
      88,    90,    92,    94,    96,    98,   100,   102,   104,   106,
     108,   110,   112,   114,   116,   118,   120,   122,   124,   126,
     128,   130,   132,   134,   136,   138,   140,   142,   144,   146,
     148,   150,   152,   154,   156,   158,   160,   162,   164,   166,
     168,   170,   172,   174,   176,   178,   180,   182,   184,   186,
     188,   190,   192,   194,   196,   198,   200,   202,   204,   205,
     210,   214,   221,   223,   227,   234,   238,   245,   248,   250,
     252,   254,   256,   258,   260,   264,   271,   273,   274,   276,
     278,   282,   284,   286,   289,   293,   295,   299,   301,   305,
     310,   312,   316,   318,   322,   324,   328,   330,   331,   336,
     340,   346,   350,   354,   356,   358,   360,   365,   368,   371,
     375,   379,   384,   386,   389,   392,   396,   399,   401,   403,
     406,   408,   411,   413,   415,   419,   421,   424,   427,   431,
     433,   436,   438,   441,   445,   449,   453,   458,   464,   470,
     472,   476,   478,   482,   484,   488,   490,   494,   499,   501,
     503,   505,   507,   509,   511,   513,   515,   519,   524,   526,
     528,   530,   532,   534,   536,   538,   540,   542,   546,   548,
     551,   554,   555,   560,   562,   564,   568,   570,   571,   572,
     579,   580,   585,   587,   588,   589,   596,   598,   600,   604,
     606,   607,   608,   615,   619,   621,   625,   626,   627,   634,
     635,   636,   645,   647,   651,   653,   657,   661,   663,   664,
     669,   670,   676,   678,   682,   684,   688,   690,   694,   696,
     700,   702,   706,   708,   710,   712,   714,   720,   721,   722,
     728,   730,   734,   735,   740,   744,   746,   750,   754,   756,
     760,   764,   768,   772,   774,   778,   782,   784,   786,   790,
     792,   796,   802,   804,   806,   808,   814,   820,   822,   826,
     828,   833,   837,   841,   843,   847,   849,   854,   858,   862,
     868,   870,   874,   877,   881,   883,   887,   889,   893,   897,
     899,   902,   906,   907,   908,   915,   917,   921,   923,   925,
     927,   931,   933,   937,   939,   941,   943,   945,   947,   951,
     953,   955,   963,   967,   973,   974,   975,   982,   984,   986,
     988,   990,   992,   994,  1001,  1006,  1013,  1021,  1025,  1032,
    1040,  1042,  1045,  1050,  1061,  1064,  1068,  1070,  1073,  1074,
    1080,  1081,  1082,  1091,  1094,  1098,  1101,  1105,  1108,  1112,
    1113,  1120,  1122,  1125,  1128,  1132,  1137,  1139,  1143,  1145,
    1149,  1152,  1155,  1157,  1160,  1164,  1167,  1171,  1177,  1178,
    1185,  1186,  1194,  1197,  1199,  1202,  1206,  1211,  1214,  1218,
    1224,  1227,  1231,  1234,  1236,  1238,  1241,  1245,  1248,  1252,
    1256,  1260,  1261,  1263,  1265,  1267,  1268,  1272,  1273,  1278,
    1279,  1285,  1291,  1298,  1306,  1310,  1316,  1318,  1322,  1328,
    1332,  1333,  1334,  1342,  1346,  1347,  1348,  1356,  1358,  1362,
    1366,  1368,  1370,  1374,  1378,  1382,  1384,  1386,  1390,  1392,
    1394,  1402,  1403,  1410,  1411,  1418,  1419,  1426,  1430,  1436,
    1438,  1442,  1448,  1450,  1454,  1460,  1462,  1464,  1466,  1468,
    1470,  1471,  1478,  1479,  1481,  1483,  1486,  1488,  1490,  1492,
    1496,  1498,  1500,  1502,  1504,  1506,  1508,  1510,  1512,  1514,
    1516,  1518,  1520,  1522,  1525,  1528,  1529,  1530,  1536,  1541,
    1542,  1544,  1546,  1550,  1552,  1553,  1557,  1558,  1564,  1565,
    1572,  1575,  1577,  1581,  1583,  1587,  1590,  1594,  1599,  1601,
    1602,  1604,  1606,  1610,  1612,  1614,  1616,  1620,  1624,  1626,
    1630,  1632,  1636,  1638,  1641,  1643,  1647,  1649,  1652,  1655,
    1659,  1663,  1665,  1669,  1673,  1675,  1679,  1681,  1685,  1687,
    1689,  1691,  1693,  1695,  1699,  1701,  1703,  1705,  1707,  1709,
    1711,  1713,  1715,  1717,  1719,  1721,  1723,  1725,  1727,  1732,
    1737,  1739,  1743,  1745,  1748,  1751,  1754,  1757,  1760,  1764,
    1769,  1774,  1780,  1782,  1784,  1786,  1788,  1790,  1792,  1794,
    1797,  1799,  1801,  1803,  1806,  1809,  1811,  1813,  1815,  1817,
    1819,  1820
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short yyrhs[] =
{
     115,     0,    -1,   116,    -1,    -1,   117,    -1,   116,   117,
      -1,   118,    -1,   127,    -1,    99,    -1,   119,    -1,   122,
      -1,     5,   120,    -1,   120,    -1,   121,    -1,   128,    -1,
     131,    -1,   136,    -1,     1,    99,    -1,   140,    -1,   143,
      -1,   149,    -1,   155,    -1,   123,    -1,     5,   123,    -1,
     124,    -1,   125,    -1,    51,    99,    -1,   126,    99,    -1,
     126,   414,    99,    -1,    52,    -1,    55,    -1,    57,    -1,
      59,    -1,    69,    13,    99,    -1,   129,    -1,   226,    -1,
     215,    -1,   259,    -1,   130,    -1,   142,    -1,   356,    -1,
     157,    -1,   162,    -1,   169,    -1,   176,    -1,   182,    -1,
     183,    -1,   234,    -1,   236,    -1,   256,    -1,   243,    -1,
     240,    -1,   239,    -1,   238,    -1,   132,    -1,   133,    -1,
     280,    -1,   282,    -1,   285,    -1,   315,    -1,   318,    -1,
     380,    -1,   274,    -1,   279,    -1,   373,    -1,   281,    -1,
     314,    -1,   319,    -1,   134,    -1,   248,    -1,   249,    -1,
     254,    -1,   326,    -1,   328,    -1,   321,    -1,   329,    -1,
     332,    -1,   342,    -1,   344,    -1,   346,    -1,   135,    -1,
     352,    -1,   348,    -1,   350,    -1,   137,    -1,   138,    -1,
     297,    -1,   139,    -1,   286,    -1,   287,    -1,   307,    -1,
     313,    -1,   291,    -1,   295,    -1,   296,    -1,   300,    -1,
     305,    -1,   306,    -1,    -1,    82,   141,   414,    99,    -1,
      60,   414,    99,    -1,    60,   414,   102,   152,   100,    99,
      -1,   144,    -1,   145,   414,    99,    -1,   145,   414,   102,
     152,   100,    99,    -1,   146,   414,    99,    -1,   146,   414,
     102,   152,   100,    99,    -1,   148,   147,    -1,   147,    -1,
      65,    -1,   188,    -1,   192,    -1,   193,    -1,   150,    -1,
     151,   414,    99,    -1,   151,   414,   102,   152,   100,    99,
      -1,    90,    -1,    -1,   153,    -1,   154,    -1,   153,   103,
     154,    -1,   414,    -1,   104,    -1,   156,    99,    -1,   156,
     414,    99,    -1,    32,    -1,    45,   158,    99,    -1,   159,
      -1,   158,   103,   159,    -1,   414,   102,   160,   100,    -1,
     161,    -1,   160,   103,   161,    -1,   402,    -1,   402,   105,
     402,    -1,   104,    -1,   402,   105,   104,    -1,   105,    -1,
      -1,    61,   163,   164,    99,    -1,   102,   165,   100,    -1,
     164,   103,   102,   165,   100,    -1,   166,   103,   166,    -1,
     165,   103,   166,    -1,   414,    -1,   167,    -1,   168,    -1,
     414,   102,   405,   100,    -1,   414,   409,    -1,   167,   409,
      -1,    39,   173,    99,    -1,    39,   170,    99,    -1,    39,
     173,   170,    99,    -1,   171,    -1,   170,   171,    -1,   172,
     173,    -1,   106,   414,   106,    -1,   106,   106,    -1,    24,
      -1,   174,    -1,   173,   174,    -1,   175,    -1,   175,   103,
      -1,   414,    -1,   159,    -1,    74,   177,    99,    -1,   178,
      -1,   177,   178,    -1,   179,   180,    -1,   106,   414,   106,
      -1,   181,    -1,   180,   181,    -1,   414,    -1,   414,   103,
      -1,   188,   197,    99,    -1,   192,   205,    99,    -1,   193,
     205,    99,    -1,   193,   103,   205,    99,    -1,   184,   105,
     105,   197,    99,    -1,   185,   105,   105,   205,    99,    -1,
     188,    -1,   188,   103,   186,    -1,   192,    -1,   192,   103,
     186,    -1,   193,    -1,   193,   103,   186,    -1,   187,    -1,
     186,   103,   187,    -1,    45,   102,   160,   100,    -1,    87,
      -1,    62,    -1,    72,    -1,    78,    -1,    80,    -1,    91,
      -1,    28,    -1,   189,    -1,   189,   104,   418,    -1,   189,
     196,   191,   100,    -1,   190,    -1,    71,    -1,    84,    -1,
      40,    -1,    73,    -1,    48,    -1,    47,    -1,    33,    -1,
     386,    -1,   414,   107,   386,    -1,    37,    -1,   192,   194,
      -1,   104,   222,    -1,    -1,   196,   195,   223,   100,    -1,
      25,    -1,   198,    -1,   197,   103,   198,    -1,   204,    -1,
      -1,    -1,   204,   106,   199,   266,   200,   106,    -1,    -1,
     204,   201,   107,   385,    -1,   159,    -1,    -1,    -1,   159,
     106,   202,   266,   203,   106,    -1,   414,    -1,   206,    -1,
     205,   103,   206,    -1,   213,    -1,    -1,    -1,   213,   106,
     207,   266,   208,   106,    -1,   213,   107,   385,    -1,   159,
      -1,   159,   104,   222,    -1,    -1,    -1,   159,   106,   209,
     266,   210,   106,    -1,    -1,    -1,   159,   104,   222,   106,
     211,   266,   212,   106,    -1,   414,    -1,   414,   104,   222,
      -1,    68,    -1,   214,   216,    99,    -1,   214,    75,    99,
      -1,   218,    -1,    -1,   216,   103,   217,   218,    -1,    -1,
     148,   102,   219,   220,   100,    -1,   221,    -1,   220,   103,
     221,    -1,    16,    -1,    16,   108,    16,    -1,   419,    -1,
     102,   225,   100,    -1,   224,    -1,   223,   103,   224,    -1,
     225,    -1,   414,   107,   225,    -1,   104,    -1,   401,    -1,
     227,    -1,   228,    -1,    78,   102,   231,   100,    99,    -1,
      -1,    -1,    78,   229,   231,   230,    99,    -1,   232,    -1,
     231,   103,   232,    -1,    -1,   414,   233,   107,   385,    -1,
      62,   235,    99,    -1,   414,    -1,   235,   103,   414,    -1,
      72,   237,    99,    -1,   414,    -1,   237,   103,   414,    -1,
      28,   241,    99,    -1,    91,   241,    99,    -1,    80,   241,
      99,    -1,   242,    -1,   105,   105,   242,    -1,   241,   103,
     242,    -1,   414,    -1,   159,    -1,    80,   244,    99,    -1,
     245,    -1,   244,   103,   245,    -1,   102,   246,   103,   247,
     100,    -1,   414,    -1,   414,    -1,   159,    -1,    29,   102,
     250,   100,    99,    -1,    44,   102,   252,   100,    99,    -1,
     251,    -1,   250,   103,   251,    -1,   411,    -1,   413,   102,
     160,   100,    -1,   414,   107,   411,    -1,   414,   107,   404,
      -1,   253,    -1,   252,   103,   251,    -1,   411,    -1,   413,
     102,   160,   100,    -1,   414,   107,   411,    -1,   414,   107,
     404,    -1,    76,   102,   255,   100,    99,    -1,   411,    -1,
     255,   103,   411,    -1,    87,    99,    -1,    87,   257,    99,
      -1,   258,    -1,   257,   103,   258,    -1,   414,    -1,   106,
     414,   106,    -1,    43,   260,    99,    -1,   261,    -1,   260,
     261,    -1,   260,   103,   261,    -1,    -1,    -1,   264,   106,
     262,   266,   263,   106,    -1,   265,    -1,   264,   103,   265,
      -1,   277,    -1,   272,    -1,   267,    -1,   266,   103,   267,
      -1,   269,    -1,   268,   104,   269,    -1,   418,    -1,   414,
      -1,   417,    -1,   414,    -1,   271,    -1,   270,   103,   271,
      -1,   403,    -1,   272,    -1,   102,   270,   103,   414,   107,
     273,   100,    -1,   401,   103,   401,    -1,   401,   103,   401,
     103,   401,    -1,    -1,    -1,   277,   278,   275,   386,   276,
      99,    -1,   411,    -1,   403,    -1,   408,    -1,   369,    -1,
     107,    -1,    26,    -1,    30,   420,   421,    93,   411,    99,
      -1,   283,   420,   421,    99,    -1,   283,   102,   284,   100,
     399,    99,    -1,   283,   102,   284,   100,   103,   399,    99,
      -1,   283,   414,    99,    -1,   283,   414,   102,   284,   100,
      99,    -1,   283,   414,   103,   102,   284,   100,    99,    -1,
      66,    -1,   420,   421,    -1,   284,   103,   420,   421,    -1,
     288,   420,   421,   103,   420,   421,   103,   420,   421,    99,
      -1,   288,   131,    -1,   288,    92,    99,    -1,   289,    -1,
     415,   289,    -1,    -1,    67,   102,   290,   386,   100,    -1,
      -1,    -1,    50,    67,   102,   292,   386,   100,   293,   294,
      -1,    92,    99,    -1,    92,   416,    99,    -1,    50,    99,
      -1,    50,   416,    99,    -1,    56,    99,    -1,    56,   416,
      99,    -1,    -1,   299,   102,   298,   386,   100,    99,    -1,
      88,    -1,   415,    88,    -1,   301,    99,    -1,   301,   416,
      99,    -1,    35,   102,   302,   100,    -1,   303,    -1,   302,
     103,   303,    -1,   304,    -1,   304,   105,   304,    -1,   105,
     304,    -1,   304,   105,    -1,   386,    -1,    36,    99,    -1,
      36,   416,    99,    -1,    58,    99,    -1,    58,   416,    99,
      -1,   310,   411,   107,   312,    99,    -1,    -1,    49,   102,
     308,   386,   100,    99,    -1,    -1,   310,    95,   102,   309,
     386,   100,    99,    -1,   310,    99,    -1,   311,    -1,   415,
     311,    -1,    46,   420,   421,    -1,    46,   420,   421,   103,
      -1,    46,   420,    -1,   400,   103,   400,    -1,   400,   103,
     400,   103,   400,    -1,    53,    99,    -1,    53,   416,    99,
      -1,    41,    99,    -1,   316,    -1,   317,    -1,    42,    99,
      -1,    42,   416,    99,    -1,    63,    99,    -1,    63,   416,
      99,    -1,    89,   320,    99,    -1,    79,   320,    99,    -1,
      -1,     6,    -1,   414,    -1,    13,    -1,    -1,   324,   322,
      99,    -1,    -1,   324,   339,   323,    99,    -1,    -1,    96,
     325,   102,   335,   100,    -1,   327,   102,   335,   100,    99,
      -1,   327,   102,   335,   100,   339,    99,    -1,   327,   102,
     335,   100,   103,   339,    99,    -1,   327,   355,    99,    -1,
     327,   355,   103,   339,    99,    -1,    83,    -1,    27,   355,
      99,    -1,    27,   355,   103,   339,    99,    -1,    81,   355,
      99,    -1,    -1,    -1,    81,   355,   103,   330,   339,   331,
      99,    -1,    94,   355,    99,    -1,    -1,    -1,    94,   355,
     103,   333,   339,   334,    99,    -1,   336,    -1,   335,   103,
     336,    -1,   414,   107,   354,    -1,   354,    -1,   354,    -1,
     414,   107,   354,    -1,   337,   103,   338,    -1,   414,   107,
     354,    -1,   414,    -1,   340,    -1,   339,   103,   340,    -1,
     386,    -1,   341,    -1,   102,   339,   103,   411,   107,   312,
     100,    -1,    -1,    77,   343,   102,   337,   100,    99,    -1,
      -1,    38,   345,   102,   335,   100,    99,    -1,    -1,    70,
     347,   102,   335,   100,    99,    -1,   349,   354,    99,    -1,
     349,   102,   335,   100,    99,    -1,    31,    -1,   351,   354,
      99,    -1,   351,   102,   335,   100,    99,    -1,    54,    -1,
     353,   354,    99,    -1,   353,   102,   335,   100,    99,    -1,
      86,    -1,   386,    -1,   104,    -1,   395,    -1,   104,    -1,
      -1,    64,   357,   102,   358,   100,    99,    -1,    -1,   359,
      -1,   360,    -1,   359,   360,    -1,   361,    -1,   362,    -1,
     363,    -1,   102,   359,   100,    -1,    15,    -1,    13,    -1,
      14,    -1,   365,    -1,   366,    -1,   103,    -1,   106,    -1,
      24,    -1,   105,    -1,   109,    -1,   364,    -1,   110,    -1,
       6,    -1,   108,     6,    -1,   111,     6,    -1,    -1,    -1,
     112,   367,   399,   368,   113,    -1,   412,   102,   370,   100,
      -1,    -1,   371,    -1,   372,    -1,   371,   103,   372,    -1,
     411,    -1,    -1,   377,   374,    99,    -1,    -1,   377,   102,
     100,   375,    99,    -1,    -1,   377,   102,   378,   100,   376,
      99,    -1,    34,   414,    -1,   379,    -1,   378,   103,   379,
      -1,   386,    -1,   104,   420,   421,    -1,    85,    99,    -1,
      85,   399,    99,    -1,   382,   102,   383,   100,    -1,   412,
      -1,    -1,   384,    -1,   386,    -1,   384,   103,   386,    -1,
     386,    -1,   387,    -1,   388,    -1,   386,    20,   388,    -1,
     386,    21,   388,    -1,   389,    -1,   388,    19,   389,    -1,
     390,    -1,   389,    18,   390,    -1,   391,    -1,    22,   391,
      -1,   392,    -1,   391,    17,   391,    -1,   393,    -1,   108,
     393,    -1,   111,   393,    -1,   392,   111,   393,    -1,   392,
     108,   393,    -1,   394,    -1,   393,   106,   394,    -1,   393,
     104,   394,    -1,   395,    -1,   395,    23,   394,    -1,   396,
      -1,   395,    24,   396,    -1,   411,    -1,   404,    -1,   381,
      -1,   407,    -1,   397,    -1,   102,   386,   100,    -1,   398,
      -1,    13,    -1,    14,    -1,    12,    -1,     6,    -1,     7,
      -1,     8,    -1,     9,    -1,    10,    -1,    11,    -1,   392,
      -1,   392,    -1,   392,    -1,   392,    -1,   413,   102,   405,
     100,    -1,   413,   102,   405,   100,    -1,   406,    -1,   405,
     103,   406,    -1,   386,    -1,   382,   409,    -1,   381,   409,
      -1,   404,   409,    -1,   412,   409,    -1,   403,   409,    -1,
     102,   105,   100,    -1,   102,   410,   105,   100,    -1,   102,
     105,   410,   100,    -1,   102,   410,   105,   410,   100,    -1,
     392,    -1,   412,    -1,   413,    -1,     3,    -1,     4,    -1,
       3,    -1,     4,    -1,   416,   105,    -1,     3,    -1,     4,
      -1,   398,    -1,   108,   398,    -1,   111,   398,    -1,    12,
      -1,    13,    -1,    14,    -1,     6,    -1,     6,    -1,    -1,
       6,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short yyrline[] =
{
       0,   374,   374,   375,   378,   379,   383,   440,   441,   449,
     450,   457,   495,   514,   523,   528,   544,   552,   569,   573,
     577,   581,   587,   588,   605,   610,   613,   614,   617,   623,
     624,   625,   626,   629,   648,   658,   674,   680,   693,   701,
     706,   712,   713,   714,   715,   716,   717,   718,   719,   720,
     721,   722,   723,   724,   730,   735,   741,   742,   749,   756,
     761,   762,   765,   766,   767,   768,   769,   770,   771,   775,
     776,   777,   780,   790,   791,   798,   799,   800,   815,   816,
     817,   824,   825,   826,   830,   834,   839,   844,   852,   853,
     862,   881,   896,   901,   906,   912,   917,   922,   929,   929,
     947,   952,   964,   968,   985,  1001,  1018,  1036,  1042,  1045,
    1051,  1052,  1053,  1060,  1064,  1075,  1093,  1100,  1103,  1106,
    1110,  1116,  1121,  1134,  1151,  1164,  1171,  1174,  1175,  1179,
    1185,  1192,  1200,  1208,  1220,  1225,  1231,  1241,  1241,  1245,
    1246,  1249,  1253,  1260,  1264,  1268,  1274,  1278,  1279,  1283,
    1297,  1305,  1323,  1327,  1335,  1348,  1353,  1357,  1363,  1368,
    1381,  1386,  1393,  1398,  1411,  1423,  1424,  1430,  1437,  1443,
    1447,  1460,  1466,  1475,  1476,  1477,  1478,  1482,  1490,  1500,
    1501,  1504,  1505,  1506,  1507,  1511,  1512,  1515,  1522,  1526,
    1530,  1534,  1538,  1542,  1546,  1553,  1560,  1589,  1598,  1604,
    1609,  1614,  1619,  1626,  1633,  1643,  1659,  1668,  1690,  1703,
    1726,  1737,  1737,  1766,  1773,  1774,  1779,  1790,  1792,  1789,
    1807,  1807,  1828,  1840,  1842,  1839,  1860,  1870,  1871,  1874,
    1883,  1885,  1882,  1896,  1910,  1920,  1934,  1936,  1933,  1953,
    1955,  1952,  1976,  1986,  2003,  2006,  2019,  2035,  2036,  2036,
    2042,  2042,  2046,  2047,  2050,  2070,  2099,  2106,  2137,  2141,
    2147,  2164,  2190,  2197,  2219,  2220,  2223,  2226,  2227,  2226,
    2236,  2237,  2240,  2240,  2251,  2254,  2258,  2265,  2268,  2272,
    2279,  2289,  2299,  2308,  2309,  2310,  2313,  2317,  2326,  2334,
    2335,  2338,  2341,  2348,  2355,  2362,  2371,  2380,  2381,  2384,
    2385,  2386,  2387,  2390,  2391,  2394,  2395,  2396,  2397,  2400,
    2409,  2410,  2414,  2418,  2421,  2422,  2425,  2429,  2437,  2440,
    2441,  2442,  2446,  2448,  2445,  2452,  2453,  2456,  2460,  2463,
    2467,  2473,  2477,  2489,  2490,  2496,  2497,  2504,  2505,  2508,
    2512,  2515,  2522,  2523,  2528,  2530,  2528,  2570,  2571,  2572,
    2573,  2576,  2577,  2588,  2603,  2612,  2613,  2617,  2621,  2625,
    2631,  2642,  2646,  2653,  2670,  2680,  2699,  2703,  2714,  2714,
    2729,  2730,  2729,  2747,  2751,  2761,  2765,  2775,  2779,  2796,
    2796,  2813,  2824,  2833,  2834,  2837,  2840,  2841,  2844,  2845,
    2858,  2866,  2876,  2893,  2894,  2897,  2898,  2910,  2960,  2959,
    2974,  2973,  2983,  2990,  2999,  3010,  3017,  3023,  3031,  3035,
    3041,  3045,  3049,  3054,  3061,  3070,  3071,  3074,  3075,  3079,
    3083,  3092,  3093,  3094,  3098,  3103,  3102,  3105,  3104,  3108,
    3108,  3117,  3118,  3119,  3120,  3124,  3129,  3132,  3138,  3147,
    3152,  3153,  3151,  3159,  3166,  3167,  3165,  3176,  3180,  3202,
    3206,  3269,  3281,  3286,  3292,  3296,  3303,  3304,  3307,  3329,
    3333,  3348,  3348,  3353,  3353,  3358,  3358,  3363,  3371,  3373,
    3377,  3385,  3387,  3391,  3399,  3401,  3409,  3410,  3414,  3432,
    3436,  3436,  3443,  3444,  3448,  3449,  3452,  3453,  3454,  3457,
    3458,  3461,  3462,  3469,  3470,  3473,  3474,  3475,  3476,  3477,
    3478,  3485,  3488,  3489,  3490,  3494,  3495,  3494,  3504,  3520,
    3523,  3526,  3530,  3537,  3542,  3541,  3548,  3547,  3554,  3553,
    3564,  3570,  3575,  3581,  3588,  3597,  3601,  3637,  3665,  3676,
    3681,  3684,  3689,  3698,  3727,  3742,  3744,  3749,  3756,  3758,
    3765,  3767,  3774,  3776,  3782,  3784,  3792,  3794,  3798,  3802,
    3807,  3814,  3816,  3826,  3833,  3835,  3842,  3844,  3851,  3855,
    3857,  3859,  3861,  3871,  3895,  3897,  3902,  3911,  3918,  3923,
    3928,  3933,  3942,  3947,  3955,  3969,  3989,  4013,  4047,  4063,
    4079,  4083,  4089,  4103,  4118,  4126,  4135,  4141,  4150,  4164,
    4174,  4184,  4196,  4217,  4222,  4225,  4232,  4241,  4242,  4246,
    4254,  4258,  4266,  4267,  4268,  4269,  4274,  4279,  4290,  4310,
    4335,  4341
};
#endif

#if YYDEBUG || YYERROR_VERBOSE
/* YYTNME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "identifier", "array identifier",
  "label", "integer const", "real const", "dp const",
  "quad const", "complex const", "dcomplex const",
  "logical const", "string", "hollerith",
  "edit descriptor", "letter", "relop", "AND", "OR",
  "EQV", "NEQV", "NOT", "power", "concat",
  "lparen", "pointer assignment", "ACCEPT", "ALLOCATABLE",
  "ALLOCATE", "ASSIGN", "BACKSPACE", "BLOCKDATA",
  "BYTE", "CALL", "CASE", "CASEDEFAULT", "CHARACTER",
  "CLOSE", "COMMON", "COMPLEX", "CONTINUE", "CYCLE",
  "DATA", "DEALLOCATE", "DIMENSION", "DO",
  "DOUBLECOMPLEX", "DOUBLEPRECISION", "DOWHILE", "ELSE",
  "END", "ENDBLOCKDATA", "ENDDO", "ENDFILE",
  "ENDFUNCTION", "ENDIF", "ENDPROGRAM", "ENDSELECT",
  "ENDSUBROUTINE", "ENTRY", "EQUIVALENCE", "EXTERNAL",
  "EXIT", "FORMAT", "FUNCTION", "GOTO", "IF",
  "IMPLICIT", "INCLUDE", "INQUIRE", "INTEGER",
  "INTRINSIC", "LOGICAL", "NAMELIST", "NONE",
  "NULLIFY", "OPEN", "PARAMETER", "PAUSE", "POINTER",
  "PRINT", "PROGRAM", "READ", "REAL", "RETURN",
  "REWIND", "SAVE", "SELECTCASE", "STOP", "SUBROUTINE",
  "TARGET", "THEN", "TO", "TYPE", "WHILE", "WRITE",
  "illegal", "empty", "end of statement", "')'", "REDUCE", "'('", "','", "'*'",
  "':'", "'/'", "'='", "'-'", "'.'", "'$'", "'+'", "'<'", "'>'", "$accept",
  "prog body", "stmt list", "stmt list item", "ordinary stmt", "stmt",
  "unlabeled stmt", "subprogram header", "end stmt", "unlabeled end stmt",
  "unnamed end stmt", "named end stmt", "end subprog token",
  "include stmt", "specification stmt", "anywhere stmt", "specif stmt",
  "executable stmt", "transfer stmt", "nontransfer stmt", "io stmt",
  "io positioning stmt", "restricted stmt", "restricted nontransfer stmt",
  "else or endif stmt", "case or endselect stmt", "prog stmt", "@1",
  "entry stmt", "function stmt", "unlabeled function stmt",
  "typed function handle", "plain function handle", "function keyword",
  "type name", "subroutine stmt", "unlabeled subroutine stmt",
  "subroutine handle", "dummy argument list", "non empty arg list",
  "dummy argument", "block data stmt", "block data handle",
  "dimension stmt", "array declarator list", "array declarator",
  "dim bound list", "dim bound item", "equivalence stmt", "@2",
  "equivalence list", "equivalence list item", "equiv entity",
  "array equiv name", "substring equiv name", "common stmt",
  "common block list", "labeled common block", "common block name",
  "common variable list", "common list item", "common entity",
  "namelist stmt", "namelist list", "namelist decl", "namelist name",
  "namelist var list", "namelist item", "type stmt", "attrbased type stmt",
  "arith attrbased type handle", "char attrbased type handle", "attr list",
  "type attr", "arith type name", "sizeable type name",
  "unsizeable type name", "kind selector", "plain char type name",
  "char type name", "char selector", "@3", "left paren",
  "arith type decl list", "arith type decl item", "@4", "@5", "@6", "@7",
  "@8", "scalar type decl entity", "char type decl list",
  "char type decl item", "@9", "@10", "@11", "@12", "@13", "@14",
  "char type decl entity", "implicit handle", "implicit stmt",
  "implicit decl list", "@15", "implicit decl item", "@16", "letter list",
  "letter list item", "len specification", "len spec list",
  "len spec item", "len spec expr", "parameter stmt", "std parameter stmt",
  "parenless parameter stmt", "@17", "@18", "parameter defn list",
  "parameter defn item", "@19", "external stmt", "external name list",
  "intrinsic stmt", "intrinsic name list", "allocatable stmt",
  "target stmt", "pointer stmt", "attr decl list", "attr decl item",
  "cray pointer stmt", "cray pointer item list", "cray pointer item",
  "pointer name", "pointee name", "allocate stmt", "deallocate stmt",
  "allocate item list", "allocate item", "deallocate item list",
  "deallocate item", "nullify stmt", "variable name list", "save stmt",
  "save list", "save item", "data stmt", "data defn list",
  "data defn item", "@20", "@21", "data defn assignee list",
  "data defn assignee", "data value list", "data value",
  "data repeat factor", "data constant value", "data dlist",
  "data dlist item", "data implied do list", "data do loop bounds",
  "assignment stmt", "@22", "@23", "lvalue", "assignment op",
  "assign stmt", "unconditional goto", "computed goto", "assigned goto",
  "goto", "goto list", "arithmetic if stmt", "logical if stmt",
  "block if stmt", "if handle", "f77 if handle", "@24", "else if stmt",
  "@25", "@26", "else if then", "else stmt", "end if stmt",
  "select case stmt", "@27", "select handle", "case stmt", "case handle",
  "case values", "case value", "case value primary", "case default stmt",
  "end select stmt", "do stmt", "@28", "@29", "do handle", "f77 do handle",
  "do loop bounds", "enddo stmt", "continue stmt", "cycle or exit stmt",
  "cycle stmt", "exit stmt", "stop stmt", "pause stmt", "stop info",
  "write stmt", "@30", "@31", "write handle", "@32", "read stmt",
  "read handle", "accept stmt", "print stmt", "@33", "@34",
  "type output stmt", "@35", "@36", "control info list",
  "control info item", "open info list", "open info item", "io list",
  "io item", "io implied do list", "open stmt", "@37", "close stmt", "@38",
  "inquire stmt", "@39", "backspace stmt", "backspace handle",
  "endfile stmt", "endfile handle", "rewind stmt", "rewind handle",
  "unit id", "format id", "format stmt", "@40", "format spec",
  "nonempty format spec", "fmt spec item", "repeatable fmt item",
  "unrepeatable fmt item", "fmt item separator", "nonstandard fmt item",
  "repeat spec", "variable fmt item", "@41", "@42", "stmt function handle",
  "stmt function dummy list", "nonempty stmt fun dummy list",
  "stmt function dummy arg", "call stmt", "@43", "@44", "@45",
  "call handle", "subr arg list", "subr arg", "return stmt",
  "function reference", "fun or substr handle", "fun arg list",
  "nonempty fun arg list", "parameter expr", "expr", "log expr",
  "log disjunct", "log term", "log factor", "log primary", "arith expr",
  "term", "factor", "char expr", "primary", "literal const",
  "numeric const", "integer expr", "int real dp expr", "int constant expr",
  "dim bound expr", "array element lvalue", "array element name",
  "subscript list", "subscript", "substring name", "substring lvalue",
  "substring interval", "substr index expr", "variable name",
  "scalar name", "array name", "symbolic name", "construct spec",
  "construct name", "data constant", "nonzero unsigned int const",
  "nonneg unsigned int const", "pre label", "label", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   127,
      41,   354,    40,    44,    42,    58,    47,    61,    45,    46,
      36,    43,    60,    62
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned short yyr1[] =
{
       0,   114,   115,   115,   116,   116,   117,   117,   117,   118,
     118,   119,   119,   120,   120,   120,   120,   120,   121,   121,
     121,   121,   122,   122,   123,   123,   124,   124,   125,   126,
     126,   126,   126,   127,   128,   128,   128,   128,   128,   129,
     129,   130,   130,   130,   130,   130,   130,   130,   130,   130,
     130,   130,   130,   130,   131,   131,   132,   132,   132,   132,
     132,   132,   133,   133,   133,   133,   133,   133,   133,   133,
     133,   133,   134,   134,   134,   134,   134,   134,   134,   134,
     134,   135,   135,   135,   136,   136,   136,   136,   137,   137,
     137,   137,   138,   138,   138,   139,   139,   139,   141,   140,
     142,   142,   143,   144,   144,   144,   144,   145,   146,   147,
     148,   148,   148,   149,   150,   150,   151,   152,   152,   153,
     153,   154,   154,   155,   155,   156,   157,   158,   158,   159,
     160,   160,   161,   161,   161,   161,   161,   163,   162,   164,
     164,   165,   165,   166,   166,   166,   167,   168,   168,   169,
     169,   169,   170,   170,   171,   172,   172,   172,   173,   173,
     174,   174,   175,   175,   176,   177,   177,   178,   179,   180,
     180,   181,   181,   182,   182,   182,   182,   183,   183,   184,
     184,   185,   185,   185,   185,   186,   186,   187,   187,   187,
     187,   187,   187,   187,   187,   188,   188,   188,   188,   189,
     189,   189,   189,   190,   190,   190,   191,   191,   192,   193,
     194,   195,   194,   196,   197,   197,   198,   199,   200,   198,
     201,   198,   198,   202,   203,   198,   204,   205,   205,   206,
     207,   208,   206,   206,   206,   206,   209,   210,   206,   211,
     212,   206,   213,   213,   214,   215,   215,   216,   217,   216,
     219,   218,   220,   220,   221,   221,   222,   222,   223,   223,
     224,   224,   225,   225,   226,   226,   227,   229,   230,   228,
     231,   231,   233,   232,   234,   235,   235,   236,   237,   237,
     238,   239,   240,   241,   241,   241,   242,   242,   243,   244,
     244,   245,   246,   247,   247,   248,   249,   250,   250,   251,
     251,   251,   251,   252,   252,   253,   253,   253,   253,   254,
     255,   255,   256,   256,   257,   257,   258,   258,   259,   260,
     260,   260,   262,   263,   261,   264,   264,   265,   265,   266,
     266,   267,   267,   268,   268,   269,   269,   270,   270,   271,
     271,   272,   273,   273,   275,   276,   274,   277,   277,   277,
     277,   278,   278,   279,   280,   281,   281,   282,   282,   282,
     283,   284,   284,   285,   286,   287,   288,   288,   290,   289,
     292,   293,   291,   294,   294,   295,   295,   296,   296,   298,
     297,   299,   299,   300,   300,   301,   302,   302,   303,   303,
     303,   303,   304,   305,   305,   306,   306,   307,   308,   307,
     309,   307,   307,   310,   310,   311,   311,   311,   312,   312,
     313,   313,   314,   315,   315,   316,   316,   317,   317,   318,
     319,   320,   320,   320,   320,   322,   321,   323,   321,   325,
     324,   326,   326,   326,   326,   326,   327,   328,   328,   329,
     330,   331,   329,   332,   333,   334,   332,   335,   335,   336,
     336,   337,   337,   337,   338,   338,   339,   339,   340,   340,
     341,   343,   342,   345,   344,   347,   346,   348,   348,   349,
     350,   350,   351,   352,   352,   353,   354,   354,   355,   355,
     357,   356,   358,   358,   359,   359,   360,   360,   360,   361,
     361,   362,   362,   362,   362,   363,   363,   363,   363,   363,
     363,   364,   365,   365,   365,   367,   368,   366,   369,   370,
     370,   371,   371,   372,   374,   373,   375,   373,   376,   373,
     377,   378,   378,   379,   379,   380,   380,   381,   382,   383,
     383,   384,   384,   385,   386,   387,   387,   387,   388,   388,
     389,   389,   390,   390,   391,   391,   392,   392,   392,   392,
     392,   393,   393,   393,   394,   394,   395,   395,   396,   396,
     396,   396,   396,   396,   397,   397,   397,   397,   398,   398,
     398,   398,   398,   398,   399,   400,   401,   402,   403,   404,
     405,   405,   406,   407,   407,   407,   408,   408,   409,   409,
     409,   409,   410,   411,   411,   412,   413,   414,   414,   415,
     416,   416,   417,   417,   417,   417,   417,   417,   418,   419,
     420,   421
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     1,     0,     1,     2,     1,     1,     1,     1,
       1,     2,     1,     1,     1,     1,     1,     2,     1,     1,
       1,     1,     1,     2,     1,     1,     2,     2,     3,     1,
       1,     1,     1,     3,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     0,     4,
       3,     6,     1,     3,     6,     3,     6,     2,     1,     1,
       1,     1,     1,     1,     3,     6,     1,     0,     1,     1,
       3,     1,     1,     2,     3,     1,     3,     1,     3,     4,
       1,     3,     1,     3,     1,     3,     1,     0,     4,     3,
       5,     3,     3,     1,     1,     1,     4,     2,     2,     3,
       3,     4,     1,     2,     2,     3,     2,     1,     1,     2,
       1,     2,     1,     1,     3,     1,     2,     2,     3,     1,
       2,     1,     2,     3,     3,     3,     4,     5,     5,     1,
       3,     1,     3,     1,     3,     1,     3,     4,     1,     1,
       1,     1,     1,     1,     1,     1,     3,     4,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     3,     1,     2,
       2,     0,     4,     1,     1,     3,     1,     0,     0,     6,
       0,     4,     1,     0,     0,     6,     1,     1,     3,     1,
       0,     0,     6,     3,     1,     3,     0,     0,     6,     0,
       0,     8,     1,     3,     1,     3,     3,     1,     0,     4,
       0,     5,     1,     3,     1,     3,     1,     3,     1,     3,
       1,     3,     1,     1,     1,     1,     5,     0,     0,     5,
       1,     3,     0,     4,     3,     1,     3,     3,     1,     3,
       3,     3,     3,     1,     3,     3,     1,     1,     3,     1,
       3,     5,     1,     1,     1,     5,     5,     1,     3,     1,
       4,     3,     3,     1,     3,     1,     4,     3,     3,     5,
       1,     3,     2,     3,     1,     3,     1,     3,     3,     1,
       2,     3,     0,     0,     6,     1,     3,     1,     1,     1,
       3,     1,     3,     1,     1,     1,     1,     1,     3,     1,
       1,     7,     3,     5,     0,     0,     6,     1,     1,     1,
       1,     1,     1,     6,     4,     6,     7,     3,     6,     7,
       1,     2,     4,    10,     2,     3,     1,     2,     0,     5,
       0,     0,     8,     2,     3,     2,     3,     2,     3,     0,
       6,     1,     2,     2,     3,     4,     1,     3,     1,     3,
       2,     2,     1,     2,     3,     2,     3,     5,     0,     6,
       0,     7,     2,     1,     2,     3,     4,     2,     3,     5,
       2,     3,     2,     1,     1,     2,     3,     2,     3,     3,
       3,     0,     1,     1,     1,     0,     3,     0,     4,     0,
       5,     5,     6,     7,     3,     5,     1,     3,     5,     3,
       0,     0,     7,     3,     0,     0,     7,     1,     3,     3,
       1,     1,     3,     3,     3,     1,     1,     3,     1,     1,
       7,     0,     6,     0,     6,     0,     6,     3,     5,     1,
       3,     5,     1,     3,     5,     1,     1,     1,     1,     1,
       0,     6,     0,     1,     1,     2,     1,     1,     1,     3,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     2,     2,     0,     0,     5,     4,     0,
       1,     1,     3,     1,     0,     3,     0,     5,     0,     6,
       2,     1,     3,     1,     3,     2,     3,     4,     1,     0,
       1,     1,     3,     1,     1,     1,     3,     3,     1,     3,
       1,     3,     1,     2,     1,     3,     1,     2,     2,     3,
       3,     1,     3,     3,     1,     3,     1,     3,     1,     1,
       1,     1,     1,     3,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     4,     4,
       1,     3,     1,     2,     2,     2,     2,     2,     3,     4,
       4,     5,     1,     1,     1,     1,     1,     1,     1,     2,
       1,     1,     1,     2,     2,     1,     1,     1,     1,     1,
       0,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned short yydefact[] =
{
       0,     0,   595,   596,     0,     0,     0,     0,   610,   469,
     125,   205,     0,     0,     0,   208,   463,     0,   201,     0,
       0,     0,     0,     0,   610,   204,   203,     0,     0,     0,
      29,     0,   472,    30,     0,    31,     0,    32,     0,   137,
       0,     0,   480,   109,   360,     0,   244,     0,   465,   199,
       0,   202,     0,     0,   461,   267,   421,     0,     0,    98,
     436,   200,     0,   475,     0,   381,   421,   116,     0,     0,
     429,     8,     0,     0,     4,     6,     9,    12,    13,    10,
      22,    24,    25,     0,     7,    14,    34,    38,    15,    54,
      55,    68,    80,    16,    84,    85,    87,    18,    39,    19,
     102,     0,     0,   108,     0,    20,   113,     0,    21,     0,
      41,    42,    43,    44,    45,    46,     0,     0,   110,   195,
     198,   111,   112,     0,    36,    35,   264,   265,    47,    48,
      53,    52,    51,    50,    69,    70,    71,    49,    37,    62,
       0,    63,    56,    65,    57,   610,    58,    88,    89,   610,
     366,    92,    93,    94,    86,     0,    95,     0,    96,    97,
      90,     0,   403,    91,    66,    59,   413,   414,    60,    67,
      74,   425,    72,     0,    73,    75,    76,    77,    78,    79,
      82,     0,    83,     0,    81,     0,    40,   350,    64,   514,
      61,   348,   349,   347,   593,   594,     0,     0,    17,    11,
      23,   595,   596,   568,   569,   570,   571,   572,   573,   567,
     565,   566,     0,   479,     0,   560,     0,   478,   556,   562,
     564,   559,   561,   558,   593,   594,   597,   598,     0,   287,
       0,   283,   286,     0,     0,   520,     0,   600,   601,   393,
       0,     0,   157,     0,   163,     0,   152,     0,     0,   158,
     160,   162,   412,   415,     0,     0,     0,   319,     0,   325,
     328,   327,     0,     0,   127,     0,   407,   398,     0,   375,
       0,    26,   410,     0,   377,     0,   395,     0,     0,     0,
       0,   275,   417,     0,     0,   368,     0,     0,     0,   278,
       0,     0,   165,     0,     0,     0,     0,     0,   422,   424,
       0,   423,     0,     0,     0,   289,     0,     0,   525,     0,
       0,   574,   546,   551,   554,     0,   312,     0,     0,   314,
     316,     0,     0,     0,     0,     1,     5,    27,     0,     0,
       0,   107,     0,   123,     0,     0,     0,     0,   222,     0,
     214,   216,   226,   213,     0,     0,     0,     0,   234,   209,
     211,     0,   227,   229,   242,     0,     0,     0,     0,   110,
     111,   112,     0,   247,   352,   351,   344,   610,     0,     0,
       0,   364,   610,     0,     0,   379,   383,     0,     0,   402,
       0,   593,   594,     0,     0,     0,   427,   456,   459,   458,
     534,   535,   538,   540,   542,   544,     0,     0,     0,   477,
       0,   476,     0,     0,     0,     0,     0,     0,     0,   587,
     509,   586,     0,   382,   367,   404,   599,     0,   437,     0,
     584,   529,   583,     0,   585,     0,     0,   280,     0,     0,
     595,   596,     0,   297,   299,   594,     0,   611,     0,     0,
       0,   386,   388,   392,   394,     0,   156,     0,   150,   153,
     154,   149,     0,   159,   161,   416,     0,   337,   340,   339,
       0,   318,     0,   320,     0,   322,     0,   303,   305,   594,
       0,   126,     0,   405,     0,   370,   376,   411,   378,   396,
     100,   117,     0,     0,   274,     0,   418,   482,     0,    33,
       0,   277,     0,     0,   164,   166,   167,   169,   171,     0,
     310,     0,     0,   270,   272,   268,   420,     0,   292,   282,
     288,     0,   439,   440,     0,   547,   548,     0,     0,     0,
       0,     0,   526,     0,   313,     0,   419,   281,   443,   444,
       0,    28,   103,   117,   105,   117,   114,   117,   124,     0,
       0,   194,     0,   189,   190,   191,   192,   188,   193,   180,
     185,   223,   173,     0,   217,     0,   608,   196,     0,   206,
       0,   182,   609,     0,   210,   256,     0,   236,     0,   174,
       0,   230,     0,     0,   184,     0,   175,   246,   250,   245,
     248,     0,     0,     0,   357,   610,     0,     0,   365,     0,
       0,   384,   400,     0,   543,     0,   458,   426,     0,     0,
       0,     0,     0,     0,     0,     0,   447,   450,   476,     0,
     434,     0,     0,   467,     0,   470,     0,   473,   516,   610,
       0,   521,   523,   515,     0,   592,     0,     0,   510,   511,
     558,   582,     0,   580,   563,     0,     0,   530,   531,   544,
     557,     0,   284,   285,   134,   136,     0,   130,   577,   132,
       0,     0,     0,     0,     0,   390,   385,     0,   391,     0,
     155,   151,     0,   321,   326,     0,     0,     0,     0,     0,
     128,   406,     0,     0,   122,     0,   118,   119,   121,     0,
       0,   144,   145,   143,   138,     0,   276,   502,   491,   492,
     490,   497,     0,   495,   498,   496,     0,   499,   501,     0,
     505,     0,   483,   484,   486,   487,   488,   500,   493,   494,
       0,     0,   279,   168,   170,   172,     0,     0,     0,   451,
       0,     0,     0,     0,     0,     0,   290,     0,    99,   550,
     549,   553,   552,   555,   317,   315,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   215,     0,     0,   197,
       0,   262,     0,   576,   263,   235,     0,     0,   258,   260,
       0,   228,     0,   233,   533,   243,   176,     0,     0,   345,
       0,   610,   361,     0,   610,   354,   610,     0,     0,     0,
     575,     0,     0,   457,   428,   536,   537,   539,   541,   545,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   518,
       0,   588,     0,     0,   508,     0,   578,     0,   438,   527,
       0,   579,   129,     0,     0,   295,   298,     0,   302,   301,
       0,   387,   389,     0,   338,     0,   568,   605,   606,   607,
       0,     0,   323,   329,     0,   331,   602,   336,   335,   333,
     296,   304,     0,   308,   307,     0,     0,     0,     0,   139,
       0,     0,   148,     0,   147,     0,     0,   503,   504,     0,
       0,   485,   369,     0,   309,   311,     0,     0,     0,   266,
     271,     0,   269,   294,     0,   293,   441,   445,   430,     0,
       0,     0,   177,   178,     0,   186,   224,   218,   221,   207,
     257,   239,   237,   212,     0,     0,   231,   254,     0,   252,
     249,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     397,     0,   558,   431,     0,     0,   448,   449,   435,   468,
     471,   474,   517,   524,     0,   522,   590,   589,     0,   512,
     513,   581,   532,   131,   135,   133,   300,   353,   464,     0,
     603,   604,     0,     0,     0,   306,   399,   371,   101,   120,
     142,   141,     0,     0,   489,   506,   481,   466,   462,   453,
     455,   452,   273,   291,     0,     0,   104,   106,   115,   187,
       0,     0,     0,     0,   259,   261,     0,     0,   251,     0,
     346,     0,   355,   362,   358,     0,     0,   380,     0,   408,
       0,     0,   432,   519,   591,     0,     0,   330,   324,   332,
     336,     0,   146,   140,     0,     0,   442,   446,   225,   219,
     240,   238,   232,   255,   253,   356,   359,   610,   401,     0,
       0,   433,   341,     0,     0,   372,   507,   454,     0,     0,
     409,   460,   342,   373,     0,   241,     0,     0,   374,   363,
     343
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short yydefgoto[] =
{
      -1,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      81,    82,    83,    84,    85,    86,    87,    88,    89,    90,
      91,    92,    93,    94,    95,    96,    97,   307,    98,    99,
     100,   101,   102,   103,   104,   105,   106,   107,   675,   676,
     677,   108,   109,   110,   263,   229,   646,   647,   111,   279,
     483,   679,   680,   681,   682,   112,   245,   246,   247,   248,
     249,   250,   113,   291,   292,   293,   496,   497,   114,   115,
     116,   117,   549,   550,   118,   119,   120,   558,   121,   122,
     349,   568,   350,   339,   340,   747,   971,   555,   745,   970,
     341,   351,   352,   762,   976,   756,   973,   972,  1028,   353,
     123,   124,   362,   768,   363,   767,   898,   899,   564,   757,
     758,   759,   125,   126,   127,   297,   724,   502,   503,   723,
     128,   280,   129,   288,   130,   131,   132,   230,   231,   133,
     304,   305,   507,   874,   134,   135,   432,   433,   466,   467,
     136,   499,   137,   318,   319,   138,   256,   257,   665,   943,
     258,   259,   832,   833,   834,   835,   456,   457,   260,   995,
     139,   581,   901,   140,   366,   141,   142,   143,   144,   145,
     582,   146,   147,   148,   149,   150,   488,   151,   673,  1001,
    1025,   152,   153,   154,   590,   155,   156,   157,   440,   441,
     442,   158,   159,   160,   474,   778,   161,   162,   779,   163,
     164,   165,   166,   167,   168,   169,   300,   170,   385,   599,
     171,   324,   172,   173,   174,   175,   727,   964,   176,   736,
     965,   605,   606,   718,   959,   386,   387,   388,   177,   295,
     178,   241,   179,   287,   180,   181,   182,   183,   184,   185,
     607,   214,   186,   284,   701,   702,   703,   704,   705,   706,
     707,   708,   709,   859,  1004,   187,   627,   628,   629,   188,
     407,   797,   924,   189,   620,   621,   190,   215,   216,   636,
     637,   763,   401,   390,   391,   392,   393,   394,   395,   312,
     313,   314,   218,   219,   220,   315,   781,   754,   649,   191,
     221,   632,   633,   222,   192,   409,   626,   223,   224,   225,
     609,   196,   197,   838,   839,   565,   583,   438
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -865
static const short yypact[] =
{
    1550,   -38,   -32,   -11,  1741,  1427,   113,     4,  -865,  -865,
    -865,  -865,   178,    16,   138,  -865,  -865,    78,  -865,    33,
     159,   123,    54,   178,  -865,  -865,  -865,    96,   207,   115,
    -865,   172,  -865,  -865,   224,  -865,   228,  -865,   178,  -865,
     178,   246,  -865,  -865,  -865,   121,  -865,   242,  -865,  -865,
     178,  -865,   158,   285,  -865,   303,   284,    97,  1427,  -865,
    -865,  -865,  1097,  -865,    88,  -865,   284,  -865,   113,  1427,
    -865,  -865,   344,  1647,  -865,  -865,  -865,  -865,  -865,  -865,
    -865,  -865,  -865,   256,  -865,  -865,  -865,  -865,  -865,  -865,
    -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,
    -865,   178,   178,  -865,   299,  -865,  -865,   178,  -865,   298,
    -865,  -865,  -865,  -865,  -865,  -865,   307,   316,   101,    74,
    -865,   130,   104,   476,  -865,  -865,  -865,  -865,  -865,  -865,
    -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,
     109,  -865,  -865,  -865,  -865,   142,  -865,  -865,  -865,  1830,
    -865,  -865,  -865,  -865,  -865,   325,  -865,   300,  -865,  -865,
    -865,   185,  -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,
    -865,  1119,  -865,  1472,  -865,  -865,  -865,  -865,  -865,  -865,
    -865,   817,  -865,   845,  -865,   891,  -865,  -865,  -865,   346,
    -865,   373,  -865,  -865,   381,   410,   302,   393,  -865,  -865,
    -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,
    -865,  -865,  1152,  -865,   182,   373,   426,   440,  -865,  -865,
    -865,   373,  -865,  -865,   448,   463,  -865,  -865,   400,  -865,
     260,  -865,   465,   397,   566,  -865,   928,  -865,  -865,  -865,
     484,   488,  -865,    80,  -865,   137,  -865,   178,    86,  -865,
     491,   465,  -865,  -865,   497,    62,   154,  -865,   167,  -865,
    -865,  -865,   397,   267,  -865,   465,   566,  -865,   518,  -865,
     512,  -865,  -865,   552,  -865,   556,  -865,   578,   287,   565,
     308,  -865,  -865,   580,   586,  -865,   594,   604,   335,  -865,
     178,   194,  -865,   178,   432,   612,   178,   178,  -865,  -865,
     601,  -865,   178,   350,   357,  -865,   359,   178,  -865,  1553,
    1553,   317,   192,  -865,   689,   605,  -865,   178,   360,  -865,
    -865,   618,   362,   367,   617,  -865,  -865,  -865,   622,   348,
     374,  -865,   394,  -865,   626,   632,   641,   658,   621,   375,
    -865,   609,   465,  -865,   723,  1203,   658,    65,   201,  -865,
    -865,   396,  -865,   627,   230,   326,   405,   651,   629,  -865,
     147,  -865,   423,  -865,  -865,  -865,  -865,  -865,   218,   566,
     656,  -865,  -865,   690,   566,  -865,  -865,   657,   659,  -865,
     652,  -865,  -865,  1388,  1119,   665,   655,  -865,  -865,   524,
    -865,   746,   750,  -865,   752,   317,   974,   428,   974,  -865,
     676,   524,   974,   681,   974,   682,   624,   683,  1225,  -865,
    1225,  -865,  1152,  -865,  -865,  -865,  -865,   209,  -865,  1119,
    -865,  1010,  -865,  1553,  -865,  1152,   178,  -865,   178,  1034,
     677,   679,   403,  -865,  -865,   686,   688,  -865,   696,  1152,
     455,  -865,   678,   524,  -865,   974,  -865,   687,  -865,  -865,
     178,  -865,   169,  -865,  -865,  -865,   693,  -865,  -865,  -865,
     410,  -865,   123,  -865,   123,  -865,   485,  -865,  -865,   695,
     692,  -865,   178,   697,  1152,  -865,  -865,  -865,  -865,  -865,
    -865,   117,   178,   430,  -865,   178,  -865,   379,  1152,  -865,
     974,  -865,   178,   698,  -865,  -865,   178,  -865,   702,   489,
    -865,   974,   495,  -865,  -865,   703,  -865,   704,  -865,  -865,
    -865,   706,  -865,  -865,   710,   192,   192,  1553,  1553,  1553,
    1553,  1553,  -865,   705,  -865,    84,  -865,  -865,  -865,  -865,
     974,  -865,  -865,   117,  -865,   117,  -865,   117,  -865,   178,
     178,  -865,   711,  -865,  -865,  -865,  -865,  -865,  -865,   712,
    -865,  -865,  -865,   178,  -865,   709,  -865,  -865,   717,   524,
     729,   712,  -865,  1237,  -865,  -865,    65,  -865,  1258,  -865,
     178,  -865,  1152,    65,   712,   435,  -865,  -865,  -865,  -865,
    -865,  1152,   501,   566,  -865,  -865,   716,   738,  -865,   735,
    1152,  -865,  -865,  1388,   752,   737,   209,  -865,  1119,   743,
    1152,  1152,  1152,  1152,  1388,   503,  -865,  -865,   524,   736,
    -865,  1119,   505,  -865,   509,  -865,   513,  -865,  -865,  -865,
     515,  -865,   524,  -865,  1270,   317,   739,   745,   744,  -865,
     521,   524,   522,  -865,  -865,   436,   760,   759,   524,   318,
    -865,   526,  -865,  -865,  -865,  -865,   539,  -865,   317,   741,
     764,   397,  1034,   432,   432,  -865,  -865,   928,  1152,   540,
    -865,  -865,   145,  -865,  -865,   567,   765,   397,  1034,   432,
    -865,  -865,   258,  1152,  -865,   766,   767,  -865,  -865,   541,
     768,   373,  -865,   770,  -865,   771,  -865,  -865,  -865,  -865,
    -865,  -865,   379,  -865,  -865,  -865,   862,  -865,  -865,   863,
    -865,   774,   379,  -865,  -865,  -865,  -865,  -865,  -865,  -865,
     262,   545,  -865,  -865,  -865,  -865,   776,   432,   550,  -865,
     769,   782,   178,   775,   786,   178,  -865,  1119,  -865,   192,
     192,  -865,  -865,  -865,  -865,  -865,  1119,   561,   787,   788,
     789,   437,   438,  1034,   658,   567,  -865,   567,  1152,  -865,
    1152,  -865,   790,   317,  -865,   780,   567,   562,  -865,  -865,
     784,  -865,   567,  -865,   524,  -865,  -865,   876,   730,   524,
    1282,  -865,  -865,   563,  -865,  -865,  -865,   295,  1152,   794,
     317,   803,  1119,  -865,  -865,   746,   746,   750,  -865,   890,
     369,   974,  1046,   443,   809,   810,   811,   812,   566,  -865,
    1080,  -865,   814,  1309,  -865,   432,  -865,  1152,  -865,  -865,
    1152,  -865,  -865,  1034,  1343,  -865,  -865,   568,  -865,  -865,
     813,  -865,  -865,   816,  -865,   815,   820,  -865,  -865,  -865,
     434,   434,   824,  -865,   826,  -865,  -865,   829,  -865,  -865,
    -865,  -865,   573,  -865,  -865,   818,   320,   819,   117,  -865,
     178,   178,  -865,  1010,  -865,   178,  1362,  -865,  -865,  1388,
     821,  -865,  -865,   844,  -865,  -865,   846,   178,  1046,  -865,
    -865,  1152,  -865,  -865,   848,   465,   655,   655,  -865,   847,
     852,   853,  -865,  -865,   587,  -865,   824,   824,  -865,   524,
    -865,  -865,   824,  -865,  1258,  1237,   824,   808,   589,  -865,
    -865,   855,  1388,   856,   566,   858,   598,   566,   860,   322,
    -865,  1388,   837,  -865,  1119,   453,  -865,  -865,  -865,  -865,
    -865,  -865,  -865,  -865,   861,  -865,  -865,  -865,   864,  -865,
    -865,  -865,   524,  -865,  -865,  -865,  -865,  -865,  -865,  1388,
    -865,  -865,   567,   857,  1415,  -865,  -865,  -865,  -865,  -865,
    -865,  -865,   602,   608,  -865,  -865,  -865,  -865,  -865,  -865,
     854,  -865,  -865,  -865,   866,   867,  -865,  -865,  -865,  -865,
     868,   869,   567,   873,  -865,  -865,   883,   951,  -865,   876,
    -865,   870,  -865,  -865,  -865,   871,   865,  -865,   892,   887,
    1388,   454,  -865,  -865,  -865,   872,   889,  -865,  -865,  -865,
    -865,   902,  -865,  -865,   884,  1046,  -865,  -865,  -865,  -865,
     824,  -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,  1388,
     898,  -865,  -865,  1388,   310,  -865,  -865,  -865,   894,   566,
    -865,  -865,   900,  -865,   905,  -865,   906,  1388,  -865,  -865,
    -865
};

/* YYPGOTO[NTERM-NUM].  */
static const short yypgoto[] =
{
    -865,  -865,  -865,   933,  -865,  -865,  1003,  -865,  -865,  1004,
    -865,  -865,  -865,  -865,  -865,  -865,  -865,   877,  -865,  -865,
    -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,
    -865,  -865,  -865,   907,  -121,  -865,  -865,  -865,  -198,  -865,
     161,  -865,  -865,  -865,  -865,    47,  -572,   202,  -865,  -865,
    -865,   170,  -110,  -865,  -865,  -865,   779,  -213,  -865,   781,
    -209,  -865,  -865,  -865,   740,  -865,  -865,   533,  -865,  -865,
    -865,  -865,  -143,   290,  -119,  -865,  -865,  -865,  -116,  -108,
    -865,  -865,   916,   523,   498,  -865,  -865,  -865,  -865,  -865,
    -865,  -101,   493,  -865,  -865,  -865,  -865,  -865,  -865,  -865,
    -865,  -865,  -865,  -865,   293,  -865,  -865,    85,  -358,  -865,
     171,  -534,  -865,  -865,  -865,  -865,  -865,   772,   345,  -865,
    -865,  -865,  -865,  -865,  -865,  -865,  -865,    57,   133,  -865,
    -865,   555,  -865,  -865,  -865,  -865,  -865,  -528,  -865,  -865,
    -865,  -865,  -865,  -865,   546,  -865,  -865,  -220,  -865,  -865,
    -865,   606,  -703,   131,  -865,   128,  -865,   412,  -232,  -865,
    -865,  -865,  -865,   -10,  -865,  -865,  -865,  -865,  -865,  -865,
    -548,  -865,  -865,  -865,   926,  -153,  -865,  -865,  -865,  -865,
    -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,   420,
    -406,  -865,  -865,  -865,  -865,  -865,  -865,   885,    89,  -865,
    -865,  -865,  -865,  -865,  -865,  -865,  1014,  -865,  -865,  -865,
    -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,
    -865,  -330,   304,  -865,  -865,  -371,  -560,  -865,  -865,  -865,
    -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,
    -173,     7,  -865,  -865,  -865,   404,  -655,  -865,  -865,  -865,
    -865,  -865,  -865,  -865,  -865,  -865,  -865,  -865,   292,  -865,
    -865,  -865,  -865,  -865,  -865,   313,  -865,  -865,  -865,  -865,
    -865,  -694,    12,  -865,   143,   496,   511,  -359,   -61,  -252,
    -168,    40,   694,  -865,  -634,  -707,  -849,  -864,   305,  -230,
    -516,  -407,   309,  -865,  -865,  -166,  -584,     5,    30,    56,
      29,   950,   -14,  -865,   791,  -865,    -5,  -250
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -609
static const short yytable[] =
{
     240,   311,   358,   234,   359,   193,   254,   360,   400,   193,
     403,   261,   405,   595,   270,   361,   473,   273,   641,   266,
     275,   356,   277,   458,   594,   459,   193,   283,   411,   752,
     194,   836,   449,   655,   194,   232,   463,   773,   783,   453,
     802,   235,   886,   414,   887,   217,   251,   861,   635,   420,
     422,   194,   265,   892,   888,   424,   195,   515,   516,   896,
     195,   198,   989,   903,   244,   306,   202,   278,   612,   281,
     264,   562,   614,  -600,   616,   996,   323,   195,   193,   289,
     817,   226,   227,   226,   227,   301,   232,   226,   227,   226,
     227,   226,   227,   320,  -601,   301,   842,   232,   217,   343,
     226,   227,   242,   194,   226,   227,   233,   226,   227,   217,
     242,   836,   328,   836,   303,   659,   226,   227,   236,   587,
     226,   227,   836,   816,   589,   322,   201,   202,   836,   195,
     329,   330,   252,   226,   227,   364,   332,   818,   334,   841,
     369,   237,   238,   377,   374,   226,   227,   342,   226,   431,
     354,   354,   955,   843,   193,   343,   262,   201,   202,  1032,
     711,   242,   237,   238,   255,   338,   380,   563,   348,   348,
    1030,   884,   343,  1040,   368,   237,   238,   962,   344,   194,
     397,   226,   227,   389,   243,   451,   446,   316,   201,   202,
     317,   381,   243,   242,   317,   981,   940,   941,   267,   302,
     737,   861,   228,   561,   337,   195,  -179,   355,   755,  -183,
     237,   238,   574,   217,   271,   765,   365,   382,   228,   928,
     414,   674,   783,   285,   417,   255,   906,   237,   238,   600,
     601,   237,   238,   346,   347,  -181,   448,   239,   434,   449,
     793,   453,   663,   243,   367,   789,   261,   255,   443,   237,
     238,   347,   822,   461,   575,   286,   255,   462,   253,   226,
     227,   193,   436,   381,   290,   729,   730,   468,   661,  1010,
     464,   272,   447,   465,   268,   243,   251,   251,   600,   601,
     378,   418,   600,   601,   379,   419,   194,   226,   227,   435,
     298,   470,   381,   494,   244,   244,   519,   299,   520,   500,
     290,   226,   227,   237,   238,   566,   269,   567,   836,   634,
     836,   460,   195,   237,   238,   600,   601,   584,   469,   493,
     585,   586,   498,   274,   381,   504,   504,   276,   719,   226,
     227,   508,   429,   772,   573,   738,   514,   739,   836,   740,
     600,   601,   600,   601,   325,   282,   523,   625,    24,   625,
     382,   731,   732,   733,   541,   327,   876,   559,   845,   427,
     639,   975,   862,   428,    43,   877,   471,   374,   648,    45,
     472,   542,   201,   202,   560,   203,   204,   205,   206,   207,
     208,   209,   210,   211,   354,   687,   480,   294,   543,   481,
     413,   383,   688,   689,   690,   908,   596,   333,   544,   376,
     430,   431,   348,   691,   545,   296,   546,   484,   608,  1033,
     608,   485,   335,   547,   608,   630,   608,   548,   622,   915,
     947,   336,   988,  -592,   631,   517,   517,   375,   518,   518,
     458,   389,   459,   638,   491,   201,   202,   631,   492,   742,
     203,   204,   205,   206,   207,   208,   952,   532,   406,   509,
     533,   443,   261,   428,   261,   232,   510,   232,   512,   524,
     511,   527,   513,   525,   423,   428,   528,   193,   913,   193,
     529,   384,   914,   534,   552,   408,   535,   309,   553,   251,
     310,   692,   693,   410,   694,   695,   672,   696,   697,   698,
     699,   700,   194,   536,   194,   569,   537,   244,   416,   570,
     710,   265,   753,   650,   576,   426,   651,   753,   570,    11,
     678,   683,   412,    15,   686,   852,    18,   854,   195,   670,
     195,   712,   579,    25,    26,   498,   580,   610,   421,   684,
     720,   611,   780,   685,   766,   808,   882,   883,   570,   598,
     553,   570,   918,   991,   600,   601,   598,    49,   923,    51,
    -528,   357,   992,  1021,   320,   656,   598,   598,   657,   642,
      61,   643,   678,   625,   678,   425,   678,   429,   342,   354,
     226,   227,   437,   826,   204,   205,   206,   207,   208,   827,
     828,   829,   342,   444,   764,   666,   338,   348,   667,   716,
     445,   648,   717,   769,   454,   721,   455,   760,   722,   354,
     338,   770,   777,   790,   771,   794,   791,   648,   791,   795,
     389,   476,   791,   796,   798,   799,   791,   348,   800,   917,
     475,  -513,   806,   389,  -513,   807,   811,   201,   202,   807,
     203,   204,   205,   206,   207,   208,   209,   210,   211,   812,
     823,   849,   813,   791,   850,   863,   383,   358,   791,   359,
     866,   477,   360,   867,   983,   478,   434,   986,   819,   820,
     361,   878,   893,   905,   791,   894,   771,   482,   936,   443,
     443,   813,   434,   945,   844,   830,   813,   479,   831,   486,
     436,   381,   648,   381,   381,   846,   541,   969,   487,   978,
     813,   825,   979,   489,   837,   961,   436,   381,   985,   381,
     506,   771,  1002,   542,   522,   807,   490,   435,  1003,   311,
     382,   850,   521,   423,   501,   554,  -220,   526,   460,   530,
     543,   531,   865,   435,   618,   538,   212,   551,   619,   556,
     544,   578,   309,   571,   572,   310,   545,   539,   546,   389,
     950,   951,   625,   785,   786,   547,   540,   381,   389,   548,
     577,   504,   648,   648,   875,   588,   591,    45,   598,   593,
     764,   592,   889,    11,   597,   602,   904,    15,   603,   604,
      18,   907,   873,   382,   837,   613,   837,    25,    26,  1036,
     615,   617,   623,   658,  -597,   837,  -598,   912,   652,   654,
     909,   837,   639,   660,   389,   653,   662,   668,   311,   669,
     671,    49,   389,    51,   713,   715,   722,   725,   302,   728,
     930,   734,   622,   743,    61,   744,   748,   749,   774,   631,
     201,   202,   932,   203,   204,   205,   206,   207,   208,   209,
     210,   211,  1027,   753,   753,   381,   750,   775,   776,   383,
     782,   311,   784,   792,   803,   804,   814,   805,   201,   202,
     780,   203,   204,   205,   206,   207,   208,   209,   210,   211,
     809,   382,   810,   815,   840,   631,   847,   383,   857,   858,
     848,   851,   853,   855,   860,   864,   868,   678,   753,   683,
     683,   869,   871,   764,   683,   872,   891,   879,   880,   881,
     890,   895,   897,   910,   201,   202,   960,   203,   204,   205,
     206,   207,   208,   209,   210,   211,   911,  -609,   919,   920,
     921,   922,   937,   383,   926,   938,   977,   946,   948,   398,
     956,   399,   939,   760,  -608,   309,   389,   942,   310,   780,
     944,   201,   202,  -334,   203,   204,   205,   206,   207,   208,
     209,   210,   211,   957,   990,   958,   966,   402,   963,   399,
     383,   967,   968,   309,   980,   982,   310,   984,   780,   987,
     993,  1005,   753,   998,   994,  1006,  1007,  1013,  1017,  1015,
    1016,   837,  1022,  1000,  1008,  1009,   753,   430,   431,  1011,
     203,   204,   205,   206,   207,   208,   209,   210,   211,  1012,
    1019,  1018,  1023,   404,  1024,   399,   383,  1026,  1031,   309,
    1035,   837,   310,  1037,  1038,  1039,   326,   199,   200,   949,
    1034,   331,  1029,   201,   202,   933,   203,   204,   205,   206,
     207,   208,   209,   210,   211,   953,   371,   452,   450,   714,
     212,   495,   383,   439,   885,   345,   309,   201,   202,   310,
     203,   204,   205,   206,   207,   208,   209,   210,   211,   201,
     202,   746,   203,   204,   205,   206,   207,   208,   209,   210,
     211,   900,   741,   761,  1014,   974,   726,   870,   383,   505,
     664,   735,   999,   997,   824,   372,   212,   821,   399,  1020,
     321,   415,   309,   201,   202,   310,   203,   204,   205,   206,
     207,   208,   209,   210,   211,   916,   856,   929,   787,   373,
     201,   202,   383,   203,   204,   205,   206,   207,   208,   209,
     210,   211,   212,   925,   788,   624,   931,   640,   309,   935,
       0,   310,   201,   202,     0,   203,   204,   205,   206,   207,
     208,   209,   210,   211,     0,   557,   212,     0,   644,   645,
       0,   383,   309,     0,     0,   310,     0,     0,   212,     0,
     399,     0,     0,     0,   309,   201,   202,   310,   203,   204,
     205,   206,   207,   208,   209,   210,   211,     0,     0,     0,
       0,     0,     0,     0,   383,     0,     0,     0,     0,     0,
       0,     0,   212,     0,   619,     0,     0,     0,   309,     0,
       0,   310,     0,     0,     0,     0,   308,     0,     0,   212,
       0,     0,     0,     0,     0,   309,   430,   431,   310,   203,
     204,   205,   206,   207,   208,   209,   210,   211,     0,     0,
       0,   384,     0,     0,     0,   383,     0,   309,   201,   202,
     310,   203,   204,   205,   206,   207,   208,   209,   210,   211,
     201,   202,     0,   203,   204,   205,   206,   207,   208,   209,
     210,   211,     0,     0,   212,     0,     0,     0,     0,     0,
     309,   430,   431,   310,   203,   204,   205,   206,   207,   208,
     209,   210,   211,   201,   202,     0,   203,   204,   205,   206,
     207,   208,   209,   210,   211,   201,   202,     0,   203,   204,
     205,   206,   207,   208,   209,   210,   211,     0,     0,     0,
       0,     0,     0,     0,     0,   212,     0,     0,     0,     0,
       0,   309,   201,   202,   310,   203,   204,   205,   206,   207,
     208,   209,   210,   211,     0,     0,     0,   212,     0,     0,
     624,     0,     0,   309,     0,     0,   310,     0,     0,   212,
       0,   751,     0,     0,     0,   309,   201,   202,   310,   203,
     204,   205,   206,   207,   208,   209,   210,   211,     0,     0,
     212,     0,   751,     0,     0,     0,   309,     0,   687,   310,
     801,     0,   212,     0,     0,   688,   689,   690,   309,     0,
       0,   310,     0,     0,   212,   902,   691,     0,     0,     0,
     309,   201,   202,   310,   203,   204,   205,   206,   207,   208,
     209,   210,   211,     0,     0,     0,     0,     0,     0,   927,
       0,   212,     0,     0,     0,     0,     0,   309,   226,   227,
     310,   203,   204,   205,   206,   207,   208,   827,   828,   829,
     201,   202,     0,   203,   204,   205,   206,   207,   208,   209,
     210,   211,     0,     0,     0,   212,     0,   934,     0,     0,
       0,   309,     0,     0,   310,     0,     0,     0,     0,     0,
       0,     0,   954,     0,   692,   693,     0,   694,   695,     0,
     696,   697,   698,   699,   700,   201,   202,     0,   203,   204,
     205,   206,   207,   208,   209,   210,   211,     0,     0,     0,
     212,     0,     0,     0,     0,     0,   309,     0,     0,   310,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   830,     0,     0,   831,     0,     0,   212,
       0,   213,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      -3,     1,     0,     2,     3,     4,   201,   202,     0,   203,
     204,   205,   206,   207,   208,   209,   210,   211,     0,     0,
       0,     0,     0,     0,   396,     0,   213,     5,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,     0,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
      67,    68,     0,     0,    69,     0,    70,    -2,     1,    71,
       2,     3,     4,     0,     0,   212,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,     0,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    66,    67,    68,     0,
       0,    69,     1,    70,     2,     3,    71,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
       0,    48,    49,    50,    51,    52,     0,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    67,    68,     2,     3,    69,     0,    70,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     5,     0,     7,
       8,     9,     0,     0,    12,     0,     0,     0,    16,     0,
       0,    19,    20,     0,    22,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    32,     0,     0,     0,     0,     0,
       0,     0,     0,    41,     0,     0,    44,    45,     0,     0,
      48,     0,     0,     0,     0,     0,    53,    54,     0,    56,
       0,    58,     0,    60,     0,    62,    63,     0,     0,    66,
       0,     0,   370,     0,    69,     0,    70
};

static const short yycheck[] =
{
      14,    62,   123,     8,   123,     0,    20,   123,   181,     4,
     183,    21,   185,   384,    28,   123,   266,    31,   425,    24,
      34,   122,    36,   255,   383,   255,    21,    41,   194,   563,
       0,   665,   245,   439,     4,     6,   256,   585,   598,   248,
     624,    12,   745,   196,   747,     5,    17,   702,   419,   215,
     216,    21,    23,   756,   748,   221,     0,   309,   310,   762,
       4,    99,   911,   770,    17,    58,     4,    38,   398,    40,
      23,     6,   402,   105,   404,   939,    69,    21,    73,    50,
     652,     3,     4,     3,     4,    56,    57,     3,     4,     3,
       4,     3,     4,    64,   105,    66,   668,    68,    58,    25,
       3,     4,    24,    73,     3,     4,   102,     3,     4,    69,
      24,   745,    83,   747,    57,   445,     3,     4,   102,   369,
       3,     4,   756,   651,   374,    68,     3,     4,   762,    73,
     101,   102,    99,     3,     4,    26,   107,   653,   109,   667,
     145,     3,     4,   157,   149,     3,     4,   118,     3,     4,
     121,   122,   859,   669,   149,    25,   102,     3,     4,  1023,
     490,    24,     3,     4,   102,   118,   161,   102,   121,   122,
    1019,   743,    25,  1037,   145,     3,     4,   871,   104,   149,
     173,     3,     4,   171,   106,    99,   106,    99,     3,     4,
     106,   161,   106,    24,   106,   902,   830,   831,   102,   102,
     530,   856,   105,   346,   103,   149,   105,   103,   566,   105,
       3,     4,   355,   173,    99,   573,   107,   161,   105,   803,
     373,   104,   782,   102,   212,   102,   774,     3,     4,    20,
      21,     3,     4,   103,   104,   105,    99,    99,   233,   452,
     611,   450,   462,   106,   102,   604,   256,   102,   236,     3,
       4,   104,   658,    99,   355,    13,   102,   103,    99,     3,
       4,   256,   233,   233,   106,   517,   518,   262,    99,   972,
     103,    99,   243,   106,    67,   106,   247,   248,    20,    21,
      95,    99,    20,    21,    99,   103,   256,     3,     4,   233,
       6,   262,   262,    99,   247,   248,   104,    13,   106,   294,
     106,     3,     4,     3,     4,   104,    99,   106,   942,   100,
     944,   255,   256,     3,     4,    20,    21,    99,   262,   290,
     102,   103,   293,    99,   294,   296,   297,    99,   501,     3,
       4,   302,   102,   583,   104,   533,   307,   535,   972,   537,
      20,    21,    20,    21,     0,    99,   317,   408,    46,   410,
     294,   519,   520,   521,    28,    99,   727,   345,   100,    99,
     421,   895,   100,   103,    65,   736,    99,   372,   429,    67,
     103,    45,     3,     4,   345,     6,     7,     8,     9,    10,
      11,    12,    13,    14,   355,     6,    99,   102,    62,   102,
      88,    22,    13,    14,    15,   100,   384,    99,    72,    99,
       3,     4,   355,    24,    78,   102,    80,    99,   396,    99,
     398,   103,   105,    87,   402,   410,   404,    91,   406,   790,
     100,   105,   100,   105,   412,   108,   108,   102,   111,   111,
     662,   419,   662,   421,    99,     3,     4,   425,   103,   540,
       6,     7,     8,     9,    10,    11,   853,    99,   102,    99,
     102,   439,   462,   103,   464,   426,    99,   428,    99,    99,
     103,    99,   103,   103,    24,   103,    99,   462,    99,   464,
     103,   102,   103,    99,    99,   102,   102,   108,   103,   450,
     111,   102,   103,   102,   105,   106,   474,   108,   109,   110,
     111,   112,   462,    99,   464,    99,   102,   450,   105,   103,
     488,   472,   563,   100,    99,   105,   103,   568,   103,    33,
     481,   482,   102,    37,   485,   681,    40,   683,   462,   472,
     464,   492,    99,    47,    48,   496,   103,    99,   102,    99,
     501,   103,   593,   103,    99,    99,    99,    99,   103,   103,
     103,   103,    99,   914,    20,    21,   103,    71,   798,    73,
     102,    75,    99,    99,   525,   100,   103,   103,   103,   426,
      84,   428,   533,   624,   535,   102,   537,   102,   539,   540,
       3,     4,     6,     6,     7,     8,     9,    10,    11,    12,
      13,    14,   553,    99,   572,   100,   539,   540,   103,   100,
     102,   652,   103,   581,   103,   100,    99,   568,   103,   570,
     553,   100,   590,   100,   103,   100,   103,   668,   103,   100,
     598,    99,   103,   100,   619,   100,   103,   570,   103,   792,
     102,   100,   100,   611,   103,   103,   100,     3,     4,   103,
       6,     7,     8,     9,    10,    11,    12,    13,    14,   100,
     100,   100,   103,   103,   103,   100,    22,   768,   103,   768,
     100,    99,   768,   103,   904,    99,   651,   907,   653,   654,
     768,   100,   100,   100,   103,   103,   103,   102,   100,   657,
     658,   103,   667,   100,   669,   108,   103,    99,   111,    99,
     651,   651,   743,   653,   654,   673,    28,   100,   102,   100,
     103,   662,   103,    99,   665,   868,   667,   667,   100,   669,
      99,   103,   100,    45,    99,   103,   102,   651,   100,   770,
     654,   103,    23,    24,   102,   106,   107,    99,   662,   102,
      62,    99,   717,   667,   100,    99,   102,   106,   104,     6,
      72,   102,   108,   106,   107,   111,    78,   105,    80,   727,
     850,   851,   803,   600,   601,    87,   105,   717,   736,    91,
      99,   722,   813,   814,   725,    99,    99,    67,   103,   107,
     748,   102,   750,    33,    99,    19,   771,    37,    18,    17,
      40,   776,   725,   717,   745,    99,   747,    47,    48,  1029,
      99,    99,    99,   105,   107,   756,   107,   782,   102,    93,
     778,   762,   853,   106,   782,   107,   103,   102,   859,   107,
     103,    71,   790,    73,   106,   103,   103,   103,   102,    99,
     805,   106,   800,   102,    84,   103,   107,   100,   102,   807,
       3,     4,   810,     6,     7,     8,     9,    10,    11,    12,
      13,    14,  1005,   894,   895,   805,   107,    99,   103,    22,
     103,   902,    99,   107,   105,   100,   105,   103,     3,     4,
     911,     6,     7,     8,     9,    10,    11,    12,    13,    14,
     100,   805,   103,    99,    99,   853,   100,    22,     6,     6,
     103,   103,   102,   102,   100,    99,   107,   848,   939,   850,
     851,    99,   107,   871,   855,    99,   106,   100,   100,   100,
     100,   107,    16,    99,     3,     4,   867,     6,     7,     8,
       9,    10,    11,    12,    13,    14,   103,    17,    99,    99,
      99,    99,    99,    22,   100,    99,   108,    99,    99,   102,
      99,   104,   107,   894,   104,   108,   914,   103,   111,   990,
     104,     3,     4,   104,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    99,   107,    99,    99,   102,   100,   104,
      22,    99,    99,   108,    99,    99,   111,    99,  1019,    99,
      99,   107,  1023,   106,   100,    99,    99,    16,   103,    99,
      99,   942,   100,   944,   106,   106,  1037,     3,     4,   106,
       6,     7,     8,     9,    10,    11,    12,    13,    14,   106,
     103,    99,   103,   102,    92,   104,    22,   113,   100,   108,
     106,   972,   111,   103,    99,    99,    73,     4,     4,   848,
    1024,   104,  1017,     3,     4,   813,     6,     7,     8,     9,
      10,    11,    12,    13,    14,   855,   149,   248,   247,   496,
     102,   291,    22,   105,   744,   119,   108,     3,     4,   111,
       6,     7,     8,     9,    10,    11,    12,    13,    14,     3,
       4,   553,     6,     7,     8,     9,    10,    11,    12,    13,
      14,   768,   539,   570,   979,   894,   511,   722,    22,   297,
     464,   525,   944,   942,   662,   149,   102,   657,   104,   990,
      66,   196,   108,     3,     4,   111,     6,     7,     8,     9,
      10,    11,    12,    13,    14,   791,   692,   805,   602,   149,
       3,     4,    22,     6,     7,     8,     9,    10,    11,    12,
      13,    14,   102,   800,   603,   105,   807,   423,   108,   814,
      -1,   111,     3,     4,    -1,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    -1,   344,   102,    -1,   104,   105,
      -1,    22,   108,    -1,    -1,   111,    -1,    -1,   102,    -1,
     104,    -1,    -1,    -1,   108,     3,     4,   111,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    22,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   102,    -1,   104,    -1,    -1,    -1,   108,    -1,
      -1,   111,    -1,    -1,    -1,    -1,    99,    -1,    -1,   102,
      -1,    -1,    -1,    -1,    -1,   108,     3,     4,   111,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    -1,    -1,
      -1,   102,    -1,    -1,    -1,    22,    -1,   108,     3,     4,
     111,     6,     7,     8,     9,    10,    11,    12,    13,    14,
       3,     4,    -1,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    -1,    -1,   102,    -1,    -1,    -1,    -1,    -1,
     108,     3,     4,   111,     6,     7,     8,     9,    10,    11,
      12,    13,    14,     3,     4,    -1,     6,     7,     8,     9,
      10,    11,    12,    13,    14,     3,     4,    -1,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   102,    -1,    -1,    -1,    -1,
      -1,   108,     3,     4,   111,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    -1,    -1,    -1,   102,    -1,    -1,
     105,    -1,    -1,   108,    -1,    -1,   111,    -1,    -1,   102,
      -1,   104,    -1,    -1,    -1,   108,     3,     4,   111,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    -1,    -1,
     102,    -1,   104,    -1,    -1,    -1,   108,    -1,     6,   111,
     100,    -1,   102,    -1,    -1,    13,    14,    15,   108,    -1,
      -1,   111,    -1,    -1,   102,   103,    24,    -1,    -1,    -1,
     108,     3,     4,   111,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,   100,
      -1,   102,    -1,    -1,    -1,    -1,    -1,   108,     3,     4,
     111,     6,     7,     8,     9,    10,    11,    12,    13,    14,
       3,     4,    -1,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    -1,    -1,    -1,   102,    -1,   104,    -1,    -1,
      -1,   108,    -1,    -1,   111,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   100,    -1,   102,   103,    -1,   105,   106,    -1,
     108,   109,   110,   111,   112,     3,     4,    -1,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    -1,    -1,    -1,
     102,    -1,    -1,    -1,    -1,    -1,   108,    -1,    -1,   111,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   108,    -1,    -1,   111,    -1,    -1,   102,
      -1,   104,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
       0,     1,    -1,     3,     4,     5,     3,     4,    -1,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    -1,    -1,
      -1,    -1,    -1,    -1,   102,    -1,   104,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    -1,    76,    77,    78,    79,
      80,    81,    82,    83,    84,    85,    86,    87,    88,    89,
      90,    91,    -1,    -1,    94,    -1,    96,     0,     1,    99,
       3,     4,     5,    -1,    -1,   102,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    -1,    76,    77,    78,    79,    80,    81,    82,
      83,    84,    85,    86,    87,    88,    89,    90,    91,    -1,
      -1,    94,     1,    96,     3,     4,    99,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      -1,    70,    71,    72,    73,    74,    -1,    76,    77,    78,
      79,    80,    81,    82,    83,    84,    85,    86,    87,    88,
      89,    90,    91,     3,     4,    94,    -1,    96,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,    -1,    29,
      30,    31,    -1,    -1,    34,    -1,    -1,    -1,    38,    -1,
      -1,    41,    42,    -1,    44,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    54,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    63,    -1,    -1,    66,    67,    -1,    -1,
      70,    -1,    -1,    -1,    -1,    -1,    76,    77,    -1,    79,
      -1,    81,    -1,    83,    -1,    85,    86,    -1,    -1,    89,
      -1,    -1,    92,    -1,    94,    -1,    96
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned short yystos[] =
{
       0,     1,     3,     4,     5,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    76,    77,    78,    79,    80,    81,    82,
      83,    84,    85,    86,    87,    88,    89,    90,    91,    94,
      96,    99,   115,   116,   117,   118,   119,   120,   121,   122,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,   134,   135,   136,   137,   138,   139,   140,   142,   143,
     144,   145,   146,   147,   148,   149,   150,   151,   155,   156,
     157,   162,   169,   176,   182,   183,   184,   185,   188,   189,
     190,   192,   193,   214,   215,   226,   227,   228,   234,   236,
     238,   239,   240,   243,   248,   249,   254,   256,   259,   274,
     277,   279,   280,   281,   282,   283,   285,   286,   287,   288,
     289,   291,   295,   296,   297,   299,   300,   301,   305,   306,
     307,   310,   311,   313,   314,   315,   316,   317,   318,   319,
     321,   324,   326,   327,   328,   329,   332,   342,   344,   346,
     348,   349,   350,   351,   352,   353,   356,   369,   373,   377,
     380,   403,   408,   411,   412,   413,   415,   416,    99,   120,
     123,     3,     4,     6,     7,     8,     9,    10,    11,    12,
      13,    14,   102,   104,   355,   381,   382,   395,   396,   397,
     398,   404,   407,   411,   412,   413,     3,     4,   105,   159,
     241,   242,   414,   102,   420,   414,   102,     3,     4,    99,
     416,   345,    24,   106,   159,   170,   171,   172,   173,   174,
     175,   414,    99,    99,   416,   102,   260,   261,   264,   265,
     272,   277,   102,   158,   159,   414,   420,   102,    67,    99,
     416,    99,    99,   416,    99,   416,    99,   416,   414,   163,
     235,   414,    99,   416,   357,   102,    13,   347,   237,   414,
     106,   177,   178,   179,   102,   343,   102,   229,     6,    13,
     320,   414,   102,   241,   244,   245,   355,   141,    99,   108,
     111,   392,   393,   394,   395,   399,    99,   106,   257,   258,
     414,   320,   241,   355,   325,     0,   117,    99,   414,   414,
     414,   147,   414,    99,   414,   105,   105,   103,   159,   197,
     198,   204,   414,    25,   104,   196,   103,   104,   159,   194,
     196,   205,   206,   213,   414,   103,   205,    75,   148,   188,
     192,   193,   216,   218,    26,   107,   278,   102,   414,   420,
      92,   131,   288,   415,   420,   102,    99,   416,    95,    99,
     411,   412,   413,    22,   102,   322,   339,   340,   341,   386,
     387,   388,   389,   390,   391,   392,   102,   355,   102,   104,
     354,   386,   102,   354,   102,   354,   102,   374,   102,   409,
     102,   409,   102,    88,   289,   311,   105,   386,    99,   103,
     409,   102,   409,    24,   409,   102,   105,    99,   103,   102,
       3,     4,   250,   251,   411,   413,   414,     6,   421,   105,
     302,   303,   304,   386,    99,   102,   106,   414,    99,   171,
     173,    99,   170,   174,   103,    99,   270,   271,   272,   403,
     413,    99,   103,   261,   103,   106,   252,   253,   411,   413,
     414,    99,   103,   421,   308,   102,    99,    99,    99,    99,
      99,   102,   102,   164,    99,   103,    99,   102,   290,    99,
     102,    99,   103,   414,    99,   178,   180,   181,   414,   255,
     411,   102,   231,   232,   414,   231,    99,   246,   414,    99,
      99,   103,    99,   103,   414,   393,   393,   108,   111,   104,
     106,    23,    99,   414,    99,   103,    99,    99,    99,   103,
     102,    99,    99,   102,    99,   102,    99,   102,    99,   105,
     105,    28,    45,    62,    72,    78,    80,    87,    91,   186,
     187,   106,    99,   103,   106,   201,     6,   418,   191,   386,
     414,   186,     6,   102,   222,   419,   104,   106,   195,    99,
     103,   106,   107,   104,   186,   205,    99,    99,   102,    99,
     103,   275,   284,   420,    99,   102,   103,   421,    99,   421,
     298,    99,   102,   107,   391,   339,   386,    99,   103,   323,
      20,    21,    19,    18,    17,   335,   336,   354,   386,   414,
      99,   103,   335,    99,   335,    99,   335,    99,   100,   104,
     378,   379,   386,    99,   105,   392,   410,   370,   371,   372,
     411,   386,   405,   406,   100,   339,   383,   384,   386,   392,
     396,   405,   242,   242,   104,   105,   160,   161,   392,   402,
     100,   103,   102,   107,    93,   304,   100,   103,   105,   335,
     106,    99,   103,   261,   265,   262,   100,   103,   102,   107,
     159,   103,   386,   292,   104,   152,   153,   154,   414,   165,
     166,   167,   168,   414,    99,   103,   414,     6,    13,    14,
      15,    24,   102,   103,   105,   106,   108,   109,   110,   111,
     112,   358,   359,   360,   361,   362,   363,   364,   365,   366,
     386,   335,   414,   106,   181,   103,   100,   103,   337,   354,
     414,   100,   103,   233,   230,   103,   245,   330,    99,   393,
     393,   394,   394,   394,   106,   258,   333,   335,   152,   152,
     152,   197,   205,   102,   103,   202,   198,   199,   107,   100,
     107,   104,   225,   392,   401,   222,   209,   223,   224,   225,
     414,   206,   207,   385,   386,   222,    99,   219,   217,   386,
     100,   103,   421,   284,   102,    99,   103,   386,   309,   312,
     392,   400,   103,   340,    99,   388,   388,   389,   390,   391,
     100,   103,   107,   339,   100,   100,   100,   375,   420,   100,
     103,   100,   410,   105,   100,   103,   100,   103,    99,   100,
     103,   100,   100,   103,   105,    99,   251,   160,   404,   411,
     411,   303,   304,   100,   271,   414,     6,    12,    13,    14,
     108,   111,   266,   267,   268,   269,   398,   414,   417,   418,
      99,   251,   160,   404,   411,   100,   386,   100,   103,   100,
     103,   103,   409,   102,   409,   102,   359,     6,     6,   367,
     100,   360,   100,   100,    99,   411,   100,   103,   107,    99,
     232,   107,    99,   159,   247,   414,   339,   339,   100,   100,
     100,   100,    99,    99,   160,   187,   266,   266,   385,   386,
     100,   106,   266,   100,   103,   107,   266,    16,   220,   221,
     218,   276,   103,   399,   420,   100,   284,   420,   100,   386,
      99,   103,   411,    99,   103,   339,   336,   354,    99,    99,
      99,    99,    99,   421,   376,   379,   100,   100,   410,   372,
     411,   406,   386,   161,   104,   402,   100,    99,    99,   107,
     398,   398,   103,   263,   104,   100,    99,   100,    99,   154,
     166,   166,   405,   165,   100,   399,    99,    99,    99,   338,
     414,   354,   385,   100,   331,   334,    99,    99,    99,   100,
     203,   200,   211,   210,   224,   225,   208,   108,   100,   103,
      99,   399,    99,   421,    99,   100,   421,    99,   100,   400,
     107,   339,    99,    99,   100,   273,   401,   267,   106,   269,
     414,   293,   100,   100,   368,   107,    99,    99,   106,   106,
     266,   106,   106,    16,   221,    99,    99,   103,    99,   103,
     312,    99,   100,   103,    92,   294,   113,   354,   212,   420,
     400,   100,   401,    99,   416,   106,   421,   103,    99,    99,
     401
};

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)		\
   ((Current).first_line   = (Rhs)[1].first_line,	\
    (Current).first_column = (Rhs)[1].first_column,	\
    (Current).last_line    = (Rhs)[N].last_line,	\
    (Current).last_column  = (Rhs)[N].last_column)
#endif

/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YYDSYMPRINT(Args)			\
do {						\
  if (yydebug)					\
    yysymprint Args;				\
} while (0)

# define YYDSYMPRINTF(Title, Token, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr, 					\
                  Token, Value);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short *bottom, short *top)
#else
static void
yy_stack_print (bottom, top)
    short *bottom;
    short *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %u), ",
             yyrule - 1, yylno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname [yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname [yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YYDSYMPRINT(Args)
# define YYDSYMPRINTF(Title, Token, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if defined (YYMAXDEPTH) && YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

#endif /* !YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  if (yytype < YYNTOKENS)
    {
      YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
# ifdef YYPRINT
      YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
    }
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yytype, yyvaluep)
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  switch (yytype)
    {

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;



#define YYPOPSTACK   (yyvsp--, yyssp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YYDSYMPRINTF ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %s, ", yytname[yytoken]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;


  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 6:
#line 384 "fortran.y"
    {
				/* Create id token for prog if unnamed.  NOTE:
				   this clobbers $1.class, value, src_text.
				 */
			  if(current_module_hash == -1) {
			    implied_id_token(&(yyvsp[0]),unnamed_prog);
			    def_function(
					 type_PROGRAM,	/* type */
					 size_DEFAULT,	/* size */
					 (char *)NULL,	/* size text */
					 &(yyvsp[0]),		/* name */
					 (Token*)NULL);	/* args */
			    current_module_hash =
			      def_curr_module(&(yyvsp[0]));
			    current_module_type = type_PROGRAM;

				/* Pretend this is a PROGRAM statement */
			    if(style_req_prog_stmt) {
				warning(yyvsp[0].line_num,yyvsp[0].col_num,
			"Program does not start with a PROGRAM statement");
			    }
			    push_block(&(yyval),tok_PROGRAM,subprog,
				       hashtab[current_module_hash].name,
				       NO_LABEL);
				/* It is possible for a block construct to
				   be the initial statement, and if so it
				   has earlier been pushed onto stack.  Detect
				   this situation and swap stack entries to
				   make them nest correctly.
				 */
			    if(block_depth > 1 &&
			       block_stack[block_depth-2].first_line == yyvsp[0].line_num) {
				BlockStack temp = block_stack[block_depth-1];
				block_stack[block_depth-1] = block_stack[block_depth-2];
				block_stack[block_depth-2] = temp;
			    }
			  }

					/* Handle END statement.  Note that
					   curr_stmt_class of structured END
					   stmts have been merged into tok_END.
					 */
			  if(curr_stmt_class == tok_END) {
			    if(prev_stmt_class != tok_RETURN)
			      (void)do_RETURN(current_module_hash,&(yyvsp[0]));
			    pop_block(&(yyval),yyval.tclass,
				      curr_stmt_name,NO_LABEL);

			    END_processing(&(yyval));
			    goto_flag = prev_goto = FALSE;
			  }
			  prev_stmt_class = curr_stmt_class;
			  integer_context = FALSE;
			  in_attrbased_typedecl = FALSE;
			  true_prev_stmt_line_num = yyval.line_num;
			}
    break;

  case 10:
#line 451 "fortran.y"
    {
				/* Treat END PROGRAM et al as plain END */
			    curr_stmt_class = tok_END;
			}
    break;

  case 11:
#line 458 "fortran.y"
    {
				/* Put definition of label into table, and
				   if it marks end of a DO range, pop block.
				 */
			  int do_label = def_label(&(yyvsp[-1]),labeled_stmt_type);
			  if( do_label || yyvsp[0].tclass == tok_ENDDO ) {
			    if(is_true(NOT_DO_TERMINAL_STMT,yyvsp[0].TOK_flags)) {
			      syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
			"statement cannot be terminal statement of a DO loop");
			    }
			    else {
			      pop_block(&(yyvsp[0]),yyvsp[0].tclass,curr_stmt_name,
				      do_label?
					(LABEL_t)(yyvsp[-1].value.integer):
					NO_LABEL);
			    }
			  }

				/* Issue picky warnings about labeled
				   statements.  FORMAT has an excuse
				   for existing, so warnings for it
				   are separately controlled.  */
			  if( style_labeled_exec &&
			      curr_stmt_class != tok_FORMAT ) {
			    warning(yyvsp[-1].line_num,yyvsp[-1].col_num,
				    "obsolescent feature: labeled statement");
			  }
			  else if( style_labeled_format &&
			      curr_stmt_class == tok_FORMAT ) {
			    warning(yyvsp[0].line_num,yyvsp[0].col_num,
				    "obsolescent feature: FORMAT statement");
			  }

			  if(executable_stmt)
			    prev_goto = goto_flag;
			  yyval = yyvsp[0];
			}
    break;

  case 12:
#line 496 "fortran.y"
    {
			  if(executable_stmt) {
			    if(prev_goto)
				syntax_error(yyvsp[0].line_num, NO_COL_NUM,
					"No path to this statement");
			    prev_goto = goto_flag;
			  }

			  if( curr_stmt_class == tok_FORMAT &&
			      misc_warn ) {
			      syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
				      "FORMAT statement has no label");
			  }
			  if( yyvsp[0].tclass == tok_ENDDO )
			    pop_block(&(yyvsp[0]),yyvsp[0].tclass,curr_stmt_name,NO_LABEL);
			}
    break;

  case 13:
#line 515 "fortran.y"
    {
			    exec_stmt_count = 0;
			    executable_stmt = FALSE;
			    labeled_stmt_type = LAB_SPECIFICATION;
			    push_block(&(yyvsp[0]),yyvsp[0].tclass,subprog,
				       hashtab[current_module_hash].name,
				       NO_LABEL);
			}
    break;

  case 14:
#line 524 "fortran.y"
    {
			    executable_stmt = FALSE;
			/* labeled_stmt_type set in lower productions */
			}
    break;

  case 15:
#line 529 "fortran.y"
    {	/* handle statement functions correctly */
			  if(is_true(STMT_FUNCTION_EXPR, yyvsp[0].TOK_flags)
				     && stmt_sequence_no <= SEQ_STMT_FUN) {
			    stmt_sequence_no = SEQ_STMT_FUN;
			    f90_stmt_sequence_no = F90_SEQ_SPECIF;
			    executable_stmt = FALSE;
			  }
			  else {
			    stmt_sequence_no = SEQ_EXEC;
			    f90_stmt_sequence_no = F90_SEQ_EXEC;
			    ++exec_stmt_count;
			    executable_stmt = TRUE;
			  }
			  labeled_stmt_type = LAB_EXECUTABLE;
			}
    break;

  case 16:
#line 545 "fortran.y"
    {
			    stmt_sequence_no = SEQ_EXEC;
			    f90_stmt_sequence_no = F90_SEQ_EXEC;
			    ++exec_stmt_count;
			    executable_stmt = TRUE;
			    labeled_stmt_type = LAB_EXECUTABLE;
			}
    break;

  case 17:
#line 553 "fortran.y"
    {
			    executable_stmt = TRUE;
			    if(stmt_sequence_no == 0)
			      stmt_sequence_no = SEQ_HEADER;
			    if(f90_stmt_sequence_no == 0)
			      f90_stmt_sequence_no = SEQ_HEADER;
			    complex_const_allowed = FALSE; /* turn off flags */
			    inside_format=FALSE;
			    integer_context = FALSE;
			    in_assignment_stmt = FALSE;
			    yyval.line_num = prev_stmt_line_num; /* best guess */
			    labeled_stmt_type = LAB_EXECUTABLE;
			    yyerrok; /* (error message already given) */
			}
    break;

  case 18:
#line 570 "fortran.y"
    {
			    current_module_type = type_PROGRAM;
			}
    break;

  case 19:
#line 574 "fortran.y"
    {
			    current_module_type = type_SUBROUTINE;
			}
    break;

  case 20:
#line 578 "fortran.y"
    {
			    current_module_type = type_SUBROUTINE;
			}
    break;

  case 21:
#line 582 "fortran.y"
    {
			    current_module_type = type_BLOCK_DATA;
			}
    break;

  case 23:
#line 590 "fortran.y"
    {
			  if( def_label(&(yyvsp[-1]),LAB_EXECUTABLE) ) {
			    syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
			"statement cannot be terminal statement of a DO loop");
				/* Pop it anyway to keep stack consistent */
			    pop_block(&(yyvsp[0]),yyvsp[0].tclass,curr_stmt_name,
				      (LABEL_t)(yyvsp[-1].value.integer));
			  }
			  yyval = yyvsp[0];
			}
    break;

  case 24:
#line 606 "fortran.y"
    {
			    curr_stmt_name = NULL;
			}
    break;

  case 28:
#line 618 "fortran.y"
    {
			    curr_stmt_name = hashtab[yyvsp[-1].value.integer].name;
			}
    break;

  case 33:
#line 630 "fortran.y"
    {
#ifdef ALLOW_INCLUDE
			  if(f77_include) {
			      nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num,0,0);
			  }
 			  open_include_file(yyvsp[-1].value.string,yyvsp[-2].line_num);
#else
			  syntax_error(yyvsp[-2].line_num,yyvsp[-2].col_num,
				"statement not permitted");
#endif
 			}
    break;

  case 34:
#line 649 "fortran.y"
    {
			     if(stmt_sequence_no < SEQ_IMPLICIT) {
				stmt_sequence_no = SEQ_IMPLICIT;
			     }
			     if(f90_stmt_sequence_no < F90_SEQ_IMPLICIT_NONE) {
				stmt_sequence_no = F90_SEQ_IMPLICIT_NONE;
			     }
			     /* labeled_stmt_type set below  */
			}
    break;

  case 35:
#line 659 "fortran.y"
    {
			     if(stmt_sequence_no < SEQ_IMPLICIT) {
				   stmt_sequence_no = SEQ_IMPLICIT;
			     }
			     else if(stmt_sequence_no > SEQ_SPECIF) {
			       check_stmt_sequence(&(yyvsp[0]),SEQ_SPECIF);
			     }
			     if(f90_stmt_sequence_no < F90_SEQ_IMPLICIT) {
				   f90_stmt_sequence_no = F90_SEQ_IMPLICIT;
			     }
			     else if(f90_stmt_sequence_no > F90_SEQ_SPECIF) {
			       check_f90_stmt_sequence(&(yyvsp[0]),F90_SEQ_SPECIF);
			     }
			     labeled_stmt_type = LAB_SPECIFICATION;
			}
    break;

  case 36:
#line 675 "fortran.y"
    {
			  check_stmt_sequence(&(yyvsp[0]),SEQ_IMPLICIT);
			/* f90 seq checks done at implicit_stmt */
			  labeled_stmt_type = LAB_SPECIFICATION;
			}
    break;

  case 37:
#line 681 "fortran.y"
    {
			     if(stmt_sequence_no < SEQ_STMT_FUN) {
				stmt_sequence_no = SEQ_STMT_FUN;
		 	     }
			     if(f90_stmt_sequence_no <= F90_SEQ_SPECIF) {
				f90_stmt_sequence_no = F90_SEQ_SPECIF;
		 	     }
			     else {
			       check_f90_stmt_sequence(&(yyvsp[0]),F90_SEQ_EXEC);
			     }
			     labeled_stmt_type = LAB_SPECIFICATION;
			}
    break;

  case 38:
#line 694 "fortran.y"
    {
			  check_stmt_sequence(&(yyvsp[0]),SEQ_SPECIF);
			  check_f90_stmt_sequence(&(yyvsp[0]),F90_SEQ_SPECIF);
			  labeled_stmt_type = LAB_SPECIFICATION;
			}
    break;

  case 39:
#line 702 "fortran.y"
    {
			     goto_flag = prev_goto = FALSE;
			     labeled_stmt_type = LAB_SPECIFICATION;
			}
    break;

  case 40:
#line 707 "fortran.y"
    {
			     labeled_stmt_type = LAB_FORMAT;
			}
    break;

  case 54:
#line 731 "fortran.y"
    {
			    goto_flag=TRUE;
			    make_true(NOT_DO_TERMINAL_STMT,yyval.TOK_flags);
			}
    break;

  case 55:
#line 736 "fortran.y"
    {
			    goto_flag=FALSE;
			}
    break;

  case 57:
#line 743 "fortran.y"
    {
			     if( f95_assign ) {
			       nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,0,f95_assign);
			       msg_tail(": assigned GOTO");
			     }
			}
    break;

  case 58:
#line 750 "fortran.y"
    {
			    if(style_req_block_if) {
				warning(if_line_num, if_col_num,
					"non-structured IF statement");
			    }
			}
    break;

  case 59:
#line 757 "fortran.y"
    {
			  check_construct_name_match(&(yyvsp[0]),
				     curr_stmt_name);
			}
    break;

  case 68:
#line 772 "fortran.y"
    {
			   record_io_usage(&(yyvsp[0]));
			}
    break;

  case 72:
#line 781 "fortran.y"
    {
			     /* If form not defined by now, READ is unformatted.
				If no REC=num was seen, then it is sequential.
			      */
			   if(current_io_form == IO_FORM_DEFAULT)
			      current_io_form = IO_FORM_UNFORMATTED;
			   if(current_io_access == IO_ACCESS_DEFAULT)
			      current_io_access = IO_ACCESS_SEQUENTIAL;
			}
    break;

  case 74:
#line 792 "fortran.y"
    {
			   if(current_io_form == IO_FORM_DEFAULT)
			      current_io_form = IO_FORM_UNFORMATTED;
			   if(current_io_access == IO_ACCESS_DEFAULT)
			      current_io_access = IO_ACCESS_SEQUENTIAL;
			}
    break;

  case 77:
#line 801 "fortran.y"
    {
			  /* In OPEN, default ACCESS is SEQUENTIAL, and default FORM
			     is FORMATTED for ACCESS=SEQUENTIAL, UNFORMATTED for
			     ACCESS=DIRECT.
			   */
			   if(current_io_access == IO_ACCESS_DEFAULT)
			      current_io_access = IO_ACCESS_SEQUENTIAL;
			   if(current_io_form == IO_FORM_DEFAULT) {
			     if(current_io_access == IO_ACCESS_SEQUENTIAL)
			       current_io_form = IO_FORM_FORMATTED;
			     else
			       current_io_form = IO_FORM_UNFORMATTED;
			   }
			}
    break;

  case 80:
#line 818 "fortran.y"
    {
			     /* These statements only apply to sequential access */
			   current_io_access = IO_ACCESS_SEQUENTIAL;
			}
    break;

  case 84:
#line 831 "fortran.y"
    {
			    goto_flag=FALSE;
			}
    break;

  case 85:
#line 835 "fortran.y"
    {
			    prev_goto = goto_flag = FALSE;
			    make_true(NOT_DO_TERMINAL_STMT,yyval.TOK_flags);
			}
    break;

  case 86:
#line 840 "fortran.y"
    {
			    goto_flag = TRUE;
			    make_true(NOT_DO_TERMINAL_STMT,yyval.TOK_flags);
			}
    break;

  case 87:
#line 845 "fortran.y"
    {
			    prev_goto = goto_flag = FALSE;
			    make_true(NOT_DO_TERMINAL_STMT,yyval.TOK_flags);
			}
    break;

  case 89:
#line 854 "fortran.y"
    {
			/* Note that $1 at this point is expr, not tok_IF.
			   This is undesirable for our purpose here, but
			   needed for more important stuff elsewhere.
			 */
			    push_block(&(yyvsp[0]),tok_IF,construct,curr_stmt_name,NO_LABEL);
			    make_true(NOT_DO_TERMINAL_STMT,yyval.TOK_flags);
			}
    break;

  case 90:
#line 863 "fortran.y"
    {	/* Flag DO w/o label or DO WHILE forms here */
			  if(is_true(NONSTD_USAGE_FLAG,yyvsp[0].TOK_flags))
#ifdef ALLOW_DO_ENDDO
			    if(f77_do_enddo)
				nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,0,0);
#else
			    syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
				    "Nonstandard syntax");
#endif
			  push_block(&(yyvsp[0]),tok_DO,construct,curr_stmt_name,
				     (LABEL_t)(yyvsp[0].tsubclass));
			  make_true(NOT_DO_TERMINAL_STMT,yyval.TOK_flags);
				/* Record hash index of DO variable in the
				   block stack entry for this statement.
				 */
			  block_stack[block_depth-1].do_var_hash = yyvsp[0].value.integer;
			}
    break;

  case 91:
#line 882 "fortran.y"
    {
#ifdef ALLOW_DO_ENDDO
			    if(f77_do_enddo)
				nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,0,0);
#else
			    syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
				    "Nonstandard syntax");
#endif
				/* pop_block is done at stmt production, where
				   optional label can be checked for match.
				 */
			}
    break;

  case 92:
#line 897 "fortran.y"
    {
			    pop_block(&(yyvsp[0]),yyvsp[0].tclass,curr_stmt_name,NO_LABEL);
			    push_block(&(yyvsp[0]),yyvsp[0].tclass,construct,curr_stmt_name,NO_LABEL);
			}
    break;

  case 93:
#line 902 "fortran.y"
    {
			    pop_block(&(yyvsp[0]),yyvsp[0].tclass,curr_stmt_name,NO_LABEL);
			    push_block(&(yyvsp[0]),yyvsp[0].tclass,construct,curr_stmt_name,NO_LABEL);
			}
    break;

  case 94:
#line 907 "fortran.y"
    {
			    pop_block(&(yyvsp[0]),yyvsp[0].tclass,curr_stmt_name,NO_LABEL);
			}
    break;

  case 95:
#line 913 "fortran.y"
    {
			    pop_block(&(yyvsp[0]),yyvsp[0].tclass,curr_stmt_name,NO_LABEL);
			    push_block(&(yyvsp[0]),yyvsp[0].tclass,construct,curr_stmt_name,NO_LABEL);
			}
    break;

  case 96:
#line 918 "fortran.y"
    {
			    pop_block(&(yyvsp[0]),tok_CASE,curr_stmt_name,NO_LABEL);
			    push_block(&(yyvsp[0]),tok_CASE,construct,curr_stmt_name,NO_LABEL);
			}
    break;

  case 97:
#line 923 "fortran.y"
    {
			    pop_block(&(yyvsp[0]),yyvsp[0].tclass,curr_stmt_name,NO_LABEL);
			}
    break;

  case 98:
#line 929 "fortran.y"
    {check_seq_header(&(yyvsp[0]));}
    break;

  case 99:
#line 931 "fortran.y"
    {
			     def_function(
					  type_PROGRAM,	/* type */
					  size_DEFAULT,	/* size */
					  (char *)NULL,	/* size text */
					  &(yyvsp[-1]),	/* name */
					  (Token*)NULL);/* args */
			     current_module_hash =
			       def_curr_module(&(yyvsp[-1]));
			}
    break;

  case 100:
#line 948 "fortran.y"
    {
			  do_ENTRY(&(yyvsp[-1]),(Token*)NULL
				   ,current_module_hash);
			}
    break;

  case 101:
#line 953 "fortran.y"
    {
			  do_ENTRY(&(yyvsp[-4]),&(yyvsp[-2])
				   ,current_module_hash);
#ifdef DEBUG_PARSER
			     if(debug_parser)
				print_exprlist("entry stmt",&(yyvsp[-2]));
#endif
			}
    break;

  case 103:
#line 969 "fortran.y"
    {
			     if(f77_function_noparen || f90_function_noparen) {
				nonstandard(yyvsp[-1].line_num,
			     (unsigned)(yyvsp[-1].col_num+strlen(token_name(&yyvsp[-1]))),
					    f90_function_noparen,0);
				msg_tail(": parentheses required");
			     }
			 def_function(
				      current_datatype,
				      current_typesize,
				      current_len_text,
				      &(yyvsp[-1]),
				      (Token*)NULL);
			 current_module_hash=
			   def_curr_module(&(yyvsp[-1]));
			}
    break;

  case 104:
#line 987 "fortran.y"
    {
			 def_function(
				      current_datatype,
				      current_typesize,
				      current_len_text,
				      &(yyvsp[-4]),
				      &(yyvsp[-2]));
			 current_module_hash=
			   def_curr_module(&(yyvsp[-4]));
#ifdef DEBUG_PARSER
			 if(debug_parser)
			   print_exprlist("function stmt",&(yyvsp[-2]));
#endif
			}
    break;

  case 105:
#line 1002 "fortran.y"
    {
			     if(f77_function_noparen || f90_function_noparen) {
				nonstandard(yyvsp[-1].line_num,
			      (unsigned)(yyvsp[-1].col_num+strlen(token_name(&yyvsp[-1]))),
					    f90_function_noparen,0);
				msg_tail(": parentheses required");
			     }
			 def_function(
				      type_UNDECL,
				      size_DEFAULT,
				      (char *)NULL,
				      &(yyvsp[-1]),
				      (Token*)NULL);
			 current_module_hash=
			   def_curr_module(&(yyvsp[-1]));
			}
    break;

  case 106:
#line 1020 "fortran.y"
    {
			 def_function(
				      type_UNDECL,	/* type */
				      size_DEFAULT,	/* size */
				      (char *)NULL,	/* size text */
				      &(yyvsp[-4]),		/* name */
				      &(yyvsp[-2]));		/* args */
			 current_module_hash=
			   def_curr_module(&(yyvsp[-4]));
#ifdef DEBUG_PARSER
			 if(debug_parser)
			   print_exprlist("function stmt",&(yyvsp[-2]));
#endif
			}
    break;

  case 107:
#line 1037 "fortran.y"
    {
			    yyval = yyvsp[0]; /* needed for block opener info */
			}
    break;

  case 109:
#line 1046 "fortran.y"
    {
			  check_seq_header(&(yyvsp[0]));
			}
    break;

  case 114:
#line 1065 "fortran.y"
    {
			  def_function(
				       type_SUBROUTINE,
				       size_DEFAULT,
				       (char *)NULL,
				       &(yyvsp[-1]),
				       (Token*)NULL);
			  current_module_hash=
			    def_curr_module(&(yyvsp[-1]));
			}
    break;

  case 115:
#line 1077 "fortran.y"
    {
			  def_function(
				       type_SUBROUTINE,
				       size_DEFAULT,
				       (char *)NULL,
				       &(yyvsp[-4]),
				       &(yyvsp[-2]));
			  current_module_hash=
			    def_curr_module(&(yyvsp[-4]));
#ifdef DEBUG_PARSER
			  if(debug_parser)
			    print_exprlist("subroutine stmt",&(yyvsp[-2]));
#endif
			}
    break;

  case 116:
#line 1094 "fortran.y"
    {
			  check_seq_header(&(yyvsp[0]));
			}
    break;

  case 117:
#line 1100 "fortran.y"
    {
			    yyval.next_token = (Token*)NULL;
			}
    break;

  case 119:
#line 1107 "fortran.y"
    {
			    yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			}
    break;

  case 120:
#line 1111 "fortran.y"
    {
			    yyval.next_token = append_token(yyvsp[-2].next_token,&(yyvsp[0]));
			}
    break;

  case 121:
#line 1117 "fortran.y"
    {
			     def_arg_name(&(yyvsp[0]));
			     primary_id_expr(&(yyvsp[0]),&(yyval));
			}
    break;

  case 122:
#line 1122 "fortran.y"
    {
			     yyval.TOK_type = type_byte(class_LABEL,type_LABEL);
			     yyval.size = size_DEFAULT;
			     yyval.TOK_flags = 0;
			     yyval.left_token = (Token *)NULL;
			     label_dummy_arg_count++;
			}
    break;

  case 123:
#line 1135 "fortran.y"
    {
				  /* form name %DATnn */
			  ++block_data_number;
			  (void)sprintf(unnamed_block_data+4,"%02d",
					block_data_number%100);
			  implied_id_token(&(yyvsp[-1]),unnamed_block_data);

			  def_function(
				       type_BLOCK_DATA,
				       size_DEFAULT,
				       (char *)NULL,
				       &(yyvsp[-1]),
				       (Token*)NULL);
			  current_module_hash=
			    def_curr_module(&(yyvsp[-1]));
			}
    break;

  case 124:
#line 1152 "fortran.y"
    {
			  def_function(
				       type_BLOCK_DATA,
				       size_DEFAULT,
				       (char *)NULL,
				       &(yyvsp[-1]),
				       (Token*)NULL);
			  current_module_hash=
			    def_curr_module(&(yyvsp[-1]));
			}
    break;

  case 125:
#line 1165 "fortran.y"
    {
			  check_seq_header(&(yyvsp[0]));
			}
    break;

  case 129:
#line 1180 "fortran.y"
    {
			     def_array_dim(&(yyvsp[-3]),&(yyvsp[-1]));
			}
    break;

  case 130:
#line 1187 "fortran.y"
    {
			     yyval.TOK_dims = 1;
			     yyval.TOK_elts = yyvsp[0].TOK_elts;
			     yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			}
    break;

  case 131:
#line 1193 "fortran.y"
    {
			     yyval.TOK_dims = yyvsp[-2].TOK_dims + 1; /* one more dimension */
			     yyval.TOK_elts = yyvsp[-2].TOK_elts * yyvsp[0].TOK_elts;
			     yyval.next_token = append_token(yyvsp[-2].next_token,&(yyvsp[0]));
			}
    break;

  case 132:
#line 1201 "fortran.y"
    {
			      if( datatype_of(yyvsp[0].TOK_type) == type_INTEGER
				 && is_true(EVALUATED_EXPR,yyvsp[0].TOK_flags) )
				yyval.TOK_elts = yyvsp[0].value.integer;
			      else
				yyval.TOK_elts = 0;
			}
    break;

  case 133:
#line 1209 "fortran.y"
    {	/* avoid getting 0 - 0 + 1 = 1 if bounds nonconstant */
			      if( datatype_of(yyvsp[-2].TOK_type) == type_INTEGER
				 && is_true(EVALUATED_EXPR,yyvsp[-2].TOK_flags)
				 && datatype_of(yyvsp[0].TOK_type) == type_INTEGER
				 && is_true(EVALUATED_EXPR,yyvsp[0].TOK_flags) )
				yyval.TOK_elts = yyvsp[0].value.integer - yyvsp[-2].value.integer + 1;
			      else
				yyval.TOK_elts = 0;

			      yyval.left_token = add_tree_node(&(yyvsp[-1]),&(yyvsp[-2]),&(yyvsp[0]));
			}
    break;

  case 134:
#line 1221 "fortran.y"
    {
			     yyval.TOK_elts = 0;
			     yyval.left_token = (Token *)NULL;
			}
    break;

  case 135:
#line 1226 "fortran.y"
    {
			     yyval.TOK_elts = 0;
			     yyvsp[0].left_token = (Token *)NULL;
			     yyval.left_token = add_tree_node(&(yyvsp[-1]),&(yyvsp[-2]),&(yyvsp[0]));
			}
    break;

  case 136:
#line 1232 "fortran.y"
    {
			     if( f77_pointers ) {
				  nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,0,0);
				  msg_tail(": deferred-shape array spec");
			     }
			}
    break;

  case 137:
#line 1241 "fortran.y"
    {equivalence_flag = TRUE;}
    break;

  case 138:
#line 1242 "fortran.y"
    {equivalence_flag = FALSE;}
    break;

  case 141:
#line 1250 "fortran.y"
    {
			  equivalence(&(yyvsp[-2]), &(yyvsp[0]));
			}
    break;

  case 142:
#line 1254 "fortran.y"
    {
			  equivalence(&(yyvsp[-2]), &(yyvsp[0]));
			}
    break;

  case 143:
#line 1261 "fortran.y"
    {
			     def_equiv_name(&(yyvsp[0]));
			}
    break;

  case 144:
#line 1265 "fortran.y"
    {
			     def_equiv_name(&(yyvsp[0]));
			}
    break;

  case 145:
#line 1269 "fortran.y"
    {
			     def_equiv_name(&(yyvsp[0]));
			}
    break;

  case 149:
#line 1284 "fortran.y"
    {
			     implied_id_token(&(yyval),blank_com_name);
			     def_com_block(&(yyval), &(yyvsp[-1]));
			     if(is_true(COMMA_FLAG,yyvsp[-1].TOK_flags))
			   	syntax_error(
					     yyvsp[-1].line_num,yyvsp[-1].col_num,
					     "trailing comma");
#ifdef DEBUG_PARSER
			     if(debug_parser)
				print_comlist("blank common",&(yyvsp[-1]));
#endif

			}
    break;

  case 150:
#line 1298 "fortran.y"
    {
			     if(is_true(COMMA_FLAG,yyvsp[-1].TOK_flags))
				syntax_error(
					     yyvsp[-1].line_num,yyvsp[-1].col_num,
					     "trailing comma");

			}
    break;

  case 151:
#line 1306 "fortran.y"
    {
			     implied_id_token(&(yyval),blank_com_name);
			     def_com_block(&(yyval),&(yyvsp[-2]));
			     if(is_true(COMMA_FLAG,yyvsp[-1].TOK_flags))
				syntax_error(
					     yyvsp[-1].line_num,yyvsp[-1].col_num,
					     "trailing comma");
#ifdef DEBUG_PARSER
			     if(debug_parser)
				print_comlist("blank common",&(yyvsp[-2]));
#endif
			}
    break;

  case 152:
#line 1324 "fortran.y"
    {
			     yyval.TOK_flags = yyvsp[0].TOK_flags;
			}
    break;

  case 153:
#line 1328 "fortran.y"
    {
			     yyval.TOK_flags = yyvsp[0].TOK_flags;
			     yyval.line_num = yyvsp[0].line_num;
			     yyval.col_num = yyvsp[0].col_num;
			}
    break;

  case 154:
#line 1336 "fortran.y"
    {
			     def_com_block(&(yyvsp[-1]),&(yyvsp[0]));
			     yyval.TOK_flags = yyvsp[0].TOK_flags;
			     yyval.line_num = yyvsp[0].line_num;
			     yyval.col_num = yyvsp[0].col_num;
#ifdef DEBUG_PARSER
			     if(debug_parser)
				print_comlist("labeled common",&(yyvsp[0]));
#endif
			}
    break;

  case 155:
#line 1349 "fortran.y"
    {
			     yyval = yyvsp[-1];
			}
    break;

  case 156:
#line 1354 "fortran.y"
    {
			     implied_id_token(&(yyval),blank_com_name);
			}
    break;

  case 157:
#line 1358 "fortran.y"
    {
			     implied_id_token(&(yyval),blank_com_name);
			}
    break;

  case 158:
#line 1364 "fortran.y"
    {
			    yyval.TOK_flags = yyvsp[0].TOK_flags;
			    yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			}
    break;

  case 159:
#line 1369 "fortran.y"
    {
			    if(!is_true(COMMA_FLAG,yyvsp[-1].TOK_flags))
				syntax_error(
					yyvsp[0].line_num,yyvsp[0].col_num-1,
					"missing comma");
			    yyval.TOK_flags = yyvsp[0].TOK_flags;
			    yyval.line_num = yyvsp[0].line_num;
			    yyval.col_num = yyvsp[0].col_num;
			    yyval.next_token = append_token(yyvsp[-1].next_token,&(yyvsp[0]));
			}
    break;

  case 160:
#line 1382 "fortran.y"
    {			   /* no comma */
			     yyval.TOK_flags = yyvsp[0].TOK_flags;
			     make_false(COMMA_FLAG,yyval.TOK_flags);
			}
    break;

  case 161:
#line 1387 "fortran.y"
    {			   /* has comma */
			     yyval.TOK_flags = yyvsp[-1].TOK_flags;
			     make_true(COMMA_FLAG,yyval.TOK_flags);
   			}
    break;

  case 162:
#line 1394 "fortran.y"
    {
			     def_com_variable(&(yyvsp[0]));
			     primary_id_expr(&(yyvsp[0]),&(yyval));
			}
    break;

  case 163:
#line 1399 "fortran.y"
    {
			     def_com_variable(&(yyvsp[0]));
			     primary_id_expr(&(yyvsp[0]),&(yyval));
			}
    break;

  case 164:
#line 1412 "fortran.y"
    {
			    if(is_true(COMMA_FLAG,yyvsp[-1].TOK_flags))
				syntax_error(yyvsp[-1].line_num,
				 (unsigned)(yyvsp[-1].col_num+strlen(token_name(&yyvsp[-1]))),
					"trailing comma");
			    if(f77_namelist) {
				nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num,0,0);
			    }
			}
    break;

  case 166:
#line 1425 "fortran.y"
    {
			    yyval = yyvsp[0];
			}
    break;

  case 167:
#line 1431 "fortran.y"
    {
			     def_namelist(&(yyvsp[-1]),&(yyvsp[0]));
			     yyval = yyvsp[0];
			}
    break;

  case 168:
#line 1438 "fortran.y"
    {
			    yyval = yyvsp[-1];
			}
    break;

  case 169:
#line 1444 "fortran.y"
    {
			     yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			}
    break;

  case 170:
#line 1448 "fortran.y"
    {
			    if(!is_true(COMMA_FLAG,yyvsp[-1].TOK_flags))
				syntax_error(
					yyvsp[0].line_num,yyvsp[0].col_num-1,
					"missing comma");
			    yyval.TOK_flags = yyvsp[0].TOK_flags;
			    yyval.line_num = yyvsp[0].line_num;
			    yyval.col_num = yyvsp[0].col_num;
			    yyval.next_token = append_token(yyvsp[-1].next_token,&(yyvsp[0]));
			}
    break;

  case 171:
#line 1461 "fortran.y"
    {			   /* no comma */
			     def_namelist_item(&(yyvsp[0]));
			     primary_id_expr(&(yyvsp[0]),&(yyval));
			     make_false(COMMA_FLAG,yyval.TOK_flags);
			}
    break;

  case 172:
#line 1467 "fortran.y"
    {			   /* has comma */
			     def_namelist_item(&(yyvsp[-1]));
			     primary_id_expr(&(yyvsp[-1]),&(yyval));
			     make_true(COMMA_FLAG,yyval.TOK_flags);
			}
    break;

  case 177:
#line 1484 "fortran.y"
    {
			  if(f77_attrbased_typedecl) {
			    nonstandard(yyvsp[-3].line_num, yyvsp[-3].col_num,0,0);
			    msg_tail(": attribute-based variable declaration");
			  }
			}
    break;

  case 178:
#line 1492 "fortran.y"
    {
			  if(f77_attrbased_typedecl) {
			    nonstandard(yyvsp[-3].line_num, yyvsp[-3].col_num,0,0);
			    msg_tail(": attribute-based variable declaration");
			  }
			}
    break;

  case 187:
#line 1516 "fortran.y"
    {
				/* turn back on flags turned off by punct  */
			  in_attrbased_typedecl = initial_flag = TRUE;
			  dim_bound_token = yyvsp[-1];	/* save copy of header */
			  current_dim_bound_list = &dim_bound_token;
			}
    break;

  case 188:
#line 1523 "fortran.y"
    {
			     current_save_attr = TRUE;
			}
    break;

  case 189:
#line 1527 "fortran.y"
    {
			     current_external_attr = TRUE;
			}
    break;

  case 190:
#line 1531 "fortran.y"
    {
			     current_intrinsic_attr = TRUE;
			}
    break;

  case 191:
#line 1535 "fortran.y"
    {
			     current_parameter_attr = TRUE;
			}
    break;

  case 192:
#line 1539 "fortran.y"
    {
                             current_pointer_attr = TRUE;
                        }
    break;

  case 193:
#line 1543 "fortran.y"
    {
                             current_target_attr = TRUE;
                        }
    break;

  case 194:
#line 1547 "fortran.y"
    {
                             current_allocatable_attr = TRUE;
                        }
    break;

  case 195:
#line 1554 "fortran.y"
    {
			  current_typesize = size_DEFAULT;
			  current_len_text = NULL;
			  reset_type_attrs();
			}
    break;

  case 196:
#line 1561 "fortran.y"
    {
			    current_typesize = yyvsp[0].value.integer;
			    current_len_text = NULL;
			    reset_type_attrs();
#if 0 /* defunct feature */
			    if(local_wordsize > 0) {
			      /*  recognize REAL*2w as DOUBLE PRECISION */
			      if(current_datatype == type_REAL
				 && yyvsp[0].value.integer == type_size[type_DP])
				current_datatype = type_DP;
			      /*  recognize COMPLEX*4w as DOUBLE COMPLEX */
			      if(current_datatype == type_COMPLEX
				 && yyvsp[0].value.integer==type_size[type_DCOMPLEX])
				current_datatype = type_DCOMPLEX;
			    }
#endif
			     if(f77_typesize || f90_typesize) {
				nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,f90_typesize,0);
			     }

				/* Give hint to lexer to continue taking attrs
				   as keywords despite non-initial position */
			     if(see_double_colon())
				 in_attrbased_typedecl = TRUE;
			}
    break;

  case 197:
#line 1590 "fortran.y"
    {
				/* Treat all KINDs as default */
			  current_typesize = size_DEFAULT;
			  current_len_text = NULL;
			  reset_type_attrs();
			}
    break;

  case 198:
#line 1599 "fortran.y"
    {
			    reset_type_attrs();
			}
    break;

  case 199:
#line 1605 "fortran.y"
    {
			     current_datatype = type_INTEGER;
			     integer_context = TRUE;
			}
    break;

  case 200:
#line 1610 "fortran.y"
    {
			     current_datatype = type_REAL;
			     integer_context = TRUE;
			}
    break;

  case 201:
#line 1615 "fortran.y"
    {
			     current_datatype = type_COMPLEX;
			     integer_context = TRUE;
			}
    break;

  case 202:
#line 1620 "fortran.y"
    {
			     current_datatype = type_LOGICAL;
			     integer_context = TRUE;
			}
    break;

  case 203:
#line 1627 "fortran.y"
    {
			     current_datatype = type_DP;
			     current_typesize = size_DEFAULT;
			     current_len_text = NULL;
			     reset_type_attrs();
			}
    break;

  case 204:
#line 1634 "fortran.y"
    {
			     current_datatype = type_DCOMPLEX;
			     current_typesize = size_DEFAULT;
			     current_len_text = NULL;
			     reset_type_attrs();
			     if(f77_double_complex || f90_double_complex) {
				nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,f90_double_complex,0);
			     }
			}
    break;

  case 205:
#line 1644 "fortran.y"
    {
			     current_datatype = type_INTEGER;
			     current_typesize = 1;
			     current_len_text = NULL;
			     reset_type_attrs();
			     if(f77_byte || f90_byte)
			       nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,f90_byte,0);
			}
    break;

  case 206:
#line 1660 "fortran.y"
    {
			  if(!kind_warning_given)
			      give_kind_warning(&(yyvsp[0]));
			  if(f77_attrbased_typedecl) {
			    nonstandard(yyvsp[0].line_num, yyvsp[0].col_num,0,0);
			    msg_tail(": F90-style declaration");
			  }
			}
    break;

  case 207:
#line 1669 "fortran.y"
    {
			  int erroneous=FALSE;
			  if( strcmp(hashtab[yyvsp[-2].value.integer].name,"KIND")
			      == 0 ) {
			    if(!kind_warning_given)
			      give_kind_warning(&(yyvsp[-2]));
			  }
			  else {
			    syntax_error(yyvsp[-2].line_num,yyvsp[-2].col_num,
					 "unrecognized keyword");
			    msg_tail(hashtab[yyvsp[-2].value.integer].name);
			    erroneous=TRUE;
			  }
			  if(!erroneous && f77_attrbased_typedecl) {
			    nonstandard(yyvsp[-2].line_num, yyvsp[-2].col_num,0,0);
			    msg_tail(": F90-style declaration");
			  }
			}
    break;

  case 208:
#line 1691 "fortran.y"
    {
			     current_datatype = type_STRING;
			     current_typesize = 1;
			     current_len_text = NULL;
			     current_size_is_adjustable = 0;
			     current_size_is_expression = 0;
			     reset_type_attrs();
			     integer_context = TRUE;
			     len_selector_given = FALSE;
			}
    break;

  case 209:
#line 1704 "fortran.y"
    {
			     current_typesize = yyvsp[0].value.integer;
			     current_size_is_adjustable = yyvsp[0].size_is_adjustable;
			     current_size_is_expression = yyvsp[0].size_is_expression;
				/* Save length spec text if expression */
			     if(current_size_is_expression) {
			       if(yyvsp[0].left_token == NULL)
				 current_len_text = new_tree_text(&(yyvsp[0]));
			       else
				 current_len_text = new_tree_text(yyvsp[0].left_token);
			     }
			     else
			       current_len_text = NULL;

			     reset_type_attrs();
				/* Give hint to lexer to continue taking attrs
				   as keywords despite non-initial position */
			     if(see_double_colon())
				 in_attrbased_typedecl = TRUE;
			}
    break;

  case 210:
#line 1727 "fortran.y"
    {
			  yyval = yyvsp[0];
			}
    break;

  case 211:
#line 1737 "fortran.y"
    {len_spec_item_count = 0;}
    break;

  case 212:
#line 1738 "fortran.y"
    {
			  if( len_selector_given ) {
			    yyval = len_spec_token; /* Recover spec saved below */
				/* Store as a parenthesized expr tree */
			    yyval.left_token = add_tree_node(&(yyvsp[-3]),
							  &len_spec_token,
							  (Token*)NULL);
			  }
				/* If len_spec_list does not specify a LEN,
				   use the current default values.
				 */
			  else {
			    yyval.left_token = (Token *)NULL;
			    yyval.value.integer = current_typesize;
			    yyval.size_is_adjustable = current_size_is_adjustable;
			    yyval.size_is_expression = current_size_is_expression;
			  }
			  if(f77_attrbased_typedecl) {
			    nonstandard(yyvsp[-3].line_num, yyvsp[-3].col_num,0,0);
			    msg_tail(": F90-style variable declaration");
			  }
			}
    break;

  case 213:
#line 1767 "fortran.y"
    {
			  yyval.tclass = '('; /* make it a regular paren */
			}
    break;

  case 216:
#line 1780 "fortran.y"
    {
			     if( current_parameter_attr) {
				syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
					     "PARAMETER lacks initializer");
			     }
			}
    break;

  case 217:
#line 1790 "fortran.y"
    {integer_context=FALSE;complex_const_allowed=TRUE;}
    break;

  case 218:
#line 1792 "fortran.y"
    {integer_context=TRUE;complex_const_allowed=FALSE;}
    break;

  case 219:
#line 1793 "fortran.y"
    {
			    if(f77_initializers || f90_initializers) {
				nonstandard(yyvsp[-4].line_num,yyvsp[-4].col_num,
					    f90_initializers,0);
				msg_tail(": combined type declaration and data-style initializer");
			    }
			    primary_id_expr(&(yyvsp[-5]),&(yyvsp[-5]));
			    check_initializer_type(&(yyvsp[-5]),&(yyvsp[-4]),&(yyvsp[-2]));
			}
    break;

  case 220:
#line 1807 "fortran.y"
    {integer_context=FALSE;complex_const_allowed = TRUE;}
    break;

  case 221:
#line 1809 "fortran.y"
    {
			    if(current_parameter_attr)
				def_parameter(&(yyvsp[-3]),&(yyvsp[0]),FALSE);
			    else
				use_lvalue(&(yyvsp[-3]));
			    if(f77_initializers) {
				nonstandard(yyvsp[-1].line_num,yyvsp[-1].col_num,
					    0,0);
				msg_tail(": F90-style initializer");
			    }
			    primary_id_expr(&(yyvsp[-3]),&(yyvsp[-3]));
			    check_initializer_type(&(yyvsp[-3]),&(yyvsp[-1]),&(yyvsp[0]));
			    integer_context=TRUE;
			    complex_const_allowed = FALSE;
			}
    break;

  case 222:
#line 1829 "fortran.y"
    {
			     declare_type(&(yyvsp[0]),
					  current_datatype,
					  current_typesize,
					  current_len_text);
			     process_attrs(&(yyvsp[0]),(Token *)NULL);
			}
    break;

  case 223:
#line 1840 "fortran.y"
    {integer_context=FALSE;complex_const_allowed=TRUE;}
    break;

  case 224:
#line 1842 "fortran.y"
    {integer_context=TRUE;complex_const_allowed=FALSE;}
    break;

  case 225:
#line 1843 "fortran.y"
    {
			    declare_type(&(yyvsp[-5]),
					 current_datatype,
					 current_typesize,
					 current_len_text);
			    process_attrs(&(yyvsp[-5]),(Token *)NULL);
			    if(f77_initializers || f90_initializers) {
				nonstandard(yyvsp[-4].line_num,yyvsp[-4].col_num,
					    f90_initializers,0);
				msg_tail(": combined type declaration and data-style initializer");
			    }
			    use_lvalue(&(yyvsp[-5]));
			    primary_id_expr(&(yyvsp[-5]),&(yyvsp[-5]));
			    check_initializer_type(&(yyvsp[-5]),&(yyvsp[-4]),&(yyvsp[-2]));
			}
    break;

  case 226:
#line 1861 "fortran.y"
    {
			     declare_type(&(yyvsp[0]),
					  current_datatype,
					  current_typesize,
					  current_len_text);
			     process_attrs(&(yyvsp[0]),current_dim_bound_list);
			}
    break;

  case 229:
#line 1875 "fortran.y"
    {
			     if( current_parameter_attr) {
				syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
					     "PARAMETER lacks initializer");
			     }
			}
    break;

  case 230:
#line 1883 "fortran.y"
    {integer_context=FALSE;complex_const_allowed=TRUE;}
    break;

  case 231:
#line 1885 "fortran.y"
    {integer_context=TRUE;complex_const_allowed=FALSE;}
    break;

  case 232:
#line 1886 "fortran.y"
    {
			    if(f77_initializers || f90_initializers) {
				nonstandard(yyvsp[-4].line_num,yyvsp[-4].col_num,
					    f90_initializers,0);
				msg_tail(": combined type declaration and data-style initializer");
			    }
			    primary_id_expr(&(yyvsp[-5]),&(yyvsp[-5]));
			    check_initializer_type(&(yyvsp[-5]),&(yyvsp[-4]),&(yyvsp[-2]));
			}
    break;

  case 233:
#line 1897 "fortran.y"
    {
			    if(current_parameter_attr)
				def_parameter(&(yyvsp[-2]),&(yyvsp[0]),FALSE);
			    else
				use_lvalue(&(yyvsp[-2]));
			    primary_id_expr(&(yyvsp[-2]),&(yyvsp[-2]));
			    if(f77_initializers) {
				nonstandard(yyvsp[-1].line_num,yyvsp[-1].col_num,
					    0,0);
				msg_tail(": F90-style initializer");
			    }
			    check_initializer_type(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0]));
			}
    break;

  case 234:
#line 1911 "fortran.y"
    {
			     yyvsp[0].size_is_adjustable = current_size_is_adjustable;
			     yyvsp[0].size_is_expression = current_size_is_expression;
			     declare_type(&(yyvsp[0]),
					  current_datatype,
					  current_typesize,
					  current_len_text);
			     process_attrs(&(yyvsp[0]),(Token *)NULL);
			}
    break;

  case 235:
#line 1921 "fortran.y"
    {
			     yyvsp[-2].size_is_adjustable = yyvsp[0].size_is_adjustable;
			     yyvsp[-2].size_is_expression = yyvsp[0].size_is_expression;
			     declare_type(&(yyvsp[-2]),
					  current_datatype,
					  yyvsp[0].value.integer,
					  new_tree_text(
					     yyvsp[0].left_token == NULL?
					     &(yyvsp[0]): yyvsp[0].left_token )
					  );
			     process_attrs(&(yyvsp[-2]),(Token *)NULL);
			}
    break;

  case 236:
#line 1934 "fortran.y"
    {integer_context=FALSE;complex_const_allowed=TRUE;}
    break;

  case 237:
#line 1936 "fortran.y"
    {integer_context=TRUE;complex_const_allowed=FALSE;}
    break;

  case 238:
#line 1937 "fortran.y"
    {
			    yyvsp[-5].size_is_adjustable = current_size_is_adjustable;
			    yyvsp[-5].size_is_expression = current_size_is_expression;
			    declare_type(&(yyvsp[-5]),
					 current_datatype,
					 current_typesize,
					 current_len_text);
			    process_attrs(&(yyvsp[-5]),(Token *)NULL);
			    if(f77_initializers || f90_initializers) {
				nonstandard(yyvsp[-4].line_num,yyvsp[-4].col_num,
					    f90_initializers,0);
				msg_tail(": combined type declaration and data-style initializer");
			    }
			    use_lvalue(&(yyvsp[-5]));
			}
    break;

  case 239:
#line 1953 "fortran.y"
    {integer_context=FALSE;complex_const_allowed=TRUE;}
    break;

  case 240:
#line 1955 "fortran.y"
    {integer_context=TRUE;complex_const_allowed=FALSE;}
    break;

  case 241:
#line 1956 "fortran.y"
    {
			    yyvsp[-7].size_is_adjustable = yyvsp[-5].size_is_adjustable;
			    yyvsp[-7].size_is_expression = yyvsp[-5].size_is_expression;
			    declare_type(&(yyvsp[-7]),
					 current_datatype,
					 yyvsp[-5].value.integer,
					 new_tree_text(
					     yyvsp[-5].left_token == NULL?
					     &(yyvsp[-5]): yyvsp[-5].left_token )
				);
			    process_attrs(&(yyvsp[-7]),(Token *)NULL);
			    if(f77_initializers || f90_initializers) {
				nonstandard(yyvsp[-4].line_num,yyvsp[-4].col_num,
					    f90_initializers,0);
				msg_tail(": combined type declaration and data-style initializer");
			    }
			    use_lvalue(&(yyvsp[-7]));
			}
    break;

  case 242:
#line 1977 "fortran.y"
    {
			     yyvsp[0].size_is_adjustable = current_size_is_adjustable;
			     yyvsp[0].size_is_expression = current_size_is_expression;
			     declare_type(&(yyvsp[0]),
					  current_datatype,
					  current_typesize,
					  current_len_text);
			     process_attrs(&(yyvsp[0]),current_dim_bound_list);
			}
    break;

  case 243:
#line 1987 "fortran.y"
    {
			     yyvsp[-2].size_is_adjustable = yyvsp[0].size_is_adjustable;
			     yyvsp[-2].size_is_expression = yyvsp[0].size_is_expression;
			     declare_type(&(yyvsp[-2]),
					  current_datatype,
					  yyvsp[0].value.integer,
					  new_tree_text(
					     yyvsp[0].left_token == NULL?
					     &(yyvsp[0]): yyvsp[0].left_token )
					  );
			     process_attrs(&(yyvsp[-2]),current_dim_bound_list);
			}
    break;

  case 244:
#line 2003 "fortran.y"
    {implicit_flag=TRUE;}
    break;

  case 245:
#line 2007 "fortran.y"
    {
			    implicit_flag=FALSE;
			    if(implicit_none) {
				syntax_error(yyvsp[-2].line_num,yyvsp[-2].col_num,
				     "conflicts with IMPLICIT NONE");
			    }
			    else {
				implicit_type_given = TRUE;
			    }
			    check_f90_stmt_sequence(&(yyvsp[-2]),F90_SEQ_IMPLICIT);
			}
    break;

  case 246:
#line 2020 "fortran.y"
    {
			    implicit_flag=FALSE;
			    if(implicit_type_given) {
			      syntax_error(yyvsp[-2].line_num,yyvsp[-2].col_num,
				   "conflicts with IMPLICIT statement");
			    }
			    else {
			      if(f77_implicit_none)
				      nonstandard(yyvsp[-1].line_num,yyvsp[-1].col_num,0,0);
			      implicit_none = TRUE;
			    }
			    check_f90_stmt_sequence(&(yyvsp[-2]),F90_SEQ_IMPLICIT_NONE);
			}
    break;

  case 248:
#line 2036 "fortran.y"
    {initial_flag = TRUE;}
    break;

  case 250:
#line 2042 "fortran.y"
    {implicit_letter_flag = TRUE;}
    break;

  case 251:
#line 2043 "fortran.y"
    {implicit_letter_flag = FALSE;}
    break;

  case 254:
#line 2051 "fortran.y"
    {
			  int c1 = (int)yyvsp[0].tsubclass;
				/* kluge to allow other non-alpha chars:
				   treate anything except _ as $.
				 */
			  if( !isalpha(c1) && c1 != '_' ) c1 = '$';

			  if( ((f77_dollarsigns||f90_dollarsigns) && c1=='$')
			   || (f77_underscores && c1=='_') ) {
			    nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,
				f90_dollarsigns&&c1=='$',0);
			    msg_tail(": nonalphabetic character");
			  }

			   set_implicit_type(current_datatype,
					     current_typesize,
					     current_len_text,
					     c1,c1);
			}
    break;

  case 255:
#line 2071 "fortran.y"
    {
			  int c1 = (int)yyvsp[-2].tsubclass,
			      c2 = (int)yyvsp[0].tsubclass;

			  if( !isalpha(c1) && c1 != '_' ) c1 = '$';
			  if( !isalpha(c2) && c2 != '_' ) c2 = '$';

			  if( ((f77_dollarsigns||f90_dollarsigns) && (c1 == '$' || c2 == '$'))
			   || (f77_underscores && (c1 == '_' || c2 == '_')))
			  {
			    if(!isalpha(c1))
			      nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num,
				  f90_dollarsigns&&(c1=='$'||c2=='$'),0);
			    else
			      nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,
				  f90_dollarsigns&&(c1=='$'||c2=='$'),0);
			    msg_tail(": nonalphabetic character");
			  }

			   set_implicit_type(current_datatype,
					     current_typesize,
					     current_len_text,
					     c1,c2);
			}
    break;

  case 256:
#line 2100 "fortran.y"
    {
			     yyval.value.integer = yyvsp[0].value.integer;
			     yyval.size_is_adjustable = 0;
			     yyval.size_is_expression = 0;
			}
    break;

  case 257:
#line 2107 "fortran.y"
    {
			    yyval.value.integer = yyvsp[-1].value.integer;
			    yyval.size_is_adjustable = yyvsp[-1].size_is_adjustable;
			    yyval.size_is_expression = yyvsp[-1].size_is_expression;
				/* Store as a parenthesized expr tree */
			    yyval.left_token = add_tree_node(&(yyvsp[-2]),
							  &(yyvsp[-1]),
							  (Token*)NULL);
			}
    break;

  case 258:
#line 2138 "fortran.y"
    {
			  ++len_spec_item_count;
			}
    break;

  case 259:
#line 2142 "fortran.y"
    {
			  ++len_spec_item_count;
			}
    break;

  case 260:
#line 2148 "fortran.y"
    {
				/* Non-keyword form: 1st item is LEN */
			  if(len_spec_item_count == 0) {
			    len_spec_token = yyvsp[0];
			    len_selector_given = TRUE;
			  }
				/* 2nd item is KIND */
			  else if(len_spec_item_count == 1) {
			    if(!kind_warning_given)
			      give_kind_warning(&(yyvsp[0]));
			  }
			  else if(len_spec_item_count == 2) {
			    syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
					 "too many specifiers in list");
			  }
			}
    break;

  case 261:
#line 2165 "fortran.y"
    {
			  int erroneous=FALSE;
			  if( strcmp(hashtab[yyvsp[-2].value.integer].name,"LEN")
			      == 0 ) {
			    len_spec_token = yyvsp[0];
			    len_selector_given = TRUE;
			  }
			  else if( strcmp(hashtab[yyvsp[-2].value.integer].name,"KIND")
			      == 0 ) {
			    if(!kind_warning_given)
			      give_kind_warning(&(yyvsp[-2]));
			  }
			  else {
			    syntax_error(yyvsp[-2].line_num,yyvsp[-2].col_num,
					 "unrecognized keyword");
			    msg_tail(hashtab[yyvsp[-2].value.integer].name);
			    erroneous=TRUE;
			  }
			  if(!erroneous && f77_attrbased_typedecl) {
			    nonstandard(yyvsp[-1].line_num, yyvsp[-1].col_num,0,0);
			    msg_tail(": F90-style declaration");
			  }
			}
    break;

  case 262:
#line 2191 "fortran.y"
    {
			     yyval.left_token = (Token *)NULL;
			     yyval.value.integer = size_ADJUSTABLE;
			     yyval.size_is_adjustable = 1;
			     yyval.size_is_expression = 0;
			}
    break;

  case 263:
#line 2198 "fortran.y"
    {
			     yyval.size_is_adjustable = 0;
			     yyval.size_is_expression = 1;
			     if(yyvsp[0].value.integer <= 0) {
			      if(yyvsp[0].value.integer < 0) {
			        if(misc_warn || f77_char_extension) { 
				  warning(yyvsp[0].line_num,yyvsp[0].col_num,
				  "non-negative integer value expected");
				  msg_tail(": substituting 0");
				}
				yyval.value.integer = 0;
			      }
			      else if(f77_char_extension) {
				   warning(yyvsp[0].line_num,yyvsp[0].col_num,
				   "nonzero integer value expected");
			      }
			     }
			}
    break;

  case 267:
#line 2226 "fortran.y"
    {param_noparen=TRUE;}
    break;

  case 268:
#line 2227 "fortran.y"
    {param_noparen=FALSE;}
    break;

  case 269:
#line 2228 "fortran.y"
    {
			  if(f77_param_noparen || f90_param_noparen) {
				nonstandard(yyvsp[-4].line_num,yyvsp[-4].col_num,f90_param_noparen,0);
				msg_tail(" : PARAMETER declaration without parentheses");
			  }
			}
    break;

  case 272:
#line 2240 "fortran.y"
    {complex_const_allowed = TRUE;}
    break;

  case 273:
#line 2242 "fortran.y"
    {
			     def_parameter(&(yyvsp[-3]),&(yyvsp[0]),param_noparen);
			     primary_id_expr(&(yyvsp[-3]),&(yyvsp[-3]));
			     check_initializer_type(&(yyvsp[-3]),&(yyvsp[-1]),&(yyvsp[0]));
			     complex_const_allowed = FALSE;
			}
    break;

  case 275:
#line 2255 "fortran.y"
    {
			     def_ext_name(&(yyvsp[0]));
			}
    break;

  case 276:
#line 2259 "fortran.y"
    {
			     def_ext_name(&(yyvsp[0]));
			}
    break;

  case 278:
#line 2269 "fortran.y"
    {
			     def_intrins_name(&(yyvsp[0]));
			}
    break;

  case 279:
#line 2273 "fortran.y"
    {
			     def_intrins_name(&(yyvsp[0]));
			}
    break;

  case 280:
#line 2280 "fortran.y"
    {
			     if( f77_pointers ) {
				  nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num,0,0);
				  msg_tail(": ALLOCATABLE statement");
			     }
			}
    break;

  case 281:
#line 2290 "fortran.y"
    {
			     if( f77_pointers ) {
				  nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num,0,0);
				  msg_tail(": TARGET statement");
			     }
			}
    break;

  case 282:
#line 2300 "fortran.y"
    {
			     if( f77_pointers ) {
				  nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num,0,0);
				  msg_tail(": POINTER statement");
			     }
			}
    break;

  case 286:
#line 2314 "fortran.y"
    {
			     apply_attr(&(yyvsp[0]),curr_stmt_class);
			}
    break;

  case 287:
#line 2318 "fortran.y"
    {
			     apply_attr(&(yyvsp[0]),curr_stmt_class);
			}
    break;

  case 288:
#line 2327 "fortran.y"
    {
		  if(f77_cray_pointers || f90_cray_pointers) {
		    nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num,f90_cray_pointers,0);
		  }
		}
    break;

  case 292:
#line 2342 "fortran.y"
    {
			     declare_type(&(yyvsp[0]),type_INTEGER,local_ptrsize,
					  NULL );
			}
    break;

  case 293:
#line 2349 "fortran.y"
    {
				/* Suppress set/used warnings since
				   often is accessed only via pointer */
		             use_lvalue(&(yyvsp[0]));
		             use_variable(&(yyvsp[0]));
		        }
    break;

  case 294:
#line 2356 "fortran.y"
    {
		             use_lvalue(&(yyvsp[0]));
		             use_variable(&(yyvsp[0]));
		        }
    break;

  case 295:
#line 2363 "fortran.y"
    {
			     if( f77_pointers ) {
				  nonstandard(yyvsp[-4].line_num,yyvsp[-4].col_num,0,0);
				  msg_tail(": ALLOCATE statement");
			     }
			}
    break;

  case 296:
#line 2372 "fortran.y"
    {
			     if( f77_pointers ) {
				  nonstandard(yyvsp[-4].line_num,yyvsp[-4].col_num,0,0);
				  msg_tail(": DEALLOCATE statement");
			     }
			}
    break;

  case 309:
#line 2401 "fortran.y"
    {
			     if( f77_pointers ) {
				  nonstandard(yyvsp[-4].line_num,yyvsp[-4].col_num,0,0);
				  msg_tail(": NULLIFY statement");
			     }
			}
    break;

  case 312:
#line 2415 "fortran.y"
    {
			  global_save = TRUE;
			}
    break;

  case 316:
#line 2426 "fortran.y"
    {
			     apply_attr(&(yyvsp[0]),tok_SAVE);
			}
    break;

  case 317:
#line 2430 "fortran.y"
    {
/***			     def_com_block(&($2),(Token*)NULL);***/
			     save_com_block(&(yyvsp[-1]));
			}
    break;

  case 322:
#line 2446 "fortran.y"
    {complex_const_allowed=TRUE;}
    break;

  case 323:
#line 2448 "fortran.y"
    {complex_const_allowed=FALSE;}
    break;

  case 327:
#line 2457 "fortran.y"
    {
			     use_lvalue(&(yyvsp[0]));
			}
    break;

  case 329:
#line 2464 "fortran.y"
    {
			    yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			}
    break;

  case 330:
#line 2468 "fortran.y"
    {
			    yyval.next_token = append_token(yyvsp[-2].next_token,&(yyvsp[0]));
			}
    break;

  case 331:
#line 2474 "fortran.y"
    {
			    yyval.left_token = (Token*)NULL;
			}
    break;

  case 332:
#line 2478 "fortran.y"
    {
				/* Save data repeat factor in a permanent token
				   pointed to by left_token.
				 */
			    Token *tcopy = new_token();
			    *tcopy = yyvsp[-2]; /* copy the repeat factor token */
			    yyval = yyvsp[0]; /* pass data_value up the parse tree */
			    yyval.left_token = tcopy;
			}
    break;

  case 334:
#line 2491 "fortran.y"
    {
			     use_parameter(&(yyvsp[0]));
			}
    break;

  case 336:
#line 2498 "fortran.y"
    {
			     use_parameter(&(yyvsp[0]));
			}
    break;

  case 339:
#line 2509 "fortran.y"
    {
			     use_lvalue(&(yyvsp[0]));
			}
    break;

  case 341:
#line 2517 "fortran.y"
    {
			    use_implied_do_index(&(yyvsp[-3]));
			}
    break;

  case 344:
#line 2528 "fortran.y"
    {complex_const_allowed = TRUE;
				    in_assignment_stmt = TRUE;}
    break;

  case 345:
#line 2530 "fortran.y"
    {
			  if( ! (is_true(LVALUE_EXPR,yyvsp[-3].TOK_flags)
			       || is_true(STMT_FUNCTION_EXPR,yyvsp[-3].TOK_flags) )) {
			    syntax_error(yyvsp[-3].line_num,yyvsp[-3].col_num,
					 "left side is not assignable");
			    if(is_true(CONST_EXPR,yyvsp[-3].TOK_flags))
				msg_tail(": it is a constant");
			  }
			  else {
			    int array_lhs, array_rhs;
			    array_lhs =
			      ((yyvsp[-3].TOK_flags&(ARRAY_ID_EXPR|ARRAY_ELEMENT_EXPR)) == ARRAY_ID_EXPR);
			    array_rhs =
			      ((yyvsp[0].TOK_flags&(ARRAY_ID_EXPR|ARRAY_ELEMENT_EXPR)) == ARRAY_ID_EXPR);
			    if( array_lhs || array_rhs ) {
			      if( (! array_lhs) && misc_warn) {
				warning(yyvsp[-3].line_num,yyvsp[-3].col_num,
					"array assigned to scalar");
			      }
			      else if( f77_assignment ) {
				nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num,0,0);
				msg_tail(": assignment involving whole array");
			      }
			    }

			    assignment_stmt_type(&(yyvsp[-3]),&(yyvsp[-2]),
					&(yyvsp[0]));
			  }
			  complex_const_allowed = FALSE;
			  in_assignment_stmt = FALSE;
			}
    break;

  case 346:
#line 2562 "fortran.y"
    {
				/* Clear u-b-s flags spuriously set */
			  if(is_true(STMT_FUNCTION_EXPR, yyvsp[-5].TOK_flags)
				     && stmt_sequence_no <= SEQ_STMT_FUN)
			     stmt_function_stmt(&(yyvsp[-5]));
		        }
    break;

  case 352:
#line 2578 "fortran.y"
    {
			     if( f77_pointers ) {
				  nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,0,0);
				  msg_tail(": pointer assignment");
			     }
			}
    break;

  case 353:
#line 2589 "fortran.y"
    {
			    do_ASSIGN(&(yyvsp[-1]));
			    if( f95_assign ) {
			      nonstandard(yyvsp[-5].line_num,yyvsp[-5].col_num,0,f95_assign);
			      msg_tail(": ASSIGN statement");
			    }

			    ref_label(&(yyvsp[-3]),LAB_ASSIGN);

			}
    break;

  case 354:
#line 2604 "fortran.y"
    {

			  ref_label(&(yyvsp[-1]),LAB_GOTO);

			}
    break;

  case 357:
#line 2618 "fortran.y"
    {
			     do_assigned_GOTO(&(yyvsp[-1]));
			}
    break;

  case 358:
#line 2622 "fortran.y"
    {
			     do_assigned_GOTO(&(yyvsp[-4]));
			}
    break;

  case 359:
#line 2626 "fortran.y"
    {
			     do_assigned_GOTO(&(yyvsp[-5]));
			}
    break;

  case 360:
#line 2632 "fortran.y"
    {
			    integer_context=TRUE;
				/* Warn if GOTO considered harmful */
			    if( style_goto ) {
			      warning(yyvsp[0].line_num,yyvsp[0].col_num,
				      "obsolescent feature: GOTO statement");
			    }
			}
    break;

  case 361:
#line 2643 "fortran.y"
    {
                            ref_label(&(yyvsp[0]), LAB_GOTO);
			}
    break;

  case 362:
#line 2647 "fortran.y"
    {
			    ref_label(&(yyvsp[0]), LAB_GOTO);
			}
    break;

  case 363:
#line 2655 "fortran.y"
    {
			  int t=datatype_of(yyvsp[-9].TOK_type);
			  if(t != type_INTEGER && t != type_REAL
			     && t != type_DP && t != type_ERROR ) {
			    syntax_error(yyvsp[-9].line_num,yyvsp[-9].col_num,
		  "integer, real, or double precision expression required");
			  }
			  ref_label(&(yyvsp[-7]), LAB_GOTO);
			  ref_label(&(yyvsp[-4]), LAB_GOTO);
			  ref_label(&(yyvsp[-1]), LAB_GOTO);

			}
    break;

  case 364:
#line 2671 "fortran.y"
    {
			  int t=datatype_of(yyvsp[-1].TOK_type);
			  if(t != type_LOGICAL && t != type_ERROR)
			     syntax_error(yyvsp[-1].line_num,yyvsp[-1].col_num,
					  "logical expression required");
			}
    break;

  case 365:
#line 2681 "fortran.y"
    {
			  int t=datatype_of(yyvsp[-2].TOK_type);
			  if(t != type_LOGICAL && t != type_ERROR)
			     syntax_error(yyvsp[-2].line_num,yyvsp[-2].col_num,
					  "logical expression required");

		/* In picky mode warn if no name tag on block construct.
		   By this time $1 is the expr, not tok_IF, so line and
		   column must be those saved at lower-level productions.
		 */
			  if(curr_stmt_name == NULL &&
			     style_req_construct_name) {
			      warning(if_line_num,if_col_num,
				"Construct name missing from IF statement");
			  }
			}
    break;

  case 366:
#line 2700 "fortran.y"
    {
			    curr_stmt_name = NULL;
			}
    break;

  case 367:
#line 2704 "fortran.y"
    {
			  if(f77_construct_name) {
			    nonstandard(yyvsp[-1].line_num,yyvsp[-1].col_num,0,0);
			    msg_tail(": IF construct name");
			  }
			  construct_name_seen=FALSE;
			  yyval = yyvsp[0];
			}
    break;

  case 368:
#line 2714 "fortran.y"
    {complex_const_allowed = TRUE;}
    break;

  case 369:
#line 2715 "fortran.y"
    {
			    if(is_true(ID_EXPR,yyvsp[-1].TOK_flags)){
				use_variable(&(yyvsp[-1]));
			    }
			    complex_const_allowed = FALSE;

			    initial_flag = TRUE;	/* for is_keyword */
			    if_line_num = yyvsp[-4].line_num; /* save location */
			    if_col_num = yyvsp[-4].col_num; /* for picky warnings */
			    yyval = yyvsp[-1]; /* Inherit expr for type checking above */
			}
    break;

  case 370:
#line 2729 "fortran.y"
    {complex_const_allowed = TRUE;}
    break;

  case 371:
#line 2730 "fortran.y"
    {
			    int t=datatype_of(yyvsp[-1].TOK_type);
			    if(t != type_LOGICAL && t != type_ERROR)
				syntax_error(yyvsp[-1].line_num,yyvsp[-1].col_num,
					  "logical expression required");

			    if(is_true(ID_EXPR,yyvsp[-1].TOK_flags)){
				use_variable(&(yyvsp[-1]));
			    }

			    complex_const_allowed = FALSE;

			    initial_flag = TRUE;
			}
    break;

  case 373:
#line 2748 "fortran.y"
    {
			    curr_stmt_name = NULL;
			}
    break;

  case 374:
#line 2752 "fortran.y"
    {
			  if(f77_construct_name) {
			    nonstandard(yyvsp[-1].line_num,yyvsp[-1].col_num,0,0);
			    msg_tail(": IF construct name");
			  }
			}
    break;

  case 375:
#line 2762 "fortran.y"
    {
			    curr_stmt_name = NULL;
			}
    break;

  case 376:
#line 2766 "fortran.y"
    {
			  if(f77_construct_name) {
			    nonstandard(yyvsp[-1].line_num,yyvsp[-1].col_num,0,0);
			    msg_tail(": IF construct name");
			  }
			}
    break;

  case 377:
#line 2776 "fortran.y"
    {
			    curr_stmt_name = NULL;
			}
    break;

  case 378:
#line 2780 "fortran.y"
    {
			  if(f77_construct_name) {
			    nonstandard(yyvsp[-1].line_num,yyvsp[-1].col_num,0,0);
			    msg_tail(": IF construct name");
			  }
			}
    break;

  case 379:
#line 2796 "fortran.y"
    {complex_const_allowed = TRUE;}
    break;

  case 380:
#line 2797 "fortran.y"
    {
			    int t = datatype_of (yyvsp[-2].TOK_type);
			    if (t != type_ERROR) {
			        if (!is_const_type(t) || is_float_type(t)) {
			            syntax_error(yyvsp[-2].line_num,yyvsp[-2].col_num,
			"integer, character, or logical expression required");
			        }
			    }
			    if(is_true(ID_EXPR,yyvsp[-2].TOK_flags)){
				use_variable(&(yyvsp[-2]));
			    }
			    complex_const_allowed = FALSE;
			    push_block(&(yyvsp[-5]),yyvsp[-5].tclass,construct,curr_stmt_name,NO_LABEL);
			}
    break;

  case 381:
#line 2814 "fortran.y"
    {
			    curr_stmt_name = NULL;
			    if (f77_case_construct) {
				nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,0,0);
			    }
			    if( style_req_construct_name ) {
			      warning(yyvsp[0].line_num,yyvsp[0].col_num,
			       "Construct name missing from SELECT statement");
			    }
			}
    break;

  case 382:
#line 2825 "fortran.y"
    {
			    if (f77_case_construct) {
				nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,0,0);
			    }
			    yyval = yyvsp[0];
			}
    break;

  case 389:
#line 2846 "fortran.y"
    {
			    int t1 = datatype_of(yyvsp[-2].TOK_type),
			        t2 = datatype_of(yyvsp[0].TOK_type);
			    if (t1 == type_LOGICAL || t2 == type_LOGICAL) {
			        syntax_error(yyvsp[-1].line_num,yyvsp[-1].col_num,
			            "ranges of type LOGICAL not allowed here");
			    }
			    if (t1 != t2) {
			        syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
			            "range boundaries must have the same type");
			    }
			}
    break;

  case 390:
#line 2859 "fortran.y"
    {
			    int t = datatype_of(yyvsp[0].TOK_type);
			    if (t == type_LOGICAL) {
			        syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
			            "ranges may not have type LOGICAL bounds");
			    }
			}
    break;

  case 391:
#line 2867 "fortran.y"
    {
			    int t = datatype_of(yyvsp[0].TOK_type);
			    if (t == type_LOGICAL) {
			        syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
			            "ranges may not have type LOGICAL bounds");
			    }
			}
    break;

  case 392:
#line 2877 "fortran.y"
    {
			    int t = datatype_of(yyvsp[0].TOK_type);
			    if (t != type_ERROR) {
			        if (!is_const_type(t) || is_float_type(t)) {
			            syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
			"integer, character, or logical expression required");
			        }
			    }
			    if (!is_true(CONST_EXPR, yyvsp[0].TOK_flags)) {
			        syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
			"expression must evaluate to a compile-time constant");
			    }
			    yyval = yyvsp[0];
			}
    break;

  case 397:
#line 2912 "fortran.y"
    {
			  if( ! is_true(LVALUE_EXPR,yyvsp[-3].TOK_flags) ) {
			    syntax_error(yyvsp[-3].line_num,yyvsp[-3].col_num,
					 "index is not assignable");
			    if(is_true(CONST_EXPR,yyvsp[-3].TOK_flags))
				msg_tail(": it is a constant");
			    yyval.value.integer = -1; /* no hash entry */
			  }
			  else {
			     def_do_variable(&(yyvsp[-3]));
				/* Store hash index of DO index in token for
				   use when pushing block on stack. The
				   value field is not used by keywords, so it
				   is OK to use it this way. */
			     yyval.value.integer = yyvsp[-3].value.integer;
			  }

				/* Check for non-integer DO index or bounds */
			     if(datatype_of(yyvsp[-3].TOK_type) == type_INTEGER
				&& datatype_of(yyvsp[-1].TOK_type) != type_INTEGER) {
			       if( f95_real_do ) {
				 nonstandard(yyvsp[-1].line_num,yyvsp[-1].col_num,0,f95_real_do);
				 msg_tail(": DO loop bounds not integer");
			       }
			       else if(misc_warn) {
				 warning(yyvsp[-2].line_num,yyvsp[-2].col_num,
				  "type mismatch between DO index and bounds");
			       }
			     }
			     else if(datatype_of(yyvsp[-3].TOK_type) != type_INTEGER) {
			       if( f95_real_do ) {
				 nonstandard(yyvsp[-3].line_num,yyvsp[-3].col_num,0,f95_real_do);
				 msg_tail(": DO index is not integer");
			       }
			       else if(datatype_of(yyvsp[-1].TOK_type) != type_INTEGER) {
				 if(port_real_do)
				   nonportable(yyvsp[-1].line_num,yyvsp[-1].col_num,
					       "non-integer DO loop");
			       }
			       else {
				 if(trunc_real_do_index) {
				   warning(yyvsp[-3].line_num,yyvsp[-3].col_num,
					   "DO index is not integer");
				 }
			       }
			     }
			}
    break;

  case 398:
#line 2960 "fortran.y"
    {complex_const_allowed=TRUE;}
    break;

  case 399:
#line 2961 "fortran.y"
    {
			    if(is_true(ID_EXPR,yyvsp[-2].TOK_flags)){
				use_variable(&(yyvsp[-2]));
			    }
			    complex_const_allowed=FALSE;
			    make_true(NONSTD_USAGE_FLAG,yyval.TOK_flags);
			    yyval.value.integer = -1; /* no DO index */
			    curr_stmt_name = NULL;
			}
    break;

  case 400:
#line 2974 "fortran.y"
    {complex_const_allowed=TRUE;}
    break;

  case 401:
#line 2975 "fortran.y"
    {
			    if(is_true(ID_EXPR,yyvsp[-2].TOK_flags)){
				use_variable(&(yyvsp[-2]));
			    }
			    complex_const_allowed=FALSE;
			    make_true(NONSTD_USAGE_FLAG,yyval.TOK_flags);
			    yyval.value.integer = -1; /* no DO index */
			}
    break;

  case 402:
#line 2984 "fortran.y"
    {
			    make_true(NONSTD_USAGE_FLAG,yyval.TOK_flags);
			    yyval.value.integer = -1; /* no DO index */
			}
    break;

  case 403:
#line 2991 "fortran.y"
    {
		/* In picky mode warn if no name tag on block construct. */
			  if( style_req_construct_name ) {
			      warning(yyvsp[0].line_num,yyvsp[0].col_num,
				"Construct name missing from DO statement");
			  }
			  curr_stmt_name = NULL;
			}
    break;

  case 404:
#line 3000 "fortran.y"
    {
			  if(f77_construct_name) {
			    nonstandard(yyvsp[-1].line_num,yyvsp[-1].col_num,0,0);
			    msg_tail(": DO construct name");
			  }
			  construct_name_seen=FALSE;
			  yyval = yyvsp[0];
			}
    break;

  case 405:
#line 3011 "fortran.y"
    {
			    ref_label(&(yyvsp[0]), LAB_DO);
			    def_do_label(&(yyvsp[0]));
				/* Save label in subclass for push_block */
			    yyval.tsubclass = yyvsp[0].value.integer;
			}
    break;

  case 406:
#line 3018 "fortran.y"
    {
                            ref_label(&(yyvsp[-1]), LAB_DO);
			    def_do_label(&(yyvsp[-1]));
			    yyval.tsubclass = yyvsp[-1].value.integer;
			}
    break;

  case 407:
#line 3024 "fortran.y"
    {
			    make_true(NONSTD_USAGE_FLAG,yyval.TOK_flags);
			    integer_context=FALSE;
			    yyval.tsubclass = (long)NO_LABEL;
			}
    break;

  case 408:
#line 3032 "fortran.y"
    {
			    yyval.TOK_type=do_bounds_type(&(yyvsp[-2]),&(yyvsp[0]),&(yyvsp[0]));
			}
    break;

  case 409:
#line 3036 "fortran.y"
    {
			    yyval.TOK_type=do_bounds_type(&(yyvsp[-4]),&(yyvsp[-2]),&(yyvsp[0]));
			}
    break;

  case 410:
#line 3042 "fortran.y"
    {
			  curr_stmt_name = NULL;
			}
    break;

  case 413:
#line 3055 "fortran.y"
    {
			   if( f77_cycle_exit ) {
			     nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,0,0);
			     msg_tail(": CYCLE statement");
			   }
		}
    break;

  case 414:
#line 3062 "fortran.y"
    {
			   if( f77_cycle_exit ) {
			     nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,0,0);
			     msg_tail(": EXIT statement");
			   }
		}
    break;

  case 420:
#line 3084 "fortran.y"
    {
			  if( f95_pause ) {
			    nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num,0,f95_pause);
			    msg_tail(": PAUSE statement");
			  }
			}
    break;

  case 423:
#line 3095 "fortran.y"
    {
			     use_variable(&(yyvsp[0]));
			}
    break;

  case 425:
#line 3103 "fortran.y"
    {complex_const_allowed = FALSE;}
    break;

  case 427:
#line 3105 "fortran.y"
    {complex_const_allowed = FALSE;}
    break;

  case 429:
#line 3108 "fortran.y"
    {init_io_ctrl_list();}
    break;

  case 430:
#line 3110 "fortran.y"
    {complex_const_allowed = TRUE;}
    break;

  case 434:
#line 3121 "fortran.y"
    {
			    record_default_io();
			}
    break;

  case 435:
#line 3125 "fortran.y"
    {
			    record_default_io();
			}
    break;

  case 436:
#line 3129 "fortran.y"
    {init_io_ctrl_list();}
    break;

  case 437:
#line 3133 "fortran.y"
    {
			    if(f77_accept_type || f90_accept_type)
				nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num,f90_accept_type,0);
			    record_default_io();
			}
    break;

  case 438:
#line 3139 "fortran.y"
    {
			    if(f77_accept_type || f90_accept_type)
				nonstandard(yyvsp[-4].line_num,yyvsp[-4].col_num,f90_accept_type,0);
			    record_default_io();
			}
    break;

  case 439:
#line 3148 "fortran.y"
    {
			    record_default_io();
			}
    break;

  case 440:
#line 3152 "fortran.y"
    {complex_const_allowed = TRUE;}
    break;

  case 441:
#line 3153 "fortran.y"
    {complex_const_allowed = FALSE;}
    break;

  case 442:
#line 3154 "fortran.y"
    {
			    record_default_io();
			}
    break;

  case 443:
#line 3160 "fortran.y"
    {
			    if(f77_accept_type || f90_accept_type)
				nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num,f90_accept_type,0);
			    record_default_io();
			}
    break;

  case 444:
#line 3166 "fortran.y"
    {complex_const_allowed = TRUE;}
    break;

  case 445:
#line 3167 "fortran.y"
    {complex_const_allowed = FALSE;}
    break;

  case 446:
#line 3168 "fortran.y"
    {
			    if(f77_accept_type || f90_accept_type)
				nonstandard(yyvsp[-6].line_num,yyvsp[-6].col_num,f90_accept_type,0);
			    record_default_io();
			}
    break;

  case 447:
#line 3177 "fortran.y"
    {
			    ++control_item_count;
			}
    break;

  case 448:
#line 3181 "fortran.y"
    {
			    ++control_item_count;
			    if(! io_warning_given) {
			      if( io_internal_file ) {
				if( (curr_stmt_class == tok_WRITE ||
				     curr_stmt_class == tok_READ) &&
				    io_list_directed ) {
				  if(f77_internal_list_io) {
				    nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,0,0);
	    msg_tail(": internal file cannot be used with list-directed I/O");
				  }
				  io_warning_given = TRUE;
				}
			      }
			    }
			}
    break;

  case 449:
#line 3203 "fortran.y"
    {
			    use_io_keyword(&(yyvsp[-2]),&(yyvsp[0]),curr_stmt_class);
			}
    break;

  case 450:
#line 3207 "fortran.y"
    {
			  if(control_item_count == 0) /* unit id */
			  {
					/* Handle special cases */
			    if( datatype_of(yyvsp[0].TOK_type) == type_STRING ) {
					/* unit id=char variable is
					   an internal file.  I/O goes in
					   and out of the variable. */
			      if( is_true(ID_EXPR,yyvsp[0].TOK_flags) ) {
				 io_internal_file = TRUE;
				 if(curr_stmt_class == tok_WRITE) {
				      use_lvalue(&(yyvsp[0]));
				 }
			      }
			      else { /* internal unit must be a variable */
				syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
					"internal file must be a variable");
			      }
			    }
			    else { /* Otherwise it is a normal external file unit id */
				 record_io_unit_id(&yyvsp[0]);
			    }
			  }
			  else if(control_item_count == 1) /* format id */
			  {
			    if( yyvsp[0].tclass == '*' )
			    {
				 io_list_directed = TRUE;
			    }
			    else if( is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				 if(datatype_of(yyvsp[0].TOK_type) == type_NAMELIST) {
				   ref_namelist(&(yyvsp[0]),curr_stmt_class);
				 }
				 else
				     /* format id=integer variable is assigned format */
				   if( datatype_of(yyvsp[0].TOK_type) == type_INTEGER) {
				     if( f95_assign ) {
				       nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,0,f95_assign);
				       msg_tail(": assigned format");
				     }
				   }
			    }
				/* An integer at this point is a format label */
			    else if ( is_true(LIT_CONST,yyvsp[0].TOK_flags) &&
				      yyvsp[0].TOK_type == type_byte(class_VAR,type_INTEGER))
			    {
				 ref_label(&(yyvsp[0]),LAB_IO);
			    }
			    current_io_form = IO_FORM_FORMATTED;
  			  }
					/* Handle use of variable */
			  if( is_true(ID_EXPR,yyvsp[0].TOK_flags)){
			       use_variable(&(yyvsp[0]));
			  }
			}
    break;

  case 451:
#line 3270 "fortran.y"
    {
			    if( yyvsp[0].tclass != '*'
			       && is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				use_variable(&(yyvsp[0]));
			    }
			    if(control_item_count == 0)
			    {
			       record_io_unit_id(&(yyvsp[0]));
			    }
			    ++control_item_count;
			}
    break;

  case 452:
#line 3282 "fortran.y"
    {
			    use_io_keyword(&(yyvsp[-2]),&(yyvsp[0]),curr_stmt_class);
			    ++control_item_count;
			}
    break;

  case 453:
#line 3287 "fortran.y"
    {
			    ++control_item_count;
			}
    break;

  case 454:
#line 3293 "fortran.y"
    {
			    use_io_keyword(&(yyvsp[-2]),&(yyvsp[0]),curr_stmt_class);
			}
    break;

  case 455:
#line 3297 "fortran.y"
    {
			    use_special_open_keywd(&(yyvsp[0]));
			}
    break;

  case 458:
#line 3308 "fortran.y"
    {
			    if( curr_stmt_class == tok_READ ||
				curr_stmt_class == tok_ACCEPT ) { /* Input */
				if(is_true(LVALUE_EXPR,yyvsp[0].TOK_flags)) {
				    use_lvalue(&(yyvsp[0]));
				}
				else {
				    syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
						 "item is not assignable");
				/* Give hint if it is a parameter */
				    if(is_true(ID_EXPR,yyvsp[0].TOK_flags) &&
				       is_true(CONST_EXPR,yyvsp[0].TOK_flags))
					msg_tail(": it is a constant");
				}
			    }
			    else {				 /* Output */
				if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				    use_variable(&(yyvsp[0]));
				}
			    }
			}
    break;

  case 460:
#line 3334 "fortran.y"
    {
			  if( ! is_true(LVALUE_EXPR,yyvsp[-3].TOK_flags) ) {
			    syntax_error(yyvsp[-3].line_num,yyvsp[-3].col_num,
					 "index is not assignable");
			    if(is_true(CONST_EXPR,yyvsp[-3].TOK_flags))
				msg_tail(": it is a constant");
			  }
			  else {
			     use_implied_do_index(&(yyvsp[-3]));
			  }
			}
    break;

  case 461:
#line 3348 "fortran.y"
    {init_io_ctrl_list();}
    break;

  case 463:
#line 3353 "fortran.y"
    {init_io_ctrl_list();}
    break;

  case 465:
#line 3358 "fortran.y"
    {init_io_ctrl_list();}
    break;

  case 467:
#line 3364 "fortran.y"
    {
			    if( yyvsp[-1].tclass != '*'
			       && is_true(ID_EXPR,yyvsp[-1].TOK_flags)){
				use_variable(&(yyvsp[-1]));
			    }
			    record_io_unit_id(&yyvsp[-1]);
			}
    break;

  case 469:
#line 3373 "fortran.y"
    {init_io_ctrl_list();}
    break;

  case 470:
#line 3378 "fortran.y"
    {
			    if( yyvsp[-1].tclass != '*'
			       && is_true(ID_EXPR,yyvsp[-1].TOK_flags)){
				use_variable(&(yyvsp[-1]));
			    }
			    record_io_unit_id(&yyvsp[-1]);
			}
    break;

  case 472:
#line 3387 "fortran.y"
    {init_io_ctrl_list();}
    break;

  case 473:
#line 3392 "fortran.y"
    {
			    if( yyvsp[-1].tclass != '*'
			       && is_true(ID_EXPR,yyvsp[-1].TOK_flags)){
				use_variable(&(yyvsp[-1]));
			    }
			    record_io_unit_id(&yyvsp[-1]);
			}
    break;

  case 475:
#line 3401 "fortran.y"
    {init_io_ctrl_list();}
    break;

  case 478:
#line 3415 "fortran.y"
    {
			  if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
			    use_variable(&(yyvsp[0]));
				/* If integer, format_id is assigned format */
			    if( datatype_of(yyvsp[0].TOK_type) == type_INTEGER ) {
			      if( f95_assign ) {
				nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,0,f95_assign);
				msg_tail(": assigned format");
			      }
			    }
			  }
			     /* A format label appears here as integer const */
			  else if(is_true(LIT_CONST,yyvsp[0].TOK_flags) &&
			    yyvsp[0].TOK_type == type_byte(class_VAR,type_INTEGER)){
			      ref_label(&(yyvsp[0]),LAB_IO);
			  }
			}
    break;

  case 480:
#line 3436 "fortran.y"
    {inside_format=TRUE;}
    break;

  case 481:
#line 3437 "fortran.y"
    {
			  inside_format=FALSE;
			}
    break;

  case 492:
#line 3463 "fortran.y"
    {
			  if( f95_Hedit ) {
			    nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,0,f95_Hedit);
			    msg_tail(": H edit descriptor");
			  }
			}
    break;

  case 500:
#line 3479 "fortran.y"
    {
			  if(f77_format_dollarsigns || f90_format_dollarsigns)
			     nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,f90_format_dollarsigns,0);
			}
    break;

  case 505:
#line 3494 "fortran.y"
    {inside_format=FALSE;}
    break;

  case 506:
#line 3495 "fortran.y"
    {inside_format=TRUE;}
    break;

  case 507:
#line 3496 "fortran.y"
    {
			  if(f77_variable_format || f90_variable_format)
			     nonstandard(yyvsp[-4].line_num,yyvsp[-4].col_num,f90_variable_format,0);
			}
    break;

  case 508:
#line 3505 "fortran.y"
    {
			  check_stmt_sequence(&(yyvsp[-3]),SEQ_STMT_FUN);
			  check_f90_stmt_sequence(&(yyvsp[-3]),F90_SEQ_SPECIF);

				def_stmt_function(&(yyvsp[-3]),&(yyvsp[-1]));
					/* make token info */
				primary_id_expr(&(yyvsp[-3]),&(yyval));
#ifdef DEBUG_PARSER
				if(debug_parser)
				  print_exprlist("stmt function",&(yyvsp[-1]));
#endif
			}
    break;

  case 509:
#line 3520 "fortran.y"
    {
			    yyval.next_token = (Token*)NULL;
			}
    break;

  case 511:
#line 3527 "fortran.y"
    {
			    yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			}
    break;

  case 512:
#line 3532 "fortran.y"
    {
			    yyval.next_token = append_token(yyvsp[-2].next_token,&(yyvsp[0]));
			}
    break;

  case 514:
#line 3542 "fortran.y"
    {
			     call_subr(&(yyvsp[0]),(Token*)NULL);
			     complex_const_allowed = FALSE;
			}
    break;

  case 516:
#line 3548 "fortran.y"
    {
			     call_subr(&(yyvsp[-2]),(Token*)NULL);
			     complex_const_allowed = FALSE;
			}
    break;

  case 518:
#line 3554 "fortran.y"
    {
			     call_subr(&(yyvsp[-3]),&(yyvsp[-1]));
#ifdef DEBUG_PARSER
			     if(debug_parser)
				print_exprlist("call stmt",&(yyvsp[-1]));
#endif
			     complex_const_allowed = FALSE;
			}
    break;

  case 520:
#line 3565 "fortran.y"
    {
			     complex_const_allowed = TRUE;
			     yyval = yyvsp[0];
			}
    break;

  case 521:
#line 3571 "fortran.y"
    {
			    yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			    yyval.left_token = (Token *)NULL;
			}
    break;

  case 522:
#line 3576 "fortran.y"
    {
			    yyval.next_token = append_token(yyvsp[-2].next_token,&(yyvsp[0]));
			}
    break;

  case 523:
#line 3582 "fortran.y"
    {
			    if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				 use_actual_arg(&(yyvsp[0]));
				 use_variable(&(yyvsp[0]));
			    }
			}
    break;

  case 524:
#line 3589 "fortran.y"
    {
			    ref_label(&(yyvsp[0]), LAB_CALL);  
			  yyval = yyvsp[0];
			  yyval.left_token = (Token *)NULL;
			}
    break;

  case 525:
#line 3598 "fortran.y"
    {
			  (void)do_RETURN(current_module_hash,&(yyvsp[-1]));
			}
    break;

  case 526:
#line 3602 "fortran.y"
    {
			  if( do_RETURN(current_module_hash,&(yyvsp[-2])) ) {

				/* Warn if alternate return value is a constant
				   that is not between 0 and the number of
				   labels that are dummy-arguments.
				 */
			     if( pretty_alt_return &&
				(is_true(EVALUATED_EXPR,yyvsp[-1].TOK_flags) &&
			        (yyvsp[-1].value.integer < 1 ||
				  yyvsp[-1].value.integer > label_dummy_arg_count)) ){
				 warning(yyvsp[-1].line_num,yyvsp[-1].col_num,
					 "alternate return value");
				 msg_tail(ulongtostr(yyvsp[-1].value.integer));
				 if( yyvsp[-1].value.integer < 0 ) {
				   msg_tail("is negative");
				 }
				 else {
				   msg_tail("exceeds");
				   msg_tail(ulongtostr(label_dummy_arg_count));
				   msg_tail("= number of alternative return points");
				 }
			     }
			     else {
				/* Style warning is under goto rubric */
			       if( style_goto ) {
				 warning(yyvsp[-2].line_num,yyvsp[-2].col_num,
				     "obsolescent feature: alternate return");
			       }
			     }
			  }
			}
    break;

  case 527:
#line 3638 "fortran.y"
    {
				   /* restore context */
				if(!is_true(COMPLEX_FLAG,yyvsp[-3].TOK_flags))
				  complex_const_allowed=FALSE;
				if(is_true(IN_ASSIGN,yyvsp[-3].TOK_flags))
				  in_assignment_stmt = TRUE;

				  /* Change empty arg list to no arg list */
				if(yyvsp[-1].next_token == NULL)
				  call_func(&(yyvsp[-3]),(Token *)NULL);
				else
				  call_func(&(yyvsp[-3]),&(yyvsp[-1]));
							/* make token info */
				func_ref_expr(&(yyvsp[-3]),&(yyvsp[-1]),&(yyval));
				/* Substitute empty token for null arglist */
				yyval.left_token = add_tree_node(
						   &(yyvsp[-2]),&(yyvsp[-3]),
						   (yyvsp[-1].next_token == NULL?
						    empty_token(&(yyvsp[-1])) :
						    yyvsp[-1].next_token) );
#ifdef DEBUG_PARSER
				if(debug_parser)
				    print_exprlist("function",&(yyvsp[-1]));
#endif
			}
    break;

  case 528:
#line 3666 "fortran.y"
    {
			  if(complex_const_allowed)/* save context */
			    make_true(COMPLEX_FLAG,yyval.TOK_flags);
			  complex_const_allowed=TRUE;
			  if(in_assignment_stmt)
			    make_true(IN_ASSIGN,yyval.TOK_flags);
			  in_assignment_stmt = FALSE;
			}
    break;

  case 529:
#line 3676 "fortran.y"
    {
				yyval.tclass = 0;
				yyval.next_token = (Token *)NULL;
				yyval.left_token = (Token *)NULL;
			}
    break;

  case 531:
#line 3685 "fortran.y"
    {
			    yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			    yyval.left_token = (Token *)NULL;
			}
    break;

  case 532:
#line 3690 "fortran.y"
    {
			    yyval.next_token = append_token(yyvsp[-2].next_token,&(yyvsp[0]));
			}
    break;

  case 533:
#line 3699 "fortran.y"
    {
			  int t=datatype_of(yyvsp[0].TOK_type);
			  if( t != type_ERROR){
			    if( ! is_const_type(t) ) {
			      syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
		      "arithmetic, char, or logical expression expected");
			    }
			    else {
			      if( !is_true(PARAMETER_EXPR,yyvsp[0].TOK_flags) ) {
				syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
					   "constant expression expected");
			      }
			    /* Here we allow, with some warnings, expr
			       containing intrins func or **REAL in
			       PARAMETER defn. */
			      else if( !is_true(CONST_EXPR,yyvsp[0].TOK_flags) ) {
				if(f77_param_intrinsic) {
				  nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,0,0);
				  msg_tail(
			 "intrinsic function or **REAL in PARAMETER defn");
				}
			      }
			    }
			  }
			}
    break;

  case 534:
#line 3728 "fortran.y"
    {
				/* Fix it up in case it is used in expr list */
			  yyval.next_token = (Token *) NULL;
#ifdef DEBUG_PARSER
			    if(debug_parser) {
				(void)fprintf(list_fd,
					"\nexpr: class=0x%lx subclass=0x%lx",
					yyvsp[0].tclass,
					yyvsp[0].tsubclass);
			    }
#endif
			}
    break;

  case 536:
#line 3745 "fortran.y"
    {
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			}
    break;

  case 537:
#line 3750 "fortran.y"
    {
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			}
    break;

  case 539:
#line 3759 "fortran.y"
    {
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			}
    break;

  case 541:
#line 3768 "fortran.y"
    {
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			}
    break;

  case 543:
#line 3777 "fortran.y"
    {
			    do_unexpr(&(yyvsp[-1]),&(yyvsp[0]),&(yyval));
			}
    break;

  case 545:
#line 3785 "fortran.y"
    {
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			}
    break;

  case 547:
#line 3795 "fortran.y"
    {
			    do_unexpr(&(yyvsp[-1]),&(yyvsp[0]),&(yyval));
			}
    break;

  case 548:
#line 3799 "fortran.y"
    {
			    do_unexpr(&(yyvsp[-1]),&(yyvsp[0]),&(yyval));
			}
    break;

  case 549:
#line 3803 "fortran.y"
    {
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			}
    break;

  case 550:
#line 3808 "fortran.y"
    {
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			}
    break;

  case 552:
#line 3817 "fortran.y"
    {
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			    if(div_check &&
			       !is_true(CONST_EXPR,yyvsp[0].TOK_flags)){
				warning(yyvsp[-1].line_num,yyvsp[-1].col_num,
					"Possible division by zero");
			    }
			}
    break;

  case 553:
#line 3827 "fortran.y"
    {
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			}
    break;

  case 555:
#line 3836 "fortran.y"
    {
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			}
    break;

  case 557:
#line 3845 "fortran.y"
    {
			  do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			}
    break;

  case 558:
#line 3852 "fortran.y"
    {
			    make_true(DIM_BOUND_EXPR,yyval.TOK_flags);
			}
    break;

  case 562:
#line 3862 "fortran.y"
    {
			    yyval.TOK_flags = 0;
			    yyval.left_token = (Token *)NULL;
			    make_true(CONST_EXPR,yyval.TOK_flags);
			    make_true(PARAMETER_EXPR,yyval.TOK_flags);
			    make_true(LIT_CONST,yyval.TOK_flags);
			    make_true(EVALUATED_EXPR,yyval.TOK_flags);
			    make_true(DIM_BOUND_EXPR,yyval.TOK_flags);
			}
    break;

  case 563:
#line 3872 "fortran.y"
    {
			    yyval = yyvsp[-1];
				/* (identifier) becomes a non-identifier */
			    if(is_true(LVALUE_EXPR,yyvsp[-1].TOK_flags)) {
				if(pretty_parens) {
				  ugly_code(yyvsp[-1].line_num,yyvsp[-1].col_num,
					  "Extraneous parentheses");
				}
				use_variable(&(yyvsp[-1]));
				make_false(LVALUE_EXPR,yyval.TOK_flags);
				make_false(ARRAY_ID_EXPR,yyval.TOK_flags);
				make_false(ARRAY_ELEMENT_EXPR,yyval.TOK_flags);
				make_false(ID_EXPR,yyval.TOK_flags);
				make_false(DO_VARIABLE,yyval.TOK_flags);
			    }
				/* (expr) becomes tree node with root = '(' */
			    yyval.left_token = add_tree_node(&(yyvsp[-2]),&(yyvsp[-1]),
							  (Token*)NULL);
			}
    break;

  case 565:
#line 3898 "fortran.y"
    {
			    yyval.TOK_type = type_byte(class_VAR,type_STRING);
			    /* (size is set in get_string) */
			}
    break;

  case 566:
#line 3903 "fortran.y"
    {
			    yyval.TOK_type = type_byte(class_VAR,type_HOLLERITH);
			    /* (size is set in get_hollerith) */
			    if(port_hollerith) {
				warning(yyvsp[0].line_num,yyvsp[0].col_num,
				"hollerith constant may not be portable");
			    }
			}
    break;

  case 567:
#line 3912 "fortran.y"
    {
			    yyval.TOK_type = type_byte(class_VAR,type_LOGICAL);
			    yyval.size = size_DEFAULT;
			}
    break;

  case 568:
#line 3919 "fortran.y"
    {
			    yyval.TOK_type = type_byte(class_VAR,type_INTEGER);
			    yyval.size = size_DEFAULT;
			}
    break;

  case 569:
#line 3924 "fortran.y"
    {
			    yyval.TOK_type = type_byte(class_VAR,type_REAL);
			    yyval.size = size_DEFAULT;
			}
    break;

  case 570:
#line 3929 "fortran.y"
    {
			    yyval.TOK_type = type_byte(class_VAR,type_DP);
			    yyval.size = size_DEFAULT;
			}
    break;

  case 571:
#line 3934 "fortran.y"
    {
			    yyval.TOK_type = type_byte(class_VAR,type_QUAD);
			    yyval.size = size_QUAD;
                            if(f77_quad_constants || f90_quad_constants) {
                              nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,f90_quad_constants,0);
                              msg_tail(": quad precision constant");
                            }
			}
    break;

  case 572:
#line 3943 "fortran.y"
    {
			    yyval.TOK_type = type_byte(class_VAR,type_COMPLEX);
			    yyval.size = size_DEFAULT;
			}
    break;

  case 573:
#line 3948 "fortran.y"
    {
			    yyval.TOK_type = type_byte(class_VAR,type_DCOMPLEX);
			    yyval.size = size_DEFAULT;
			}
    break;

  case 574:
#line 3956 "fortran.y"
    {
			    if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				use_variable(&(yyvsp[0]));
			    }
			    if(datatype_of(yyvsp[0].TOK_type) != type_INTEGER) {
				syntax_error(
					yyvsp[0].line_num,yyvsp[0].col_num,
					"expression must be integer type");
			    }
			}
    break;

  case 575:
#line 3970 "fortran.y"
    {
			    if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				use_variable(&(yyvsp[0]));
			    }
			    {
				int t=datatype_of(yyvsp[0].TOK_type);
				    if(t != type_INTEGER && t != type_REAL
					&& t != type_DP ) {
					syntax_error(
					  yyvsp[0].line_num,yyvsp[0].col_num,
		"expression must be integer, real, or double precision type");
			    	    }
			    }
			}
    break;

  case 576:
#line 3990 "fortran.y"
    {
			    if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				use_variable(&(yyvsp[0]));
			    }
			    if( ! is_true(CONST_EXPR,yyvsp[0].TOK_flags) ) {
				syntax_error(
					yyvsp[0].line_num,yyvsp[0].col_num,
					"constant expression expected");
			    }
			    else {
			      if(datatype_of(yyvsp[0].TOK_type) != type_INTEGER){
				syntax_error(
					yyvsp[0].line_num,yyvsp[0].col_num,
					"integer expression expected");
			      }
			      else {
				yyval.value.integer = int_expr_value(&(yyvsp[0]));
			      }
			    }
			}
    break;

  case 577:
#line 4014 "fortran.y"
    {
			    if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				use_variable(&(yyvsp[0]));
			    }

			    if(f77_array_bounds) {	/* Section 5.1.1.1 */
			      if( !is_true(DIM_BOUND_EXPR,yyvsp[0].TOK_flags) ) {
				nonstandard(yyvsp[0].line_num,yyvsp[0].col_num,0,0);
				msg_tail(
		": array bounds expr cannot have array or function reference");
			      }
			    }

			    if( datatype_of(yyvsp[0].TOK_type) != type_INTEGER ){
				syntax_error(
					yyvsp[0].line_num,yyvsp[0].col_num,
					"integer dimension expected");
				yyval.value.integer = 0;
			    }
			    else {
			      if( is_true(EVALUATED_EXPR,yyvsp[0].TOK_flags) )
				yyval.value.integer =
				  int_expr_value(&(yyvsp[0]));
			      else		/* must be dummy */
				yyval.value.integer = 0;
			    }
			}
    break;

  case 578:
#line 4048 "fortran.y"
    {
				ref_array(&(yyvsp[-3]),&(yyvsp[-1]));
#ifdef DEBUG_PARSER
				if(debug_parser)
				    print_exprlist("array lvalue",&(yyvsp[-1]));
#endif
					/* array now becomes scalar */
				make_false(ARRAY_ID_EXPR,yyval.TOK_flags);
				make_true(ARRAY_ELEMENT_EXPR,yyval.TOK_flags);
				yyval.left_token = add_tree_node(
						   &(yyvsp[-2]),&(yyvsp[-3]),yyvsp[-1].next_token);
				yyval.next_token = (Token *) NULL;
			}
    break;

  case 579:
#line 4064 "fortran.y"
    {
				ref_array(&(yyvsp[-3]),&(yyvsp[-1]));
#ifdef DEBUG_PARSER
				if(debug_parser)
				    print_exprlist("array",&(yyvsp[-1]));
#endif
					/* array now becomes scalar */
				make_false(ARRAY_ID_EXPR,yyval.TOK_flags);
				make_true(ARRAY_ELEMENT_EXPR,yyval.TOK_flags);
				yyval.left_token = add_tree_node(
						   &(yyvsp[-2]),&(yyvsp[-3]),yyvsp[-1].next_token);
				yyval.next_token = (Token *) NULL;
			}
    break;

  case 580:
#line 4080 "fortran.y"
    {
			    yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			}
    break;

  case 581:
#line 4084 "fortran.y"
    {
			    yyval.next_token = append_token(yyvsp[-2].next_token,&(yyvsp[0]));
			}
    break;

  case 582:
#line 4090 "fortran.y"
    {
			    if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				 use_variable(&(yyvsp[0]));
			    }
				/* check subscript exprs for integer type */
			    if(datatype_of(yyvsp[0].TOK_type) != type_INTEGER)
			      if(trunc_real_subscript)
			         warning(yyvsp[0].line_num,yyvsp[0].col_num,
					 "subscript is not integer");
			}
    break;

  case 583:
#line 4104 "fortran.y"
    {
				   /* restore status of complex flag */
			    if(!is_true(COMPLEX_FLAG,yyvsp[-1].TOK_flags))
				  complex_const_allowed=FALSE;
				/* set flag to keep more than just id for
				   arg list text */
			    if(is_true(ID_EXPR,yyvsp[-1].TOK_flags))
			       make_true(ARRAY_ELEMENT_EXPR,yyval.TOK_flags);
			    yyval.size=substring_size(&(yyvsp[-1]),&(yyvsp[0]));
			    yyval.left_token = add_tree_node(
					       &save_token,&(yyvsp[-1]),&(yyvsp[0]));
			    yyval.next_token = (Token *) NULL;
			}
    break;

  case 584:
#line 4119 "fortran.y"
    {
			    yyval.size=substring_size(&(yyvsp[-1]),&(yyvsp[0]));
			    yyval.left_token = add_tree_node(
					       &save_token,&(yyvsp[-1]),&(yyvsp[0]));
			    yyval.next_token = (Token *) NULL;
			}
    break;

  case 585:
#line 4127 "fortran.y"
    {
			    yyval.size=substring_size(&(yyvsp[-1]),&(yyvsp[0]));
			    yyval.left_token = add_tree_node(
					       &save_token,&(yyvsp[-1]),&(yyvsp[0]));
			    yyval.next_token = (Token *) NULL;
			}
    break;

  case 586:
#line 4136 "fortran.y"
    {
			    ref_variable(&(yyvsp[-1]));
			    yyval.TOK_flags = yyvsp[-1].TOK_flags;
			    yyval.size=substring_size(&(yyvsp[-1]),&(yyvsp[0]));
			}
    break;

  case 587:
#line 4142 "fortran.y"
    {
			    yyval.size=substring_size(&(yyvsp[-1]),&(yyvsp[0]));
			}
    break;

  case 588:
#line 4151 "fortran.y"
    {
			    yyval.TOK_start=1;
			    yyval.TOK_end=0; /* 0 means LEN */

			    save_token = yyvsp[-2]; /* Save the paren for tree node */
			    yyval.left_token =
			      add_tree_node(&(yyvsp[-1]),
				     empty_token(&(yyvsp[-2])),empty_token(&(yyvsp[0])));
				/* Nullify next_token so it looks like
				   a tokenlist */
			    yyval.next_token = (Token *)NULL;
			}
    break;

  case 589:
#line 4165 "fortran.y"
    {
			    yyval.TOK_start=yyvsp[-2].value.integer;
			    yyval.TOK_end=0; /* 0 means LEN */

			    save_token = yyvsp[-3]; /* Save the paren for tree node */
			    yyval.left_token =
			      add_tree_node(&(yyvsp[-1]),&(yyvsp[-2]),empty_token(&(yyvsp[0])));
			    yyval.next_token = (Token *)NULL;
			}
    break;

  case 590:
#line 4175 "fortran.y"
    {
			    yyval.TOK_start=1;
			    yyval.TOK_end=yyvsp[-1].value.integer;

			    save_token = yyvsp[-3]; /* Save the paren for tree node */
			    yyval.left_token =
			      add_tree_node(&(yyvsp[-2]),empty_token(&(yyvsp[-3])),&(yyvsp[-1]));
			    yyval.next_token = (Token *)NULL;
			}
    break;

  case 591:
#line 4185 "fortran.y"
    {
			    yyval.TOK_start=yyvsp[-3].value.integer;
			    yyval.TOK_end=yyvsp[-1].value.integer;

			    save_token = yyvsp[-4]; /* Save the paren for tree node */
			    yyval.left_token =
			      add_tree_node(&(yyvsp[-2]),&(yyvsp[-3]),&(yyvsp[-1]));
			    yyval.next_token = (Token *)NULL;
			}
    break;

  case 592:
#line 4197 "fortran.y"
    {
			  if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
			    use_variable(&(yyvsp[0]));
			  }
				/* check validity and replace nonconst
				   value by size_UNKNOWN. */
			  if(is_true(CONST_EXPR,yyvsp[0].TOK_flags)) {
			    if( (yyval.value.integer=int_expr_value(&(yyvsp[0]))) < 1) {
			      syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
					   "invalid substring index");
			    }
			  }
			  else  /* (no longer need ID hash index) */
			    yyval.value.integer=size_UNKNOWN;
			}
    break;

  case 593:
#line 4218 "fortran.y"
    {
			    ref_variable(&(yyvsp[0]));
			    yyval.TOK_flags = yyvsp[0].TOK_flags;
			}
    break;

  case 595:
#line 4226 "fortran.y"
    {
			    ref_identifier(&(yyvsp[0]));
			    primary_id_expr(&(yyvsp[0]),&(yyval));
			}
    break;

  case 596:
#line 4233 "fortran.y"
    {
			    ref_variable(&(yyvsp[0]));
			    primary_id_expr(&(yyvsp[0]),&(yyval));
			}
    break;

  case 599:
#line 4247 "fortran.y"
    {
			  construct_name_seen=TRUE;
				/* remember the name for block balancing */
			  curr_stmt_name = hashtab[yyvsp[-1].value.integer].name;
			}
    break;

  case 600:
#line 4255 "fortran.y"
    {
			  curr_stmt_name = hashtab[yyvsp[0].value.integer].name;
			}
    break;

  case 601:
#line 4259 "fortran.y"
    {
			  curr_stmt_name = hashtab[yyvsp[0].value.integer].name;
			}
    break;

  case 603:
#line 4267 "fortran.y"
    { yyval = yyvsp[0]; }
    break;

  case 604:
#line 4268 "fortran.y"
    { yyval = yyvsp[0]; }
    break;

  case 605:
#line 4270 "fortran.y"
    {
			    yyval.TOK_type = type_byte(class_VAR,type_LOGICAL);
			    yyval.size = size_DEFAULT;
			}
    break;

  case 606:
#line 4275 "fortran.y"
    {
			    yyval.TOK_type = type_byte(class_VAR,type_STRING);
			    yyval.size = size_DEFAULT;
			}
    break;

  case 607:
#line 4280 "fortran.y"
    {
			    yyval.TOK_type = type_byte(class_VAR,type_HOLLERITH);
			    yyval.size = size_DEFAULT;
			}
    break;

  case 608:
#line 4291 "fortran.y"
    {
			  if(yyvsp[0].value.integer == 0) {
			    if(misc_warn) {
			      warning(yyvsp[0].line_num,yyvsp[0].col_num,
				    "nonzero integer expected");
			      msg_tail(": substituting 1");
			    }
			    yyval.value.integer = 1;
			  }
			  yyval.left_token = (Token *)NULL;
			}
    break;

  case 609:
#line 4311 "fortran.y"
    {
			  if(yyvsp[0].value.integer <= 0) {
			    if(yyvsp[0].value.integer < 0) {
			      if(misc_warn || f77_char_extension) { 
				  warning(yyvsp[0].line_num,yyvsp[0].col_num,
					  "non-negative integer expected");
				  msg_tail(": substituting 0");
			      }
			      yyval.value.integer = 0;
			    }
			    else if(f77_char_extension) {
			      warning(yyvsp[0].line_num,yyvsp[0].col_num,
				    "nonzero integer expected");
			    }
			  }
			  yyval.left_token = (Token *)NULL;
			}
    break;

  case 610:
#line 4335 "fortran.y"
    {
			    integer_context=TRUE;
			}
    break;

  case 611:
#line 4342 "fortran.y"
    {
			    if( yyval.value.integer > 99999 && misc_warn) {
				syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
				      "statement label exceeds 5 digits");
			    }
				integer_context=FALSE;
				yyval.TOK_type = type_byte(class_LABEL,type_LABEL);
				yyval.size = size_DEFAULT;
				yyval.TOK_flags = 0;
			}
    break;


    }

/* Line 1000 of yacc.c.  */
#line 6889 "y.tab.c"

  yyvsp -= yylen;
  yyssp -= yylen;


  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  int yytype = YYTRANSLATE (yychar);
	  const char* yyprefix;
	  char *yymsg;
	  int yyx;

	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  int yyxbegin = yyn < 0 ? -yyn : 0;

	  /* Stay within bounds of both yycheck and yytname.  */
	  int yychecklim = YYLAST - yyn;
	  int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
	  int yycount = 0;

	  yyprefix = ", expecting ";
	  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      {
		yysize += yystrlen (yyprefix) + yystrlen (yytname [yyx]);
		yycount += 1;
		if (yycount == 5)
		  {
		    yysize = 0;
		    break;
		  }
	      }
	  yysize += (sizeof ("syntax error, unexpected ")
		     + yystrlen (yytname[yytype]));
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "syntax error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[yytype]);

	      if (yycount < 5)
		{
		  yyprefix = ", expecting ";
		  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
		    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
		      {
			yyp = yystpcpy (yyp, yyprefix);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yyprefix = " or ";
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("syntax error; also virtual memory exhausted");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror ("syntax error");
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* If at end of input, pop the error token,
	     then the rest of the stack, then return failure.  */
	  if (yychar == YYEOF)
	     for (;;)
	       {
		 YYPOPSTACK;
		 if (yyssp == yyss)
		   YYABORT;
		 YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
		 yydestruct (yystos[*yyssp], yyvsp);
	       }
        }
      else
	{
	  YYDSYMPRINTF ("Error: discarding", yytoken, &yylval, &yylloc);
	  yydestruct (yytoken, &yylval);
	  yychar = YYEMPTY;

	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

#ifdef __GNUC__
  /* Pacify GCC when the user code never invokes YYERROR and the label
     yyerrorlab therefore never appears in user code.  */
  if (0)
     goto yyerrorlab;
#endif

  yyvsp -= yylen;
  yyssp -= yylen;
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
      yydestruct (yystos[yystate], yyvsp);
      YYPOPSTACK;
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;


  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*----------------------------------------------.
| yyoverflowlab -- parser overflow comes here.  |
`----------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}


#line 4356 "fortran.y"


void
init_parser(VOID)			/* Initialize various flags & counters */
{
	initial_flag = TRUE;	/* set flag for keyword test */
	implicit_flag=FALSE;	/* clear flags for IMPLICIT stmt */
	implicit_letter_flag = FALSE;
	implicit_type_given = FALSE;
	implicit_none = FALSE;
	global_save = FALSE;
	prev_token_class = EOS;
	complex_const_allowed = FALSE;
	stmt_sequence_no = 0;
	f90_stmt_sequence_no = 0;
	true_prev_stmt_line_num = 0;
	{
	  int i;		/* Reset *_this_file flags for project files */
	  for(i=0; i<glob_symtab_top; i++) {
	    glob_symtab[i].used_this_file =
	      glob_symtab[i].set_this_file =
	      glob_symtab[i].invoked_as_func_this_file =
	      glob_symtab[i].declared_external_this_file = FALSE;
	  }
	}
}

				/* Handle unary expressions: link
				   into a tree and propagate type.
				 */
PRIVATE void
#if HAVE_STDC
do_unexpr(Token *op, Token *expr, Token *result)
#else /* K&R style */
do_unexpr(op,expr,result)
     Token *op,*expr,*result;
#endif /* HAVE_STDC */
{
  unexpr_type(op,expr,result);

  result->left_token = add_tree_node(op, expr, (Token*)NULL);
}
				/* Handle binary expressions: link
				   into a tree and propagate type.
				 */
PRIVATE void
#if HAVE_STDC
do_binexpr(Token *l_expr, Token *op, Token *r_expr, Token *result)
#else /* K&R style */
do_binexpr(l_expr,op,r_expr,result)
     Token *l_expr,*op,*r_expr,*result;
#endif /* HAVE_STDC */
{
  binexpr_type(l_expr,op,r_expr,result); /* Propagate the type */

  result->left_token = add_tree_node(op, l_expr, r_expr);
}


			/* Changes a token to empty and replaces
			   src_text by null string, value by 0.  Other
			   info (line, col, etc.)  unchanged. */

PRIVATE Token *
#if HAVE_STDC
empty_token(Token *t)
#else /* K&R style */
empty_token(t)
     Token *t;
#endif /* HAVE_STDC */
{
#ifdef DEBUG_EMPTY_TOKEN
  static char *nullstring="(empty)"; /* for debugging.  */
#else
  static char *nullstring=""; /* for operation.  */
#endif
  t->tclass = tok_empty;
  t->tsubclass = 0;
  t->value.integer = 0;
  t->left_token = (Token *) NULL;
  t->src_text = nullstring;

  return t;
}

		/* Propagate non-integer type if any of DO loop
		   bounds are non-integer. */
PRIVATE int
#if HAVE_STDC
do_bounds_type(Token *t1, Token *t2, Token *t3)
#else /* K&R style */
do_bounds_type(t1,t2,t3)
     Token *t1, *t2, *t3;
#endif /* HAVE_STDC */
{
  int result_type;
       if(datatype_of(t1->TOK_type) != type_INTEGER)result_type = t1->TOK_type;
  else if(datatype_of(t2->TOK_type) != type_INTEGER)result_type = t2->TOK_type;
  else if(datatype_of(t3->TOK_type) != type_INTEGER)result_type = t3->TOK_type;
  else result_type = t1->TOK_type;
  return result_type;
}


/* Debugging routine: prints the expression list of various productions */
#ifdef DEBUG_PARSER
PRIVATE void
print_exprlist(s,t)
	char *s;
	Token *t;
{

	(void)fprintf(list_fd,"\n%s arglist: ",s);

	if(t == NULL)
		(void)fprintf(list_fd,"(empty)");
	else {
  	    while( (t=t->next_token) != NULL) {
		  fprintf(list_fd,"%s ",type_name[datatype_of(t->TOK_type)]);
		  if( is_true(ID_EXPR,t->TOK_flags) )
			(void)fprintf(list_fd,"(%s) ",token_name(t));
	    }
	}
}

PRIVATE void
print_comlist(s,t)
	char *s;
	Token *t;
{

	(void)fprintf(list_fd,"\n%s varlist: ",s);

	if(t == NULL)
		(void)fprintf(list_fd,"(empty)");
	else {
  	    while( (t=t->next_token) != NULL) {
		  fprintf(list_fd,"%s ",type_name[datatype_of(t->TOK_type)]);
		  if( is_true(ID_EXPR,t->TOK_flags) )
			(void)fprintf(list_fd,"(%s) ",token_name(t));
		}
	  }
}
#endif

/* After having parsed prog_stmt, function_stmt, subroutine_stmt,
   block_data_stmt, the stmt_sequence_no is set to the value SEQ_HEADER.
*/

void
#if HAVE_STDC
check_seq_header(Token *t)
#else /* K&R style */
check_seq_header(t)
     Token *t;
#endif /* HAVE_STDC */
{
	if(stmt_sequence_no >= SEQ_HEADER) {
	   syntax_error( (t == (Token *) NULL? line_num: t->line_num),
			NO_COL_NUM,
			"missing END statement inserted");
	   msg_tail( (t == (Token *) NULL? "at end of file":
		      "prior to statement") );

	   if( t != (Token *) NULL )
	     pop_block(t,tok_END,(char *)NULL,NO_LABEL);

	   END_processing(t);
	}
	stmt_sequence_no = SEQ_HEADER;
	f90_stmt_sequence_no = F90_SEQ_HEADER;
}

PRIVATE void
#if HAVE_STDC
check_stmt_sequence(Token *t, int seq_num)
#else /* K&R style */
check_stmt_sequence(t,seq_num)
     Token *t;
     int seq_num;
#endif /* HAVE_STDC */
{
    if(stmt_sequence_no > seq_num) {
      if(f77_stmt_order) {
	nonstandard(t->line_num, NO_COL_NUM,0,0);
	msg_tail(": Statement out of order.");
      }
    }
			/* If no error, sequence number is updated to new
			   value.  If error, it is rolled back to prevent
			   cascades of error messages.  */
    stmt_sequence_no = seq_num;
}

PRIVATE void
#if HAVE_STDC
check_f90_stmt_sequence(Token *t, int f90_seq_num)
#else /* K&R style */
check_f90_stmt_sequence(t,f90_seq_num)
     Token *t;
     int f90_seq_num;
#endif /* HAVE_STDC */
{
    if(f90_stmt_sequence_no > f90_seq_num) {
      if(f90_stmt_order) {
	nonstandard(t->line_num, NO_COL_NUM,f90_stmt_order,0);
	msg_tail(": Statement out of order.");
      }
    }
			/* If no error, sequence number is updated to new
			   value.  If error, it is rolled back to prevent
			   cascades of error messages.  */
    f90_stmt_sequence_no = f90_seq_num;
}

PRIVATE void
init_io_ctrl_list(VOID)
{
  control_item_count = 0;
  io_internal_file = FALSE;
  io_list_directed = FALSE;
  io_warning_given = FALSE;
  current_io_unit_no = IO_UNIT_UNKNOWN;
  current_io_unit_id = IO_UNIT_UNKNOWN;
  current_io_access = IO_ACCESS_DEFAULT;
  current_io_form = IO_FORM_DEFAULT;
}


		/* Remember the name or number of unit_id for current I/O stmt.
		   This routine is only called by parser productions that have a
		   bare unit_id, so less checking is done than for unit=unit_id
		   specifiers that can refer to other than external files.
		 */
void
record_io_unit_id(Token *id)
{
     if( id->tclass == '*' )
     {
	  current_io_unit_id = IO_UNIT_DEFAULT;
     }
     else if( is_true(ID_EXPR,id->TOK_flags)){
	  current_io_unit_id = id->value.integer; /* get hash code of identifier */
     }
     else if( is_true(LIT_CONST,id->TOK_flags) &&
	      id->TOK_type == type_byte(class_VAR,type_INTEGER))
     {
	  current_io_unit_no = id->value.integer; /* get literal int value */
     }
}

		/* Set I/O usage parameters for default formatted sequential I/O
		   statement like READ *, X  */
PRIVATE void
record_default_io(VOID)
{
  current_io_unit_no = IO_UNIT_UNKNOWN;
  current_io_unit_id = IO_UNIT_DEFAULT;
  current_io_access = IO_ACCESS_SEQUENTIAL;
  current_io_form = IO_FORM_FORMATTED;
}

		/* This routine applies the attributes of attr-based type
		   declaration.  Set dim_bounds to current_dim_bound_list
		   or to NULL if item has its own array bounds declarator.
		 */
PRIVATE void
process_attrs(Token *t,Token *dim_bounds)
{
    if(current_external_attr)
	def_ext_name(t);
    if(current_intrinsic_attr)
	def_intrins_name(t);

    if(current_allocatable_attr)
	apply_attr(t,tok_ALLOCATABLE);
    if(current_pointer_attr)
	apply_attr(t,tok_POINTER);
    if(current_save_attr)
	apply_attr(t,tok_SAVE);
    if(current_target_attr)
	apply_attr(t,tok_TARGET);

    if(dim_bounds != NULL)
	def_array_dim(t,dim_bounds);
}

	/* After having parsed end_stmt, common block lists and
	   subprogram argument lists are copied over into global symbol
	   table, the local symbol table is printed out and then cleared,
	   and stmt_sequence_no is set to zero for start of next module.
	*/

PRIVATE void
#if HAVE_STDC
END_processing(Token *t)
#else /* K&R style */
END_processing(t)
	Token *t;
#endif /* HAVE_STDC */
{
  ++tot_module_count;
  if(current_module_hash != -1) {
        if(exec_stmt_count == 0 &&
	   current_module_type != type_BLOCK_DATA) {
	  if(misc_warn)
	    warning(t == (Token *)NULL? line_num: t->line_num, NO_COL_NUM,
		  "Module contains no executable statements");
	}
	if(do_list && t != (Token *)NULL) {
	    (void)flush_end_stmt(t->line_num);
	}

	doing_end_proc = TRUE;	/* Set flag for special error message mode */

			/* Catch things that had to wait till now */
	check_loose_ends(current_module_hash);
			/* Put arg and com lists into global table */
	process_lists(current_module_hash);
			/* Print symbol table for debug */
	debug_symtabs();
			/* Print local symbol table and do local warnings */
	print_loc_symbols();
			/* Reset local symbol table */
	init_symtab();

	doing_end_proc = FALSE;
  }
  exec_stmt_count = 0;
  stmt_sequence_no = 0;
  f90_stmt_sequence_no = 0;
  current_module_hash = -1;
  implicit_type_given = FALSE;
  implicit_none = FALSE;
  true_prev_stmt_line_num = 0;
  integer_context = FALSE;
  global_save = FALSE;
  label_dummy_arg_count = 0;
  num_io_unit_usages = 0;
}

		/* Routine to create a node for an expr tree.  Returns
		   a pointer to the newly created node.
		 */
PRIVATE Token *
#if HAVE_STDC
add_tree_node(Token *node, Token *left, Token *right)
#else /* K&R style */
add_tree_node(node,left,right)
     Token *node,*left,*right;
#endif /* HAVE_STDC */
{
  Token *new_node, *new_left, *new_right;

  new_node=new_token();

  *new_node = *node;		/* Make a permanent copy of root */

		/* Add the children.  If child's left_token pointer is
		   null, then that expression is a primary.  Otherwise
		   it is the root node of a subtree.
		 */
  if(left->left_token == (Token *)NULL) {
    new_left=new_token();
    *new_left = *left;			/* Copy primary to permanent space */
  }
  else {
    new_left = left->left_token;	/* No copying needed in this case */
  }

  if(right == (Token *)NULL) {
    new_right = (Token *)NULL;		/* No right child */
  }
  else if(right->left_token == (Token *)NULL
	  || node->tclass == '(') { /* Paren means right child is expr list */
    new_right=new_token();
    *new_right = *right;		/* Copy primary to permanent space */
  }
  else {
    new_right = right->left_token;	/* No copying needed in this case */
  }

  new_node->left_token = new_left;	/* Link children onto the new root */
  new_node->next_token = new_right;
  return new_node;
}

		/* Routine to add token t to the front of a token list. */
PRIVATE Token *
#if HAVE_STDC
append_token(Token *tlist, Token *t)
#else /* K&R style */
append_token(tlist,t)
     Token *tlist, *t;
#endif /* HAVE_STDC */
{
	Token *tcopy;

	tcopy=new_token();

	*tcopy = *t;		/* make permanent copy of token */
	tcopy->next_token = tlist; /* link it onto front of list */
	return tcopy;		/* return it as new tlist */
}


			/* Routine to pop closing statement of block off
			   the stack.  Note: label should be NO_LABEL even
			   if the statement has a label, except for terminal
			   statement of a labeled DO loop.
			 */
PRIVATE void pop_block(Token *t, int stmt_class, char *name, LABEL_t label)
{

	/* Define lookup table for block matches.  This table is generated
	   from tokdefs.h by the Perl script make_blockmatch.pl.  This script
	   also generates 4 macro definitions that go here.  It
	   defines MIN_BLOCK_TOKEN and MAX_BLOCK_TOKEN used to bound range
	   of valid keytok_name arguments for error messages.  It also defines
	   MIN_CLOSER and MAX_CLOSER giving the range of token numbers for
	   closing tokens.  The array block_match contains the token numbers
	   for the matching openers.  Look up the matching opener class as
	     block_match[closer_class-MIN_CLOSER]
	   Plain END is handled specially since it matches many things.
	   Likewise closing labeled-DO range is handled specially.  (ENDDO
	   is handled there if loop is labeled, handled with structured
	   block closers otherwise.)
	*/

  static int block_match[] = {
#include "block_match.h"
  };

		/* Macro for names of all block keyword tokens.  Although no
		   error messages should print "identifier" (only occurs
		   as DO terminator, and mismatch is handled specially),
		   include it for possible debug use.  Any other
		   token classes in block_stack mean a bug in ftnchek.
		 */
#define TOKEN_NAME(CLASS) ((CLASS)>=MIN_BLOCK_TOKEN && (CLASS)<=MAX_BLOCK_TOKEN? \
	keytok_name(CLASS):((CLASS) == tok_identifier?"identifier":"bogus"))

		/* Define DBG_TOKNAME for debugging.  If possible,
		   use yytname to allow for bogus tokens showing up.
		   This works only for bison parser generator.  It would
		   be easy to fix up for byacc too if need be.
		*/
#ifdef DEBUG_BLOCKCHECK
#ifdef USE_YYTNAME
#define DBG_TOKNAME(CLASS) (char *)(yytname[YYTRANSLATE(CLASS)])
#else
#define DBG_TOKNAME(CLASS) TOKEN_NAME(CLASS)
#endif
#endif

#ifdef DEBUG_BLOCKCHECK
  if(debug_latest) {
    fprintf(list_fd,"\npopping stmt class %s name %s label %d at line %d",
	    DBG_TOKNAME(stmt_class),name,label,t->line_num);
  }
#endif

  if(block_depth == 0) {
      syntax_error(t->line_num,t->col_num,"no construct to end here");
  }
  else {
    int opener_class, must_check_name=FALSE;
    BLOCK_TYPE blocktype;

    --block_depth;

    opener_class = block_stack[block_depth].sclass;
    blocktype = block_stack[block_depth].blocktype;

#ifdef DEBUG_BLOCKCHECK
    if(debug_latest) {
      fprintf(list_fd,"\n  opener was class %s name %s label %d at line %d",
	      DBG_TOKNAME(opener_class),
	      block_stack[block_depth].name,
	      block_stack[block_depth].label,
	      block_stack[block_depth].first_line);
    }
#endif
				/* DO loop terminator */
    if( label != NO_LABEL) {
      int shared_warning = TRUE;
				/* Mark DO index variable as inactive */
      int h=block_stack[block_depth].do_var_hash;
      if(h != -1)
	undef_do_variable(h);

      if( stmt_class == tok_ENDDO ) {
	must_check_name = TRUE;
      }
      else {
			/* issue picky warnings if not modern DO construct */
	if(style_req_enddo) {
	  warning(t->line_num,t->col_num,
		  "DO loop not terminated by ENDDO");
	}
	else if( stmt_class != tok_CONTINUE ) {
	  if(style_req_do_construct) {
	    warning(t->line_num,t->col_num,
		    "DO loop not terminated by CONTINUE or ENDDO");
	  }
	}
      }
      if( opener_class != tok_DO ) {
	syntax_error(t->line_num,t->col_num,keytok_name(opener_class));
	msg_tail("block not closed when DO loop terminating statement encountered");
      }
      else if( label != block_stack[block_depth].label ) {
	syntax_error(t->line_num,t->col_num,"Label");
	msg_tail(ulongtostr(label));
	msg_tail("on DO loop terminator does not match");
	if(block_stack[block_depth].label == NO_LABEL ) {
	  msg_tail("label-less DO statement");
	}
	else {
	  msg_tail("corresponding DO label");
	  msg_tail(ulongtostr(block_stack[block_depth].label));
	}
	msg_tail("above");
      }
		/* If terminator is shared by other DOs, pop them too */
      else {
	while(block_depth > 0 && label == block_stack[block_depth-1].label) {
	  --block_depth;

				/* Mark DO index variable as inactive */
	  {
	    int hh=block_stack[block_depth].do_var_hash;
	    if(hh != -1)
	      undef_do_variable(hh);
	  }
#ifdef DEBUG_BLOCKCHECK
	  if(debug_latest) {
	      fprintf(list_fd,"\n  opener was class %s name %s label %d at line %d",
		      DBG_TOKNAME(opener_class),
		      block_stack[block_depth].name,
		      block_stack[block_depth].label,
		      block_stack[block_depth].first_line);
	  }
#endif
	  if(style_shared_do_terminator && shared_warning) {
	    warning(t->line_num,t->col_num,
		    "Obsolescent feature: shared DO terminator");
	    shared_warning = FALSE; /* don't repeat the warning */
	  }
	}
      }
    }
    else if( stmt_class == tok_END ) {	/* plain END statement */
      if(style_req_structured_end) {
	  warning(t->line_num,t->col_num,"Old-style END statement");
      }
			/* Check that END statement ends subprog block */
      if(opener_class != tok_SUBROUTINE
	 && opener_class != tok_FUNCTION
	 && opener_class != tok_PROGRAM
	 && opener_class != tok_BLOCKDATA) {
	  syntax_error(t->line_num,t->col_num,
		       "Block not closed when END statement encountered");
      }
    }
    else {			/* structured block closers */
      int matching_class;

      must_check_name = TRUE;

				/* Look up the correct matching opener class */
      if( stmt_class < MIN_CLOSER || stmt_class > MAX_CLOSER ||
	  (matching_class = block_match[stmt_class-MIN_CLOSER]) == 0 ) {
	fprintf(list_fd,"%d=%s ",stmt_class,keytok_name(stmt_class));
	oops_message(OOPS_FATAL,t->line_num,t->col_num,
		     "pop_block called for unrecognized closing token");
      }
      else {			/* check if opener matches expected */
	if( opener_class != matching_class ) {
		/* If possible, use token names for better error messages */
	  syntax_error(t->line_num,t->col_num,
		       keytok_name(stmt_class));
	  msg_tail("statement does not match");
	  msg_tail(keytok_name(opener_class));
	  msg_tail("block it closes");

	  must_check_name = FALSE; /* name mismatch probably bogus here */
	}
				/* If unlabeled END DO of loop with index
				   variable, mark it inactive.
				 */
	if( stmt_class == tok_ENDDO ) {
	  int h=block_stack[block_depth].do_var_hash;
	  if(h != -1)
	    undef_do_variable(h);
	}
      }
    }
		/* Issue syntax error if name missing from a component of
		   a named construct.  In picky mode warn if no name tag on
		   structured END.
		*/
    if( must_check_name ) {
      if( name == (char *)NULL ) {
	if( blocktype == construct ) {	/* IF, DO, SELECT */
	  if( block_stack[block_depth].name != (char *)NULL ) {
	    syntax_error(t->line_num,t->col_num,
			 "Construct name");
	    msg_tail(block_stack[block_depth].name);
	    msg_tail("missing");
	  }
	}
	else {		/* structured END of subprogram */
	  if(style_req_end_name) {
	    warning(t->line_num,t->col_num,
		    "Name of subprogram missing from");
	    msg_tail(keytok_name(stmt_class));
	    msg_tail("statement");
	  }
	}
      }
				/* Otherwise check name tag if present */
      else {
			/* OK to compare pointers due to name storage method */
	if(name != block_stack[block_depth].name) {
			/* Opener name can only be missing from a construct,
			   but handle subprog case anyway.
			*/
	  if(block_stack[block_depth].name == (char *)NULL) {
	    syntax_error(t->line_num,t->col_num,
			   "name found on closing statement of unnamed");
	    msg_tail(blocktype == construct? "construct": "subprogram");
	  }
	  else {
	    syntax_error(t->line_num,t->col_num,
			 "Name");
	    msg_tail(name);
	    msg_tail("does not match");
	    msg_tail(blocktype == construct? "construct": "subprogram");
	    msg_tail("name");
	    msg_tail(block_stack[block_depth].name);
	  }
	}
      }
    }
  }
}

			/* Check CYCLE and EXIT statements for agreement
			   with enclosing DO loop.
			*/

PRIVATE void check_construct_name_match(Token *t, char *name)
{

				/* If no name on statement, it must at
				   least be inside range of a DO.
				 */
  if( name == (char *)NULL ) {
    int depth;
    for(depth = block_depth-1; depth >= 0; depth--) {
      if( block_stack[depth].sclass == tok_DO )
	return;
    }
    syntax_error(t->line_num,t->col_num,
		 "statement not within range of any DO loop");
  }
				/* If name tag present, it must belong to
				   an enclosing DO.
				*/
  else {
    int depth;
    for(depth = block_depth-1; depth >= 0; depth--) {
      if( block_stack[depth].sclass == tok_DO &&
	  block_stack[depth].name == name )
	  return;
    }
    syntax_error(t->line_num,t->col_num,
		 "construct name");
    msg_tail(name);
    msg_tail("does not match name of any enclosing DO construct");
  }
}

PRIVATE void push_block(Token *t, int stmt_class, BLOCK_TYPE blocktype,
			char *name, LABEL_t label)
{
  if(block_depth == MAX_BLOCK_DEPTH) {
    oops_message(OOPS_FATAL,t->line_num,t->col_num,
		     "blocks nested too deeply");
  }
  else {
#ifdef DEBUG_BLOCKCHECK
    if(debug_latest) {
      fprintf(list_fd,"\npushing stmt class %s name %s label %d at line %d",
	      DBG_TOKNAME(stmt_class),name,label,t->line_num);
    }
#endif
				/* ELSE and ELSE IF masquerade here as IF,
				   and CASE and CASEDEFAULT as SELECT, to
				   simplify match code in pop_block. */
    block_stack[block_depth].sclass = 
      ((stmt_class == tok_ELSE)? tok_IF:
       ((stmt_class == tok_CASE)? tok_SELECTCASE: stmt_class));
    block_stack[block_depth].name = name;
    block_stack[block_depth].label = label;
    block_stack[block_depth].first_line = t->line_num;
    block_stack[block_depth].blocktype = blocktype;
    block_stack[block_depth].do_var_hash = -1; /* undefined at this time */
    ++block_depth;

  }
}

PRIVATE void give_kind_warning(Token *t)
{
  warning(t->line_num,t->col_num,
"I do not yet support KIND selectors.  \
All KINDs are treated as default KIND.  \
Checking of type agreement may be incorrect as a result.  \
(This message is only given once.)");
  kind_warning_given = TRUE;
}

